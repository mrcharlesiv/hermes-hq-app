import CoreMedia
import Foundation
import ScreenCaptureKit
import ScreenCore

/// The Mac's console through ScreenCaptureKit, scaled to at most `maxWidth` pixels across. Runs only
/// while a viewer is connected; the helper's own windows are excluded; macOS shows its capture indicator.
final class ScreenCaptureSource: NSObject, FrameSource, SCStreamOutput, SCStreamDelegate {
    let name = "screen"
    let maxWidth: Int
    let displayID: CGDirectDisplayID?
    /// The display actually captured (only the requested one).
    private var capturedDisplay: CGDirectDisplayID?
    private var stream: SCStream?
    private var deliver: ((Frame) -> Void)?
    private var previous: CVPixelBuffer?
    private let queue = DispatchQueue(label: "dispatch-screen.capture")
    private let lock = NSLock()
    // Two slots: a thumbnail's display listing must not fail a viewer's capture start as busy.
    private let contentCalls = HelperDeadlineRunner(maxPending: 2)
    private let streamCalls = HelperDeadlineRunner()
    private let screenshotCalls = HelperDeadlineRunner()
    var log: (String) -> Void = { _ in }
    /// macOS ended the stream on its own; `userStopped` is the person pressing Stop in macOS's own
    /// screen-recording indicator.
    var onStopped: (_ reason: String, _ userStopped: Bool) -> Void = { _, _ in }

    /// Live, so pointer mapping follows a resolution or arrangement change while the helper runs.
    var displayBounds: CGRect? {
        lock.lock(); let id = capturedDisplay; lock.unlock()
        return id.map(CGDisplayBounds)
    }

    init(maxWidth: Int, displayID: CGDirectDisplayID?) {
        self.maxWidth = maxWidth
        self.displayID = displayID
    }

    private func filterAndConfiguration() throws -> (SCContentFilter, SCStreamConfiguration) {
        let content = try contentCalls.run("Listing displays", seconds: HelperDeadlines.content) { try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true) }
        let resolution = resolveDisplay(requested: displayID, main: CGMainDisplayID(), available: content.displays.map(\.displayID))
        let wanted: UInt32
        switch resolution {
        case let .use(id): wanted = id
        case let .selectedMissing(id):
            let reason = "Display \(id) is not connected. Reconnect it or choose another with hermes hq-screen enable --display, then Resume sharing at the Mac."
            // Losing the chosen display is Stop sharing: resuming must be a decision at the Mac.
            // The callback may take the server condition that the start caller owns.
            DispatchQueue.main.async { [weak self] in self?.onStopped(reason, true) }
            throw SocketError.system(reason, ENODEV)
        case let .mainMissing(id): throw SocketError.system("Main display \(id) is not available", ENODEV)
        }
        guard let display = content.displays.first(where: { $0.displayID == wanted }) else { throw SocketError.closed }
        let own = content.applications.filter { $0.bundleIdentifier == Bundle.main.bundleIdentifier }
        let filter = SCContentFilter(display: display, excludingApplications: own, exceptingWindows: [])
        lock.lock(); capturedDisplay = display.displayID; lock.unlock()
        let pointWidth = Double(display.width), pointHeight = Double(display.height)
        let pixelScale = Double(CGDisplayPixelsWide(display.displayID)) / max(1, pointWidth)
        let scale = min(1, Double(maxWidth) / (pointWidth * pixelScale)) * pixelScale
        let configuration = SCStreamConfiguration()
        // H.264 macroblocks: even dimensions.
        configuration.width = Int(pointWidth * scale) & ~1
        configuration.height = Int(pointHeight * scale) & ~1
        configuration.pixelFormat = kCVPixelFormatType_32BGRA
        configuration.showsCursor = true
        configuration.queueDepth = 5
        configuration.minimumFrameInterval = CMTime(value: 1, timescale: 30)
        configuration.colorSpaceName = CGColorSpace.sRGB
        return (filter, configuration)
    }

    func start(deliver: @escaping (Frame) -> Void) throws {
        let (filter, configuration) = try filterAndConfiguration()
        let stream = SCStream(filter: filter, configuration: configuration, delegate: self)
        try stream.addStreamOutput(self, type: .screen, sampleHandlerQueue: queue)
        lock.lock(); self.deliver = deliver; self.stream = stream; lock.unlock()
        do {
            try streamCalls.run("Starting screen capture", seconds: HelperDeadlines.captureStart,
                                   undo: { _ in try? await stream.stopCapture() }) { try await stream.startCapture() }
        } catch {
            lock.lock(); self.stream = nil; self.deliver = nil; previous = nil; lock.unlock()
            // If start is still pending, its late-success hook owns stop; otherwise clean up the failure.
            _ = try? streamCalls.run("Stopping failed screen capture", seconds: HelperDeadlines.captureStop) { try await stream.stopCapture() }
            throw error
        }
        log("capture started \(configuration.width)x\(configuration.height)")
    }

    func stop() {
        lock.lock(); let stream = self.stream; self.stream = nil; deliver = nil; previous = nil; lock.unlock()
        guard let stream else { return }
        _ = try? streamCalls.run("Stopping screen capture", seconds: HelperDeadlines.captureStop) { try await stream.stopCapture() }
        log("capture stopped")
    }

    func snapshot() -> Frame? {
        guard let (filter, configuration) = try? filterAndConfiguration(),
              let sample = try? screenshotCalls.run("Taking a screenshot", seconds: HelperDeadlines.screenshot, body: { try await SCScreenshotManager.captureSampleBuffer(contentFilter: filter, configuration: configuration) }),
              let buffer = CMSampleBufferGetImageBuffer(sample) else { return nil }
        return Frame(buffer: buffer, serial: 0, dirty: [Rect(x: 0, y: 0, width: CVPixelBufferGetWidth(buffer), height: CVPixelBufferGetHeight(buffer))])
    }

    func stream(_ stream: SCStream, didOutputSampleBuffer sample: CMSampleBuffer, of type: SCStreamOutputType) {
        guard type == .screen, sample.isValid, let buffer = CMSampleBufferGetImageBuffer(sample),
              let attachments = (CMSampleBufferGetSampleAttachmentsArray(sample, createIfNecessary: false) as? [[SCStreamFrameInfo: Any]])?.first,
              let rawStatus = attachments[.status] as? Int, SCFrameStatus(rawValue: rawStatus) == .complete else { return }
        // Changed regions by comparing with the previous frame: exact for Tight and Raw viewers
        // whatever coordinate space ScreenCaptureKit's own dirty-rect hints use.
        lock.lock()
        guard self.stream === stream else { lock.unlock(); return }
        let deliver = self.deliver
        let dirty = changedTiles(from: previous, to: buffer)
        previous = buffer
        lock.unlock()
        guard !dirty.isEmpty else { return }
        deliver?(Frame(buffer: buffer, serial: 0, dirty: dirty))
    }

    func stream(_ stream: SCStream, didStopWithError error: Error) {
        // macOS revoked or re-asked the Screen Recording grant, a display went away, or the person at
        // the Mac pressed Stop in the capture indicator. This stream is over; the server hears why.
        lock.lock()
        let current = self.stream === stream
        if current { self.stream = nil; deliver = nil; previous = nil }
        lock.unlock()
        log("capture stopped by macOS: \(error.localizedDescription)")
        guard current else { return }
        onStopped(error.localizedDescription, (error as? SCStreamError)?.code == .userStopped)
    }
}
