# Hermes HQ Screen setup source

This archive contains the Mac screen helper, gateway plugin, and setup script shipped with this Hermes HQ app. It does not require a Hermes HQ repository checkout.

1. Verify the archive's SHA-256 against the checksum in the setup request before extracting it.
2. Extract with /usr/bin/ditto -x -k "<archive path>" "<fresh temporary directory>" and open its hermes-hq-screen-setup directory. Use ditto to preserve app executable permissions and macOS metadata.
3. Use the included signed and notarized Hermes HQ Screen.app: run python3 scripts/setup-screen-helper.py --json --app "<absolute extracted directory>/hermes-hq-screen-setup/Hermes HQ Screen.app" and follow its reported next action. Add --control when the setup request authorizes taking control, and --wait-permissions 60 to continue checking while the owner approves permissions. Run again with --check --json to verify the installed setup.

Run setup on the Mac that serves the selected Hermes connection, as its owner. It replaces an older install of this helper and plugin made before the rename, keeping their settings and macOS permissions. The included helper needs macOS 14 or later. Xcode and an Apple signing identity are not required on the user’s Mac. The user must grant Screen Recording on that Mac, and Accessibility only when control is enabled.

Do not report success until the helper permissions, plugin health, display status and a live screen frame have been verified. If a prerequisite is unavailable, explain the concrete blocker. Do not weaken signature checks or modify macOS permission databases.
