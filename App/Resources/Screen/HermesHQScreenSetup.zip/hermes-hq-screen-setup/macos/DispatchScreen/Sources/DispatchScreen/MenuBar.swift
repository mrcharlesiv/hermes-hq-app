import AppKit
import ScreenCore

/// The Mac-side indicator: who is watching, whether a person is in control, and Stop sharing. macOS
/// adds its own capture indicator while the stream runs.
final class MenuBar: NSObject {
    private let helper: ScreenHelper
    private let item = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
    private let summary = NSMenuItem(title: "", action: nil, keyEquivalent: "")
    private let toggle = NSMenuItem(title: "", action: #selector(toggleSharing), keyEquivalent: "")

    init(helper: ScreenHelper) {
        self.helper = helper
        super.init()
        let menu = NSMenu()
        summary.isEnabled = false
        toggle.target = self
        menu.addItem(summary)
        menu.addItem(.separator())
        menu.addItem(toggle)
        let quit = NSMenuItem(title: "Quit Hermes HQ Screen", action: #selector(quit), keyEquivalent: "")
        quit.target = self
        menu.addItem(quit)
        item.menu = menu
        refresh()
    }

    func refresh() {
        let clients = helper.server.clientCount
        let paused = helper.server.isPaused
        let human = helper.isHumanInControl && clients > 0
        summary.title = paused ? "Sharing is stopped" : human ? "A person is controlling this Mac from Hermes HQ"
            : clients > 0 ? "Hermes HQ is viewing this Mac (\(clients))" : "Ready to share this Mac with Hermes HQ"
        toggle.title = paused ? "Resume sharing" : "Stop sharing"
        let symbol = paused ? "rectangle.slash" : clients > 0 ? "rectangle.inset.filled.and.person.filled" : "rectangle.on.rectangle"
        let image = NSImage(systemSymbolName: symbol, accessibilityDescription: summary.title)
        image?.isTemplate = !human
        item.button?.image = human ? image?.withSymbolConfiguration(.init(paletteColors: [.systemRed])) : image
        item.button?.toolTip = summary.title
    }

    @objc private func toggleSharing() {
        helper.setSharingPaused(!helper.server.isPaused)
        refresh()
    }

    @objc private func quit() { helper.onStop() }
}
