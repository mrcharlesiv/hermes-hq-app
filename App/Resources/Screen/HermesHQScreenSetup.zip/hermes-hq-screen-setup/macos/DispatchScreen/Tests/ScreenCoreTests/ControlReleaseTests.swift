import XCTest
@testable import ScreenCore

/// r5-54: the gateway plugin tells the helper about every lease transition with `release_input`, so a
/// transition that never flips human_control (one person taking over from another, or a takeover and
/// hand-back between two of the watcher's once-a-second samples) still lifts what the last person held.
final class ControlReleaseTests: XCTestCase {
    var directory: String!
    var server: RFBServer!
    var sink: RecordingSink!

    override func setUp() {
        directory = NSTemporaryDirectory() + "dsc-\(UUID().uuidString.prefix(8))"
        sink = RecordingSink()
        server = RFBServer(source: TestPatternSource(width: 320, height: 200, fps: 30), input: sink,
                           options: .init(name: "Test Mac", allowControl: true, displayFrame: CGRect(x: 0, y: 0, width: 640, height: 400), h264: false))
    }

    override func tearDown() {
        server?.stop()
        try? FileManager.default.removeItem(atPath: directory)
    }

    func testReleaseInputLiftsWhatAPersonHeldThoughHumanControlNeverFlipped() throws {
        let path = directory + "/rfb.sock"
        try server.listen(path: path)
        let client = try TestClient(path)
        try client.handshake()
        let helper = ScreenHelper(server: server, stateDir: URL(fileURLWithPath: directory))
        // The takeover's own notice, before the acquire answers the phone.
        _ = helper.handle(["cmd": "set", "human_control": true, "release_input": true])
        try client.pointer(1, 20, 20); try client.key(0xffe3, true); try client.roundTrip()
        // Another person takes over: human_control stays true.
        _ = helper.handle(["cmd": "set", "human_control": true, "release_input": true])
        XCTAssertEqual(Array(sink.snapshot.suffix(2)), [
            .button(.left, down: false, x: 40, y: 40, clicks: 1),
            .key(code: 59, down: false, flags: []),
        ], "the drag and Ctrl are lifted")
        let count = sink.snapshot.count
        _ = helper.handle(["cmd": "set", "human_control": false, "release_input": true])
        _ = helper.handle(["cmd": "set", "human_control": false, "release_input": true])
        XCTAssertEqual(sink.snapshot.count, count, "nothing is released twice")
        XCTAssertEqual(helper.status()["human_control"] as? Bool, false)
    }
}
