"""Hermes HQ Screen: Bot Screen for a macOS Hermes gateway ("watch and take control" of the Mac).

Hermes' Bot Screen ships a Linux backend only (Xvnc per profile). On a Mac this plugin supplies one:
the Hermes HQ Screen helper app captures the console and serves RFB on a private socket, and
``adapter.py`` points the core display runtime at it. Core keeps the tickets, the control lease, the
input gate and computer_use's fence. Nothing is shared until ``hermes hq-screen enable`` is run
at the Mac. See docs/bot-screen-mac.md in the Hermes HQ repository. (This plugin was called dispatch-screen;
``hermes dispatch-screen`` still works.)

Every process that loads plugins (serve, the messaging gateway, cron, the CLI) gets the host-wide
lease here; ``hermes serve`` also mounts ``dashboard/plugin_api.py``, which installs the backend. A
process started with a profile's HERMES_HOME (a kanban worker, a per-profile chat) looks for plugins
in that home only; its computer_use fence reads the profile's copy of the lease, kept in step
(adapter.mirror_lease).
"""
import importlib.util
import logging
import sys
from pathlib import Path

log = logging.getLogger("hermes-hq-screen")


def load(name: str):
    """This plugin's sibling modules, one instance per process (shared with dashboard/plugin_api.py)."""
    key = f"hermes_hq_screen_{name}"
    if key not in sys.modules:
        spec = importlib.util.spec_from_file_location(key, Path(__file__).with_name(f"{name}.py"))
        module = importlib.util.module_from_spec(spec)
        sys.modules[key] = module  # before exec: dataclasses and annotations resolve through it
        spec.loader.exec_module(module)
    return sys.modules[key]


def register(ctx):
    if sys.platform == "darwin":
        try:
            load("adapter").install_agent_side()
        except Exception:  # noqa: BLE001 - a broken plugin must never break the agent
            log.warning("hermes-hq-screen: could not install the host-wide lease", exc_info=True)
    cli = load("cli")
    ctx.register_cli_command(cli.COMMAND, "Share this Mac's screen with Hermes Bot Screen (Hermes HQ)",
                             cli.setup, cli.run, description=cli.DESCRIPTION)
    # The name this command had as dispatch-screen, so existing notes and scripts keep working.
    ctx.register_cli_command(cli.LEGACY_COMMAND, f"Old name of 'hermes {cli.COMMAND}'",
                             cli.setup, cli.run, description=cli.DESCRIPTION)
