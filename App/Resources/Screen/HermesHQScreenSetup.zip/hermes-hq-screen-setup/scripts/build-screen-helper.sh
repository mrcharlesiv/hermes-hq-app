#!/bin/zsh
# Builds "Hermes HQ Screen.app", the macOS helper behind Bot Screen on a Mac gateway (docs/bot-screen-mac.md).
#
#   scripts/build-screen-helper.sh                 test, build and sign into .build/hermes-hq-screen/
#   scripts/build-screen-helper.sh --install       ...then copy it to /Applications (the Mac's owner, at the Mac),
#                                                  replacing an old "Dispatch Screen.app" there (same bundle id)
#   options: --identity "Apple Development: …"     signing identity (default: the first Apple Development identity)
#            --adhoc                               ad-hoc signature (local tests; macOS forgets its grants on every rebuild)
#            --skip-tests                          skip swift test
#            --universal                           build both Apple silicon and Intel slices
#            --output DIR                          output folder (default: .build/hermes-hq-screen)
#   env: HERMES_HQ_SCREEN_OUT, HERMES_HQ_SCREEN_SIGN_IDENTITY (the old DISPATCH_SCREEN_* names still work)
#
# macOS ties Screen Recording and Accessibility to the app's signature (team + bundle id), so sign with
# the same identity every time or the grants have to be given again.
set -euo pipefail
ROOT=${0:A:h:h}
PACKAGE=$ROOT/macos/DispatchScreen
OUT=${HERMES_HQ_SCREEN_OUT:-${DISPATCH_SCREEN_OUT:-$ROOT/.build/hermes-hq-screen}}
APP_NAME="Hermes HQ Screen.app"
LEGACY_APP_NAME="Dispatch Screen.app"
IDENTITY=${HERMES_HQ_SCREEN_SIGN_IDENTITY:-${DISPATCH_SCREEN_SIGN_IDENTITY:-}}
INSTALL=0 TESTS=1 ADHOC=0 UNIVERSAL=0
while (( $# )); do
  case $1 in
    --install) INSTALL=1 ;;
    --identity) (( $# >= 2 )) || { print -u2 "--identity needs a signing identity"; exit 64; }; IDENTITY=$2; shift ;;
    --adhoc) ADHOC=1 ;;
    --skip-tests) TESTS=0 ;;
    --universal) UNIVERSAL=1 ;;
    --output) (( $# >= 2 )) || { print -u2 "--output needs a directory"; exit 64; }; OUT=${2:A}; shift ;;
    *) print -u2 "unknown option $1"; exit 64 ;;
  esac
  shift
done
APP="$OUT/$APP_NAME"

# Fail before compiling when this Mac cannot produce a helper the gateway will accept.
[[ $(uname -s) == Darwin ]] || { print -u2 "Hermes HQ Screen requires macOS 14 or later."; exit 1; }
MAJOR=$(sw_vers -productVersion | cut -d. -f1)
(( MAJOR >= 14 )) || { print -u2 "Hermes HQ Screen requires macOS 14 or later."; exit 1; }
command -v swift >/dev/null || { print -u2 "Install Xcode with Swift 6, or use a signed Hermes HQ Screen.app with scripts/setup-screen-helper.py --app."; exit 1; }
SWIFT_VERSION=$(swift --version)
[[ $SWIFT_VERSION =~ 'Swift version ([0-9]+)' ]] && (( match[1] >= 6 )) || { print -u2 "Hermes HQ Screen needs Swift 6 or later. Select a current Xcode, or use a signed helper."; exit 1; }

if (( ADHOC )); then
  IDENTITY=-
elif [[ -z $IDENTITY ]]; then
  IDENTITY=$(security find-identity -v -p codesigning | sed -n 's/.*"\(Apple Development: [^"]*\)".*/\1/p' | head -1)
  if [[ -z $IDENTITY ]]; then
    IDENTITY=$(security find-identity -v -p codesigning | sed -n 's/.*"\(Developer ID Application: [^"]*\)".*/\1/p' | head -1)
  fi
  [[ -n $IDENTITY ]] || { print -u2 "No Apple Development or Developer ID Application signing identity found. Use a signed Hermes HQ Screen.app with scripts/setup-screen-helper.py --app, or add your signing certificate in Xcode. Ad-hoc builds cannot be used for live sharing."; exit 1; }
fi

if (( TESTS )); then
  print "==> swift test"
  (cd $PACKAGE && swift test --quiet)
fi
if (( UNIVERSAL )); then
  # Fixed slice order and separate scratch trees prevent a stale host-only build
  # from being mistaken for a distributable app.
  for ARCH in arm64 x86_64; do
    print "==> swift build -c release ($ARCH)"
    swift build --package-path "$PACKAGE" --scratch-path "$OUT/swift-$ARCH" --arch "$ARCH" -c release --quiet
  done
  ARM_BIN=$(swift build --package-path "$PACKAGE" --scratch-path "$OUT/swift-arm64" --arch arm64 -c release --show-bin-path)/DispatchScreen
  INTEL_BIN=$(swift build --package-path "$PACKAGE" --scratch-path "$OUT/swift-x86_64" --arch x86_64 -c release --show-bin-path)/DispatchScreen
else
  print "==> swift build -c release"
  (cd $PACKAGE && swift build -c release --quiet)
  BIN=$(cd $PACKAGE && swift build -c release --show-bin-path)/DispatchScreen
fi

rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
if (( UNIVERSAL )); then
  lipo -create "$ARM_BIN" "$INTEL_BIN" -output "$APP/Contents/MacOS/DispatchScreen"
  ARCHS=$(lipo -archs "$APP/Contents/MacOS/DispatchScreen")
  [[ $ARCHS == "arm64 x86_64" || $ARCHS == "x86_64 arm64" ]] || { print -u2 "Universal helper has unexpected architectures: $ARCHS"; exit 1; }
else
  cp "$BIN" "$APP/Contents/MacOS/DispatchScreen"
fi
cp "$PACKAGE/Resources/Info.plist" "$APP/Contents/Info.plist"
print -n "APPL????" > "$APP/Contents/PkgInfo"

print "==> codesign ($IDENTITY)"
codesign --force --options runtime --sign "$IDENTITY" "$APP"
codesign --verify --strict --verbose=1 "$APP"
SIGNATURE=$(codesign -dv "$APP" 2>&1)
BUNDLE_ID=$(print -r -- "$SIGNATURE" | sed -n 's/^Identifier=//p')
TEAM_ID=$(print -r -- "$SIGNATURE" | sed -n 's/^TeamIdentifier=//p')
print "Identifier: $BUNDLE_ID"
if [[ -n $TEAM_ID && $TEAM_ID != "not set" ]]; then
  print "Team ID: $TEAM_ID  (hermes hq-screen enable --control --team-id $TEAM_ID)"
else
  print "Team ID: not set (ad-hoc signing has no Team ID; Bot Screen requires a team signature)"
fi
print "Built $APP"

if (( INSTALL )); then
  TARGET="/Applications/$APP_NAME"
  LEGACY="/Applications/$LEGACY_APP_NAME"
  # A running helper holds its state directory; ask it to stop so the new build is what launches next
  # (the old dispatch-screen plugin's helper serves the old folder).
  STOPPED=0
  for SOCK in $HOME/.hermes/hermes-hq-screen/ctl.sock $HOME/.hermes/dispatch-screen/ctl.sock; do
    if [[ -S $SOCK ]]; then
      python3 -c 'import socket,sys;s=socket.socket(socket.AF_UNIX);s.settimeout(2);s.connect(sys.argv[1]);s.sendall(b"{\"cmd\":\"stop\"}\n");s.recv(64)' "$SOCK" 2>/dev/null && STOPPED=1 || true
    fi
  done
  (( STOPPED )) && sleep 1
  rm -rf "$TARGET"
  ditto "$APP" "$TARGET"
  print "Installed $TARGET"
  # One helper only: the renamed app replaces "Dispatch Screen.app" (same bundle id, so macOS keeps its grants).
  if [[ -d $LEGACY && ! -L $LEGACY ]] && [[ $(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$LEGACY/Contents/Info.plist" 2>/dev/null) == $BUNDLE_ID ]]; then
    rm -rf "$LEGACY"
    print "Removed $LEGACY (replaced by $TARGET)"
  fi
  print "Next, at this Mac: \"$TARGET/Contents/MacOS/DispatchScreen\" grant"
fi
