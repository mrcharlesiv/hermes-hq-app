"""The serve-side loop: repaint every bot's Screen when the shared Mac console changes, tell the
helper's menu bar whether a person is in control, keep each profile home's copy of the lease in step
(adapter.mirror_lease), and give control back to the agents when a person's lease is orphaned (a
killed phone never hands back).

Core broadcasts ``display.lease`` / ``display.status`` only for the profile that made a change and
for homes whose ``bot-desktop`` files move; one console shared by every bot needs every allowed
profile's pane repainted, so this loop broadcasts for them itself.
"""
from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any, Callable, Iterable, Optional

log = logging.getLogger("hermes-hq-screen")


class Watcher:
    def __init__(self, helper, *, homes: Callable[[], Iterable[Path]], broadcast: Callable[[str, dict], None],
                 snapshot: Callable[[Path], Optional[dict]], clock: Callable[[], float] = time.monotonic,
                 mirror: Optional[Callable[[], Any]] = None):
        self.helper = helper
        self.homes = homes
        self.broadcast = broadcast
        self.snapshot = snapshot
        self.clock = clock
        self.mirror = mirror
        self._epoch: Optional[int] = None
        self._status_key: Optional[tuple] = None
        # (holder, viewer id, epoch) last told to the helper
        self._hold: Optional[tuple] = None
        # ((viewer id, epoch) of the unwatched hold, since when)
        self._orphaned: Optional[tuple[tuple, float]] = None
        self._mirror_problem: Optional[str] = None

    def _mirror_failed(self, exc: Exception, _lease) -> None:
        if str(exc) != self._mirror_problem:  # once per distinct failure, not every second
            log.warning("hermes-hq-screen: could not mirror the lease into the profile homes: %s", exc)
            self._mirror_problem = str(exc)
        # A person holds control while some profile's own processes still read "agent" (a profile added
        # during the hold whose copy can't be written): the Mac goes back to the agents, by holder, rather
        # than that profile's computer_use acting under the person. A takeover through the plugin never gets
        # this far (adapter._host_wide_notify refuses it).
        current = _lease.get()
        failures = getattr(exc, "failures", None) or []
        if current.holder == _lease.HUMAN and any(_lease._read(path).holder != _lease.HUMAN for _name, path, _error in failures):
            released = _lease.release(viewer_id=current.viewer_id)
            log.warning("hermes-hq-screen: handed the Mac back because a profile could not be paused (holder now %s)", released.holder)

    def _allowed_homes(self) -> list[Path]:
        return [home for home in self.homes() if self.helper.profile_allowed(_profile_of(home, self.helper.root()))]

    def tick(self) -> None:
        from hermes_constants import hermes_home_key
        from tools.bot_desktop import lease as _lease

        if self.mirror is not None:
            try:
                self.mirror()  # a change made by another process (the messaging gateway, the CLI)
                self._mirror_problem = None
            except Exception as exc:  # noqa: BLE001 - one unwritable profile must not stop the repaints or the orphan release
                self._mirror_failed(exc, _lease)
        # The helper first: a transition landing between the two reads then leaves it behind the lease, and
        # the check below says the newer holder again rather than a stale one.
        live = self.helper.helper_status()
        current = _lease.get()
        homes = self._allowed_homes()
        if self._epoch is not None and current.epoch != self._epoch:
            for home in homes:
                self.broadcast("display.lease", {"profile_key": hermes_home_key(home), "lease": _lease.public_view(current)})
        self._epoch = current.epoch

        # Every transition tells the helper itself (adapter.tell_helper); this catches up on one it missed (a
        # helper that was busy or restarting), by the whole hold, not a Boolean sampled once a second: a
        # takeover and hand-back between two ticks still hands the Mac back with nothing left pressed. Input
        # is released only once the agent holds: a person who has just taken control may already be pressing.
        # (A person taking over from another is covered by the helper: it lifts the last controller's input
        # before the next viewer's first event.) The helper refuses input while it thinks the agent holds
        # (r6-77), so one that restarted between two ticks (never seen down) and says so is told again.
        human = current.holder == _lease.HUMAN
        hold = (current.holder, current.viewer_id, current.epoch)
        if live is not None and (hold != self._hold or live.get("human_control", human) != human):
            request = {"cmd": "set", "human_control": human}
            if self._hold is not None and hold != self._hold and not human:
                request["release_input"] = True
            self.helper.ctl(request)
        self._hold = hold if live is not None else None

        key = (bool(live), (live or {}).get("clients"), (live or {}).get("paused"), ((live or {}).get("tcc") or {}).get("screen"),
               self.helper.paused(), self.helper.settings().get("enabled"))
        if self._status_key is not None and key != self._status_key:
            for home in homes:
                payload = self.snapshot(home)
                if payload:
                    self.broadcast("display.status", payload)
        self._status_key = key

        # A person's lease with nobody watching for stale_human_lease_minutes: the phone was killed or
        # lost; hand the Mac back so the agents are not fenced out indefinitely.
        # The clock belongs to one hold: a phone that comes back and re-takes control (a new id, a new
        # epoch) before its stream connects starts a fresh one.
        clients = (live or {}).get("clients", 0)
        limit = float(self.helper.settings().get("stale_human_lease_minutes") or 0) * 60
        hold = (current.viewer_id, current.epoch) if human else None
        if hold is None or clients or limit <= 0:
            self._orphaned = None
        elif self._orphaned is None or self._orphaned[0] != hold:
            self._orphaned = (hold, self.clock())
        elif self.clock() - self._orphaned[1] >= limit:
            self._orphaned = None
            if not (self.helper.helper_status() or {}).get("clients"):
                # By holder: core releases only while that same viewer still holds, so a takeover
                # landing now is never revoked.
                released = _lease.release(viewer_id=current.viewer_id)
                log.info("hermes-hq-screen: released a person's lease nobody had watched for %.0f min (holder now %s)",
                         limit / 60, released.holder)


def _profile_of(home: Path, root: Path) -> str:
    home = Path(home)
    return "default" if home.resolve() == Path(root).resolve() else home.name
