import CoreMedia
import Foundation
import VideoToolbox

/// RFB "Open H.264" (encoding 50, as noVNC 1.7 decodes it with WebCodecs): one full-framebuffer rect
/// per update carrying Annex-B NAL units. Hardware VideoToolbox, realtime, no B-frames. Frames are
/// encoded only when a client's update request is answered, so the pull model never breaks the
/// reference chain; a keyframe (with SPS/PPS) starts every stream and follows every resize.
public final class H264Encoder {
    public let width: Int
    public let height: Int
    private var session: VTCompressionSession?
    private var index: Int64 = 0
    private var forceKey = true

    /// Bits per second for RFB QualityLevel 0-9 at 1080p; scaled by area, never under 300 kbps.
    public static func bitrate(quality: Int, width: Int, height: Int) -> Int {
        let at1080: [Double] = [0.25, 0.35, 0.5, 0.7, 0.85, 1.0, 1.6, 2.5, 3.5, 5.0]
        let mbps = at1080[max(0, min(9, quality))] * Double(width * height) / Double(1920 * 1080)
        return max(300_000, Int(mbps * 1_000_000))
    }

    public init?(width: Int, height: Int, bitrate: Int) {
        self.width = width
        self.height = height
        var created: VTCompressionSession?
        let spec = [kVTVideoEncoderSpecification_EnableHardwareAcceleratedVideoEncoder: true] as CFDictionary
        let status = VTCompressionSessionCreate(allocator: nil, width: Int32(width), height: Int32(height), codecType: kCMVideoCodecType_H264,
                                                encoderSpecification: spec, imageBufferAttributes: nil, compressedDataAllocator: nil,
                                                outputCallback: nil, refcon: nil, compressionSessionOut: &created)
        guard status == noErr, let session = created else { return nil }
        self.session = session
        VTSessionSetProperty(session, key: kVTCompressionPropertyKey_RealTime, value: kCFBooleanTrue)
        // Constrained Baseline decodes everywhere WebCodecs does (the simulator reported avc1.42401f supported).
        VTSessionSetProperty(session, key: kVTCompressionPropertyKey_ProfileLevel, value: kVTProfileLevel_H264_ConstrainedBaseline_AutoLevel)
        VTSessionSetProperty(session, key: kVTCompressionPropertyKey_AllowFrameReordering, value: kCFBooleanFalse)
        VTSessionSetProperty(session, key: kVTCompressionPropertyKey_MaxKeyFrameInterval, value: 3600 as CFNumber)
        VTSessionSetProperty(session, key: kVTCompressionPropertyKey_ExpectedFrameRate, value: 30 as CFNumber)
        setBitrate(bitrate)
        VTCompressionSessionPrepareToEncodeFrames(session)
    }

    deinit {
        if let session { VTCompressionSessionInvalidate(session) }
    }

    public func setBitrate(_ bitsPerSecond: Int) {
        guard let session else { return }
        VTSessionSetProperty(session, key: kVTCompressionPropertyKey_AverageBitRate, value: bitsPerSecond as CFNumber)
        // Cap bursts at 1.5x the average per second so a scroll cannot flood a phone link.
        let limit = [Double(bitsPerSecond) * 1.5 / 8, 1.0] as CFArray
        VTSessionSetProperty(session, key: kVTCompressionPropertyKey_DataRateLimits, value: limit)
    }

    public func requestKeyframe() { forceKey = true }

    /// Encodes one frame; returns Annex-B bytes (SPS/PPS first on a keyframe) and whether it is a keyframe.
    public func encode(_ buffer: CVPixelBuffer) -> (data: [UInt8], key: Bool)? {
        guard let session else { return nil }
        let lock = NSLock()
        var result: (data: [UInt8], key: Bool)?
        let properties: CFDictionary? = forceKey ? [kVTEncodeFrameOptionKey_ForceKeyFrame: true] as CFDictionary : nil
        let pts = CMTime(value: index, timescale: 30)
        index += 1
        let status = VTCompressionSessionEncodeFrame(session, imageBuffer: buffer, presentationTimeStamp: pts, duration: .invalid,
                                                     frameProperties: properties, infoFlagsOut: nil) { status, _, sample in
            guard status == noErr, let sample, let converted = H264Encoder.annexB(sample) else { return }
            lock.lock(); result = converted; lock.unlock()
        }
        guard status == noErr else { return nil }
        VTCompressionSessionCompleteFrames(session, untilPresentationTimeStamp: .invalid)
        lock.lock(); defer { lock.unlock() }
        if result?.key == true { forceKey = false }
        return result
    }

    static func annexB(_ sample: CMSampleBuffer) -> (data: [UInt8], key: Bool)? {
        guard let block = CMSampleBufferGetDataBuffer(sample) else { return nil }
        let attachments = CMSampleBufferGetSampleAttachmentsArray(sample, createIfNecessary: false) as? [[CFString: Any]]
        let key = !(attachments?.first?[kCMSampleAttachmentKey_NotSync] as? Bool ?? false)
        let startCode: [UInt8] = [0, 0, 0, 1]
        var out: [UInt8] = []
        var headerLength: Int32 = 4
        if key, let format = CMSampleBufferGetFormatDescription(sample) {
            var count = 0
            CMVideoFormatDescriptionGetH264ParameterSetAtIndex(format, parameterSetIndex: 0, parameterSetPointerOut: nil, parameterSetSizeOut: nil,
                                                               parameterSetCountOut: &count, nalUnitHeaderLengthOut: &headerLength)
            for index in 0 ..< count {
                var pointer: UnsafePointer<UInt8>?
                var size = 0
                if CMVideoFormatDescriptionGetH264ParameterSetAtIndex(format, parameterSetIndex: index, parameterSetPointerOut: &pointer,
                                                                      parameterSetSizeOut: &size, parameterSetCountOut: nil,
                                                                      nalUnitHeaderLengthOut: nil) == noErr, let pointer {
                    out += startCode
                    out += UnsafeBufferPointer(start: pointer, count: size)
                }
            }
        }
        let total = CMBlockBufferGetDataLength(block)
        var avcc = [UInt8](repeating: 0, count: total)
        guard CMBlockBufferCopyDataBytes(block, atOffset: 0, dataLength: total, destination: &avcc) == noErr else { return nil }
        let lengthSize = Int(headerLength)
        var offset = 0
        while offset + lengthSize <= total {
            var length = 0
            for byte in avcc[offset ..< offset + lengthSize] { length = length << 8 | Int(byte) }
            offset += lengthSize
            guard length > 0, offset + length <= total else { break }
            out += startCode
            out += avcc[offset ..< offset + length]
            offset += length
        }
        return (out, key)
    }
}
