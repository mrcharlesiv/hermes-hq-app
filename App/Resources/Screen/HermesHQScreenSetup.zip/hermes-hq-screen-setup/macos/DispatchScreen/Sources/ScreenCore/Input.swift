import Foundation

/// What a remote key or pointer event becomes on this Mac, before CGEvent (DispatchScreen/EventInput.swift).
public enum InputAction: Equatable {
    public enum Button: Int { case left = 0, right = 1, middle = 2 }
    case move(x: Double, y: Double, dragging: Button?)
    case button(Button, down: Bool, x: Double, y: Double, clicks: Int)
    /// Lines to scroll: positive `dy` is up, positive `dx` is left (the X11 wheel buttons 4-7).
    case scroll(dx: Int, dy: Int, x: Double, y: Double)
    /// A virtual key (modifiers are their own keys) with the modifier flags held after it.
    case key(code: UInt16, down: Bool, flags: ModifierFlags)
    /// Layout-independent text for a printable key with no ⌘, ⌃ or ⌥ held.
    case text(String, down: Bool)
    case pasteboard(String)
}

public struct ModifierFlags: OptionSet, Equatable {
    public let rawValue: UInt8
    public init(rawValue: UInt8) { self.rawValue = rawValue }
    public static let shift = ModifierFlags(rawValue: 1)
    public static let control = ModifierFlags(rawValue: 2)
    public static let option = ModifierFlags(rawValue: 4)
    public static let command = ModifierFlags(rawValue: 8)
    public static let capsLock = ModifierFlags(rawValue: 16)
}

/// X11 keysyms (as noVNC sends them) to macOS virtual key codes (Carbon kVK_*).
public enum Keysyms {
    public static let modifiers: [UInt32: (code: UInt16, flag: ModifierFlags)] = [
        0xffe1: (56, .shift), 0xffe2: (60, .shift),          // Shift_L, Shift_R
        0xffe3: (59, .control), 0xffe4: (62, .control),      // Control_L, Control_R
        0xffe9: (58, .option), 0xffea: (61, .option),        // Alt_L, Alt_R → Option
        0xffe7: (55, .command), 0xffe8: (54, .command),      // Meta_L, Meta_R → Command
        0xffeb: (55, .command), 0xffec: (54, .command),      // Super_L, Super_R → Command
        0xffe5: (57, .capsLock),                             // Caps_Lock
    ]
    public static let special: [UInt32: UInt16] = [
        0xff0d: 36, 0xff8d: 76,                  // Return, KP_Enter
        0xff09: 48, 0xfe20: 48,                  // Tab, ISO_Left_Tab
        0xff08: 51, 0xff1b: 53, 0xffff: 117,     // BackSpace, Escape, Delete
        0xff50: 115, 0xff57: 119,                // Home, End
        0xff55: 116, 0xff56: 121,                // Page_Up, Page_Down
        0xff51: 123, 0xff53: 124, 0xff54: 125, 0xff52: 126,  // Left, Right, Down, Up
        0xffbe: 122, 0xffbf: 120, 0xffc0: 99, 0xffc1: 118, 0xffc2: 96, 0xffc3: 97,   // F1-F6
        0xffc4: 98, 0xffc5: 100, 0xffc6: 101, 0xffc7: 109, 0xffc8: 103, 0xffc9: 111, // F7-F12
        0xff63: 114,                             // Insert → Help
    ]
    /// US-layout virtual keys for the characters that combine with ⌘/⌃/⌥ (the helper replaces these
    /// with the current layout's own table at launch).
    public static let usLayout: [Character: UInt16] = {
        var table: [Character: UInt16] = [:]
        let rows: [(String, [UInt16])] = [
            ("asdfhgzxcv", [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]), ("bqweryt", [11, 12, 13, 14, 15, 16, 17]),
            ("123465", [18, 19, 20, 21, 22, 23]), ("=97-80]ou[ip", [24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35]),
            ("lj'k;\\,/nm.", [37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47]), ("` ", [50, 49]),
        ]
        for (chars, codes) in rows { for (char, code) in zip(chars, codes) { table[char] = code } }
        return table
    }()

    /// The table shortcuts use: the helper installs the current keyboard layout's at launch.
    public static var activeLayout: [Character: UInt16] = usLayout

    /// The character a printable keysym stands for (Latin-1 directly, else 0x01000000 + code point).
    public static func character(_ keysym: UInt32) -> Character? {
        let scalar: UInt32
        if (0x20 ... 0x7e).contains(keysym) || (0xa0 ... 0xff).contains(keysym) { scalar = keysym }
        else if keysym >= 0x0100_0000, keysym <= 0x0110_ffff { scalar = keysym - 0x0100_0000 }
        else { return nil }
        return Unicode.Scalar(scalar).map(Character.init)
    }
}

/// macOS counts a double click only when the second press lands within the double-click interval and
/// a few points of the first; without kCGMouseEventClickState set, apps never see double clicks.
public struct ClickTracker {
    public var interval: TimeInterval
    public var slop: Double
    private var last: (button: InputAction.Button, at: TimeInterval, x: Double, y: Double, count: Int)?

    public init(interval: TimeInterval = 0.5, slop: Double = 4) { self.interval = interval; self.slop = slop }

    public mutating func press(_ button: InputAction.Button, at time: TimeInterval, x: Double, y: Double) -> Int {
        var count = 1
        if let last, last.button == button, time - last.at <= interval, abs(x - last.x) <= slop, abs(y - last.y) <= slop {
            count = min(last.count + 1, 3)
        }
        last = (button, time, x, y, count)
        return count
    }
}

/// Turns RFB pointer and key events into InputActions: button-mask edges into presses with click
/// counts, moves with a button held into drags, wheel buttons into line scrolls, and keysyms into
/// virtual keys or layout-independent text.
public struct InputTranslator {
    public var clicks = ClickTracker()
    public var layout: [Character: UInt16] = Keysyms.activeLayout
    private var mask: UInt8 = 0
    private var flags: ModifierFlags = []
    /// A key this viewer holds down: a virtual key (a special key, or a shortcut's letter) or typed text.
    private enum HeldKey { case code(UInt16), text(String) }
    /// Every held key in press order, so releaseAll lifts each one (a viewer can drop between down and up).
    private var held: [(keysym: UInt32, key: HeldKey)] = []
    private var releaseCounts: [InputAction.Button: Int] = [:]
    private var lastPosition: (x: Double, y: Double) = (-1, -1)

    public init() {}

    /// Framebuffer coordinates in, screen points out: `scale` maps one onto the other.
    public mutating func pointer(mask newMask: UInt8, x: Int, y: Int, scale: (Double, Double) -> (Double, Double), time: TimeInterval) -> [InputAction] {
        let (px, py) = scale(Double(x), Double(y))
        var out: [InputAction] = []
        let buttons: [(UInt8, InputAction.Button)] = [(1, .left), (4, .right), (2, .middle)]
        let held = buttons.first { mask & $0.0 != 0 }?.1
        if lastPosition.x != px || lastPosition.y != py { out.append(.move(x: px, y: py, dragging: held)) }
        lastPosition = (px, py)
        for (bit, button) in buttons where (newMask ^ mask) & bit != 0 {
            let down = newMask & bit != 0
            let count = down ? clicks.press(button, at: time, x: px, y: py) : releaseCounts[button] ?? 1
            if down { releaseCounts[button] = count }
            out.append(.button(button, down: down, x: px, y: py, clicks: count))
        }
        // Wheel "buttons" arrive as a press then a release; act on the press only.
        let pressed = newMask & ~mask
        if pressed & 0x08 != 0 { out.append(.scroll(dx: 0, dy: 3, x: px, y: py)) }
        if pressed & 0x10 != 0 { out.append(.scroll(dx: 0, dy: -3, x: px, y: py)) }
        if pressed & 0x20 != 0 { out.append(.scroll(dx: 3, dy: 0, x: px, y: py)) }
        if pressed & 0x40 != 0 { out.append(.scroll(dx: -3, dy: 0, x: px, y: py)) }
        mask = newMask
        return out
    }


    public mutating func key(_ keysym: UInt32, down: Bool) -> [InputAction] {
        if let modifier = Keysyms.modifiers[keysym] {
            if modifier.flag == .capsLock {
                if down { flags.formSymmetricDifference(.capsLock) }
            } else if down { flags.insert(modifier.flag) } else { flags.remove(modifier.flag) }
            return [.key(code: modifier.code, down: down, flags: flags)]
        }
        if let code = Keysyms.special[keysym] {
            if down { hold(keysym, .code(code)) } else { _ = lift(keysym) }
            return [.key(code: code, down: down, flags: flags)]
        }
        guard let char = Keysyms.character(keysym) else { return [] }
        let shortcut = !flags.intersection([.command, .control, .option]).isEmpty
        if down {
            if shortcut, let code = layout[Character(char.lowercased())] {
                hold(keysym, .code(code))
                return [.key(code: code, down: true, flags: shortcutFlags(char))]
            }
            hold(keysym, .text(String(char)))
            return [.text(String(char), down: true)]
        }
        switch lift(keysym) {
        case let .code(code)?: return [.key(code: code, down: false, flags: shortcutFlags(char))]
        case let .text(text)?: return [.text(text, down: false)]
        case nil: return []
        }
    }

    /// A shortcut's letter is looked up unshifted, so its case would be lost: an upper-case keysym (⌘ then
    /// "Z" with no Shift_L, as a phone's sticky ⌘ plus a capital sends it) is ⌘⇧Z, never ⌘Z.
    private func shortcutFlags(_ char: Character) -> ModifierFlags {
        char.isUppercase && String(char) != char.lowercased() ? flags.union(.shift) : flags
    }

    /// A repeat of a held key replaces its entry, so one release (or releaseAll) lifts it once.
    private mutating func hold(_ keysym: UInt32, _ key: HeldKey) {
        held.removeAll { $0.keysym == keysym }
        held.append((keysym, key))
    }

    private mutating func lift(_ keysym: UInt32) -> HeldKey? {
        guard let index = held.lastIndex(where: { $0.keysym == keysym }) else { return nil }
        return held.remove(at: index).key
    }

    /// Everything released (a client left mid-drag or with a modifier down), where the pointer last was.
    public mutating func releaseAll(x fallbackX: Double, y fallbackY: Double) -> [InputAction] {
        let (x, y) = lastPosition.x >= 0 ? lastPosition : (fallbackX, fallbackY)
        var out: [InputAction] = []
        for (bit, button) in [(UInt8(1), InputAction.Button.left), (4, .right), (2, .middle)] where mask & bit != 0 {
            out.append(.button(button, down: false, x: x, y: y, clicks: 1))
        }
        mask = 0
        // Newest first, then the modifiers: every key-down posted for this viewer gets its key-up.
        for entry in held.reversed() {
            switch entry.key {
            case let .code(code): out.append(.key(code: code, down: false, flags: flags))
            case let .text(text): out.append(.text(text, down: false))
            }
        }
        held.removeAll()
        for (flag, code) in [(ModifierFlags.shift, UInt16(56)), (.control, 59), (.option, 58), (.command, 55)] where flags.contains(flag) {
            flags.remove(flag)
            out.append(.key(code: code, down: false, flags: flags))
        }
        return out
    }
}

/// Receives translated input (CGEventPost in the app; a recorder in tests).
public protocol InputSink: AnyObject {
    func perform(_ action: InputAction)
}

public final class RecordingSink: InputSink {
    public private(set) var actions: [InputAction] = []
    private let lock = NSLock()
    public init() {}
    public func perform(_ action: InputAction) { lock.lock(); actions.append(action); lock.unlock() }
    public var snapshot: [InputAction] { lock.lock(); defer { lock.unlock() }; return actions }
}
