// swift-tools-version:6.0
// Hermes HQ Screen: shares this Mac's screen with the Hermes Bot Screen (RFB over a private Unix
// socket). Built into "Hermes HQ Screen.app" by scripts/build-screen-helper.sh; see docs/bot-screen-mac.md.
// The package, target and executable keep their old DispatchScreen name (never shown: the app's
// name comes from Info.plist, and the gateway plugin finds Contents/MacOS/DispatchScreen).
import PackageDescription

let package = Package(
    name: "DispatchScreen",
    platforms: [.macOS(.v14)],
    products: [
        .executable(name: "DispatchScreen", targets: ["DispatchScreen"]),
    ],
    targets: [
        // Protocol, encoders, input translation and the control socket: no TCC, fully testable.
        .target(name: "ScreenCore", swiftSettings: [.swiftLanguageMode(.v5)]),
        // ScreenCaptureKit capture, CGEvent input, the menu-bar item and the CLI.
        .executableTarget(name: "DispatchScreen", dependencies: ["ScreenCore"], swiftSettings: [.swiftLanguageMode(.v5)]),
        .testTarget(name: "ScreenCoreTests", dependencies: ["ScreenCore"], swiftSettings: [.swiftLanguageMode(.v5)]),
    ]
)
