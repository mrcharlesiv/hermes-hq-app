import XCTest
@testable import ScreenCore

final class HelperPolicyTests: XCTestCase {
    private let unlocked: [String: Any] = [
        "CGSSessionUniqueSessionUUID": "test", "kCGSSessionAuditIDKey": 1,
        "kCGSSessionGroupIDKey": 20, "kCGSSessionLoginwindowSafeLogin": false,
        "kCGSSessionOnConsoleKey": true, "kCGSSessionSystemSafeBoot": false,
        "kCGSSessionUserIDKey": 501, "kCGSSessionUserNameKey": "test",
        "kCGSessionLoginDoneKey": true, "kCGSessionLongUserNameKey": "Test", "kSCSecuritySessionID": 1,
    ]

    func testDisplaySelectionNeverFallsBack() {
        XCTAssertEqual(resolveDisplay(requested: 2, main: 1, available: [1, 2]), .use(2))
        XCTAssertEqual(resolveDisplay(requested: 2, main: 1, available: [1, 3]), .selectedMissing(2))
        XCTAssertEqual(resolveDisplay(requested: 2, main: 1, available: []), .selectedMissing(2))
        XCTAssertEqual(resolveDisplay(requested: nil, main: 1, available: [2, 1]), .use(1))
        XCTAssertEqual(resolveDisplay(requested: nil, main: 2, available: [1, 2]), .use(2))
        XCTAssertEqual(resolveDisplay(requested: nil, main: 1, available: [2]), .mainMissing(1))
        XCTAssertEqual(resolveDisplay(requested: nil, main: 1, available: []), .mainMissing(1))
    }

    func testMeasuredConsoleIsUnlockedButUnknownIsRefused() {
        XCTAssertEqual(consoleLockState(session: unlocked, notified: .init()), .unlocked)
        XCTAssertEqual(consoleLockState(session: nil, notified: .init()), .unknown)
        for key in ["kCGSSessionOnConsoleKey", "kCGSessionLoginDoneKey"] {
            var session = unlocked
            session.removeValue(forKey: key)
            XCTAssertEqual(consoleLockState(session: session, notified: .init()), .unknown)
            session[key] = false
            XCTAssertEqual(consoleLockState(session: session, notified: .init()), .locked)
            session[key] = "true"
            XCTAssertEqual(consoleLockState(session: session, notified: .init()), .unknown)
        }
    }

    func testLockSignalsWinOverUnlockedSignals() {
        XCTAssertEqual(consoleLockState(session: unlocked, notified: .init(screenLocked: true)), .locked)
        XCTAssertEqual(consoleLockState(session: unlocked, notified: .init(sessionResigned: true)), .locked)
        var session = unlocked
        session["CGSSessionScreenIsLocked"] = true
        XCTAssertEqual(consoleLockState(session: session, notified: .init()), .locked)
        session["CGSSessionScreenIsLocked"] = false
        XCTAssertEqual(consoleLockState(session: session, notified: .init(screenLocked: true)), .locked)
        XCTAssertEqual(consoleLockState(session: session, notified: .init(sessionResigned: true)), .locked)
        for bad: Any in ["false", 1, NSNull()] {
            session["CGSSessionScreenIsLocked"] = bad
            XCTAssertEqual(consoleLockState(session: session, notified: .init()), .unknown)
        }
    }

    func testDeadlineReturnsValueAndPropagatesError() throws {
        XCTAssertEqual(try withHelperDeadline("value", seconds: 1) { 42 }, 42)
        enum Failure: Error { case expected }
        XCTAssertThrowsError(try withHelperDeadline("error", seconds: 1) { throw Failure.expected }) {
            XCTAssertTrue($0 is Failure)
        }
    }

    func testDeadlineCancelsAnUnfinishedBody() {
        let cancelled = expectation(description: "cancelled")
        XCTAssertThrowsError(try withHelperDeadline("never", seconds: 0.05) {
            do { try await Task.sleep(nanoseconds: UInt64.max) }
            catch { cancelled.fulfill(); throw error }
        }) { XCTAssertEqual(String(describing: $0), "never timed out") }
        wait(for: [cancelled], timeout: 2)
    }

    func testUncooperativeOperationRetainsItsWorkerSlotUntilCleanup() {
        let runner = HelperDeadlineRunner()
        let proceed = DispatchSemaphore(value: 0)
        let cleaned = expectation(description: "late operation cleaned")
        XCTAssertThrowsError(try runner.run("held", seconds: 0.05, undo: { _ in cleaned.fulfill() }) {
            XCTAssertEqual(proceed.wait(timeout: .now() + 2), .success)
            return 1
        }) { XCTAssertTrue($0 is HelperTimeout) }
        XCTAssertThrowsError(try runner.run("retry", seconds: 0.05) { 2 }) { XCTAssertTrue($0 is HelperBusy) }
        proceed.signal()
        wait(for: [cleaned], timeout: 2)
    }

    func testLateSuccessIsUndoneExactlyOnce() {
        let undone = expectation(description: "undone")
        undone.assertForOverFulfill = true
        XCTAssertThrowsError(try withHelperDeadline("late", seconds: 0.05, undo: { value in
            XCTAssertEqual(value, 7); undone.fulfill()
        }) {
            try? await Task.sleep(nanoseconds: 10_000_000_000)
            return 7
        }) { XCTAssertTrue($0 is HelperTimeout) }
        wait(for: [undone], timeout: 2)
    }
}
