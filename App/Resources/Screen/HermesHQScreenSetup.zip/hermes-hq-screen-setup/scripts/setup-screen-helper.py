#!/usr/bin/env python3
"""Set up the signed Mac screen helper from any working directory.

The normal caller is Hermes, after the owner requests setup in Hermes HQ. macOS
permission approvals still belong to the owner. This script never changes TCC,
silently resumes paused sharing, or kills a gateway to restart it.

  python3 /path/to/hermes-ios/scripts/setup-screen-helper.py
  python3 /path/to/hermes-ios/scripts/setup-screen-helper.py --app '/path/Hermes HQ Screen.app'
  python3 /path/to/hermes-ios/scripts/setup-screen-helper.py --check --json

Exit 0: local checks passed; verify the live gateway's display.status next.
Exit 2: the owner needs to approve permissions. Exit 3: another setup is running.
Exit 1: setup is blocked. --check does not change the installation or checkpoint.

The helper and plugin were called "Dispatch Screen.app" and dispatch-screen. Setup carries the old
settings over (the old ~/.hermes/dispatch-screen folder is kept), installs "Hermes HQ Screen.app" and
the hermes-hq-screen plugin, then removes the old app and plugin so only one helper remains. The bundle
id is unchanged, so macOS keeps the Screen Recording and Accessibility grants.
"""
from __future__ import annotations

import argparse
import ast
from contextlib import ExitStack, contextmanager
import fcntl
import hashlib
import importlib.util
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path

SOURCE = Path(__file__).resolve().parents[1]
BUNDLE_ID = "com.charlesmcdowell.dispatch.screen"
SETUP_SCHEMA_VERSION = 1
INSTALLER_VERSION = "1.2.0"
APP_NAME = "Hermes HQ Screen.app"
LEGACY_APP_NAME = "Dispatch Screen.app"
EXECUTABLE = "DispatchScreen"
PLUGIN_NAME = "hermes-hq-screen"
LEGACY_PLUGIN_NAME = "dispatch-screen"
CLI = "hq-screen"
STATE_NAME = "hermes-hq-screen"
LEGACY_STATE_NAME = "dispatch-screen"


class SetupError(Exception):
    pass


class SetupBusy(SetupError):
    pass


def atomic_json(path, value):
    """Keep the last complete checkpoint if writing a new one is interrupted."""
    if path.is_symlink():
        raise SetupError(f"Refusing to replace a symbolic link at {path}.")
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", dir=path.parent, prefix=".setup-state-", delete=False) as stream:
            temporary = Path(stream.name)
            os.chmod(temporary, 0o600)
            json.dump(value, stream, indent=2, sort_keys=True)
            stream.flush()
            os.fsync(stream.fileno())
        temporary.replace(path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


@contextmanager
def setup_lock(state):
    """One installer per host, shared by every bot profile; a dead process releases the lock."""
    if state.is_symlink():
        raise SetupError(f"Refusing to use a symbolic link for screen state at {state}.")
    state.mkdir(parents=True, exist_ok=True, mode=0o700)
    descriptor = os.open(state / "setup.lock", os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0), 0o600)
    try:
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise SetupBusy("Another Hermes chat is already setting up this Mac. Let it finish, then check setup again.") from exc
        yield
    finally:
        os.close(descriptor)


@contextmanager
def check_lock(state):
    """Checks never create files, but do not inspect a half-installed plugin either."""
    try:
        descriptor = os.open(state / "setup.lock", os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    except FileNotFoundError:
        yield
        return
    try:
        try:
            fcntl.flock(descriptor, fcntl.LOCK_SH | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise SetupBusy("Another Hermes chat is still setting up this Mac. Check again after it finishes.") from exc
        yield
    finally:
        os.close(descriptor)


class SetupProgress:
    def __init__(self, state):
        self.path = state / "setup-state.json"
        previous = read_json(self.path)
        self.value = {"setup_schema_version": SETUP_SCHEMA_VERSION, "installer_version": INSTALLER_VERSION,
                      "run_id": uuid.uuid4().hex, "started_at": int(time.time()),
                      "gateway_reload_pending": previous.get("gateway_reload_pending") is True or previous.get("restart_required") is True,
                      "restart_required": None,
                      "plugin_sha256": previous.get("plugin_sha256"),
                      "gateway_verification_required": True, "local_ready": False}
        self.update(phase="preparing")

    def update(self, **values):
        self.value.update(values)
        self.value["updated_at"] = int(time.time())
        atomic_json(self.path, self.value)


def tree_fingerprint(root):
    """Content identity, ignoring caches the installed plugin does not keep."""
    if not root.is_dir():
        return None
    digest = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root)
        if any(part in ("tests", "__pycache__") for part in relative.parts) or path.suffix == ".pyc":
            continue
        digest.update(str(relative).encode() + b"\0")
        if path.is_symlink():
            digest.update(b"link\0" + os.readlink(path).encode())
        elif path.is_file():
            digest.update(b"file\0")
            with path.open("rb") as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b""):
                    digest.update(block)
        else:
            digest.update(b"dir\0")
    return digest.hexdigest()


def validate_plugin(plugin):
    required = ("__init__.py", "adapter.py", "cli.py", "helper.py", "watch.py", "dashboard/plugin_api.py",
                "plugin.yaml", "pinned-shapes.json")
    for name in required:
        if not (plugin / name).is_file() or (plugin / name).is_symlink():
            raise SetupError(f"The screen plugin is incomplete: {name} is missing or is a symbolic link.")
    if f"name: {PLUGIN_NAME}\n" not in (plugin / "plugin.yaml").read_text():
        raise SetupError("The screen plugin manifest has an unexpected identity.")
    if not isinstance(json.loads((plugin / "pinned-shapes.json").read_text()), dict):
        raise SetupError("The screen plugin compatibility record is invalid.")
    for path in plugin.rglob("*.py"):
        if path.is_symlink():
            raise SetupError(f"The screen plugin contains a symbolic link: {path.relative_to(plugin)}.")
        try:
            ast.parse(path.read_text(), filename=str(path))
        except (SyntaxError, UnicodeError) as exc:
            raise SetupError(f"The screen plugin has invalid Python in {path.relative_to(plugin)}: {exc}") from exc


def run(argv, *, env=None, timeout=60):
    try:
        result = subprocess.run([str(arg) for arg in argv], capture_output=True, text=True,
                                timeout=timeout, env=env)
    except (OSError, subprocess.SubprocessError) as exc:
        raise SetupError(f"Could not run {Path(str(argv[0])).name}: {exc}") from exc
    if result.returncode:
        raise SetupError((result.stderr.strip() or result.stdout.strip() or
                          f"{Path(str(argv[0])).name} exited with {result.returncode}")[-4000:])
    return result.stdout


def hermes_root(value=None):
    if value:
        return Path(value).expanduser().resolve()
    native = Path.home() / ".hermes"
    value = os.environ.get("HERMES_HOME", "").strip()
    if not value:
        return native
    home = Path(value).expanduser().resolve()
    if home == native or native in home.parents:
        return native
    return home.parent.parent if home.parent.name == "profiles" else home


def read_json(path):
    try:
        value = json.loads(path.read_text())
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def command_value(output):
    # Hermes can print plugin diagnostics before its command's JSON result.
    decoder = json.JSONDecoder()
    for index, char in enumerate(output):
        if char not in "{[":
            continue
        try:
            value, length = decoder.raw_decode(output[index:])
            if isinstance(value, (dict, list)) and not output[index + length:].strip():
                return value
        except ValueError:
            pass
    raise SetupError(f"Hermes did not return a readable setup report. Run hermes {CLI} doctor for details.")


def command_json(output):
    value = command_value(output)
    if not isinstance(value, dict):
        raise SetupError("Hermes returned an unexpected setup report.")
    return value


def plugin_entries(command, env):
    entries = command_value(run([*command, "plugins", "list", "--json"], env=env, timeout=120))
    if not isinstance(entries, list):
        raise SetupError("Hermes could not report the current plugin state. Update Hermes and retry setup.")
    return [entry for entry in entries if isinstance(entry, dict)]


def plugin_enabled(command, env, entries=None):
    entries = plugin_entries(command, env) if entries is None else entries
    return any(entry.get("name") == PLUGIN_NAME and entry.get("status") == "enabled" for entry in entries)


def settings_path(root):
    """This plugin's settings, or the old dispatch-screen ones until they are carried over."""
    current = root / STATE_NAME / "settings.json"
    legacy = root / LEGACY_STATE_NAME / "settings.json"
    return legacy if not current.exists() and not current.is_symlink() and legacy.is_file() else current


def migrate_legacy_state(root):
    """Copy the old dispatch-screen state across with the plugin's own code (nothing overwritten, the old
    folder kept), before this run's lock and checkpoint create the new folder."""
    try:
        spec = importlib.util.spec_from_file_location("hermes_hq_screen_setup_migrate", SOURCE / "gateway-plugin" / PLUGIN_NAME / "helper.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module.migrate_legacy_state(root)
    except (OSError, ImportError, AttributeError, SyntaxError) as exc:
        raise SetupError(f"Could not carry the old Dispatch Screen settings over: {exc}") from exc


def app_bundle_id(app):
    try:
        import plistlib
        return plistlib.loads((app / "Contents/Info.plist").read_bytes()).get("CFBundleIdentifier")
    except (OSError, ValueError):
        return None


def remove_legacy_apps(apps, keep):
    """Remove old "Dispatch Screen.app" copies of this helper (same bundle id) once the renamed app is
    installed, so one helper remains. Returns (removed, actions for any that could not be removed)."""
    removed, actions = [], []
    for app in dict.fromkeys(apps):
        if app.name != LEGACY_APP_NAME or app.is_symlink() or not app.is_dir() or app.resolve() == keep.resolve():
            continue
        if app_bundle_id(app) != BUNDLE_ID:
            continue
        try:
            shutil.rmtree(app)
            removed.append(str(app))
        except OSError as exc:
            actions.append(f"Move the old {app} to the Trash; {APP_NAME} replaces it ({exc}).")
    return removed, actions


def existing_settings(path):
    if path.is_symlink():
        raise SetupError(f"Refusing to change screen settings through the symbolic link {path}.")
    if not path.exists():
        return {}
    try:
        value = json.loads(path.read_text())
    except (OSError, ValueError) as exc:
        raise SetupError("The existing screen settings are unreadable. Repair them before setup so their restrictions are preserved.") from exc
    if not isinstance(value, dict):
        raise SetupError("The existing screen settings are invalid; setup has left them unchanged.")
    if "allow_control" in value and not isinstance(value["allow_control"], bool):
        raise SetupError("The existing screen control setting is invalid; setup has left it unchanged.")
    if "team_ids" in value and (not isinstance(value["team_ids"], list) or
                               any(not isinstance(team, str) or not team for team in value["team_ids"])):
        raise SetupError("The existing signing restrictions are invalid; setup has left them unchanged.")
    if "profiles" in value and value["profiles"] != "all" and (not isinstance(value["profiles"], list) or
                                                              any(not isinstance(name, str) or not name for name in value["profiles"])):
        raise SetupError("The existing profile restrictions are invalid; setup has left them unchanged.")
    return value


def signed_team(app):
    if not (app / "Contents/MacOS" / EXECUTABLE).is_file():
        raise SetupError(f"No Hermes HQ Screen helper is installed at {app}.")
    run(["/usr/bin/codesign", "--verify", "--strict", app])
    try:
        result = subprocess.run(["/usr/bin/codesign", "-dv", "--verbose=2", str(app)],
                                capture_output=True, text=True, timeout=20)
    except (OSError, subprocess.SubprocessError) as exc:
        raise SetupError(f"Could not read the helper signature: {exc}") from exc
    info = dict(line.split("=", 1) for line in result.stderr.splitlines() if "=" in line)
    team = info.get("TeamIdentifier", "not set")
    if result.returncode or info.get("Identifier") != BUNDLE_ID or team in ("", "not set"):
        raise SetupError("Hermes HQ Screen needs a valid Apple team signature. Ad-hoc or unrelated apps cannot share the screen.")
    return team


def build_helper():
    # The build script validates macOS, Swift and a team certificate before compiling.
    run(["/bin/zsh", SOURCE / "scripts/build-screen-helper.sh"], timeout=900)
    out = os.environ.get("HERMES_HQ_SCREEN_OUT") or os.environ.get("DISPATCH_SCREEN_OUT") or str(SOURCE / ".build/hermes-hq-screen")
    return Path(out) / APP_NAME


def load_helper(plugin, root):
    spec = importlib.util.spec_from_file_location("hermes_hq_screen_setup_helper", plugin / "helper.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    # This library's only Hermes import resolves the root. Pass the root explicitly so
    # an installer launched by a named profile still owns the host-wide helper state.
    module.root = lambda: root
    return module


@contextmanager
def replaced_directory(source, destination, *, validate=None, before_replace=None, copy=None):
    """Validate the staged copy, and retain the previous version through the caller's checks."""
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.is_symlink():
        raise SetupError(f"Refusing to replace a symbolic link at {destination}.")
    temporary = Path(tempfile.mkdtemp(prefix=".hermes-hq-screen-", dir=destination.parent))
    keep_backup = False
    try:
        stage = temporary / destination.name
        backup = temporary / "previous"
        if copy:
            copy(source, stage)
        else:
            shutil.copytree(source, stage, symlinks=True, ignore=shutil.ignore_patterns("tests", "__pycache__", "*.pyc"))
        if validate:
            validate(stage)
        if before_replace:
            before_replace()
        had_previous = destination.exists()
        if had_previous:
            destination.rename(backup)
        try:
            stage.rename(destination)
            if validate:
                validate(destination)
            yield
        except BaseException:
            try:
                if destination.exists() and not stage.exists():
                    shutil.rmtree(destination)
                if had_previous and backup.exists():
                    backup.rename(destination)
            except OSError as exc:
                keep_backup = True
                raise SetupError(f"Could not restore {destination}. Recovery files remain at {temporary}: {exc}") from exc
            raise
    finally:
        if not keep_backup:
            shutil.rmtree(temporary)


def replace_directory(source, destination, *, validate=None):
    with replaced_directory(source, destination, validate=validate):
        pass


def copy_app(source, destination):
    # Preserve the signed bundle's metadata and notarization ticket as Finder does.
    run(["/usr/bin/ditto", source, destination], timeout=120)


def install_app(source, destination, helper, transactions=None):
    team = signed_team(source)
    if source.resolve() == destination.resolve() or tree_fingerprint(source) == tree_fingerprint(destination):
        signed_team(destination)
        return team

    def stop_previous():
        # Stop only this helper, after the staged replacement is verified.
        helper.ctl({"cmd": "stop"})
        deadline = time.monotonic() + 5
        while helper.helper_status() is not None:
            if time.monotonic() >= deadline:
                raise SetupError("The running helper did not stop. Quit Hermes HQ Screen from its menu bar, then retry setup.")
            time.sleep(0.1)
    replacement = replaced_directory(source, destination, validate=signed_team, before_replace=stop_previous, copy=copy_app)
    if transactions is not None:
        transactions.enter_context(replacement)
    else:
        with replacement:
            pass
    return team


def assess(report, control=False):
    """Fresh CLI health is necessary; only the live display RPC can prove gateway readiness."""
    problems = []
    if report.get("hermes_shapes") != "ok":
        problems.append("This Hermes version is incompatible with the screen plugin: " + str(report.get("hermes_shapes", "unknown")))
    if report.get("signature") != "ok":
        problems.append(str(report.get("signature") or "The helper signature could not be verified."))
    if report.get("plugin_enabled") is not True:
        problems.append("The screen plugin is not confirmed enabled in the host's Hermes configuration.")
    if not report.get("settings", {}).get("enabled"):
        problems.append("Screen sharing is not enabled.")
    if problems:
        return "blocked", problems
    live = report.get("helper") or {}
    if live.get("paused"):
        return "blocked", ["Sharing was paused at this Mac. Resume sharing from the Hermes HQ Screen menu bar."]
    permissions = live.get("tcc") or report.get("permissions") or {}
    if not isinstance(permissions, dict):
        return "blocked", ["The Mac's permission status could not be verified."]
    missing = []
    if permissions.get("screen") is not True:
        missing.append("Allow Hermes HQ Screen in System Settings > Privacy & Security > Screen & System Audio Recording.")
    if control and permissions.get("events") is not True:
        missing.append("Allow Hermes HQ Screen in System Settings > Privacy & Security > Accessibility for control.")
    if missing:
        return "permissions_required", missing
    if report.get("blocker"):
        return "blocked", [str(report["blocker"])]
    if live.get("capture_error"):
        return "blocked", [str(live["capture_error"])]
    if live.get("ok") is not True:
        return "helper_start_required", ["The helper is not running. Re-run setup to launch it, then verify the live Screen connection."]
    return "ready_to_verify", []


def setup(args):
    if platform.system() != "Darwin" or int(platform.mac_ver()[0].split(".")[0] or 0) < 14:
        raise SetupError("Live Mac screen sharing requires macOS 14 or later on the gateway host.")
    root = hermes_root(args.hermes_root)
    if args.check:
        with check_lock(root / STATE_NAME):
            return setup_at_root(args, root)
    migrate_legacy_state(root)
    with setup_lock(root / STATE_NAME):
        progress = SetupProgress(root / STATE_NAME)
        try:
            return setup_at_root(args, root, progress)
        except (SetupError, OSError, ValueError) as exc:
            progress.update(phase="blocked", status="blocked", actions=[str(exc)], local_ready=False)
            raise



def wait_for_permissions(read_report, control, seconds, progress=None):
    """Observe local permission changes without reinstalling or dismissing system prompts."""
    deadline = time.monotonic() + max(0, min(seconds, 300))
    while True:
        report = read_report()
        status, actions = assess(report, control)
        if status != "permissions_required" or time.monotonic() >= deadline:
            return report
        if progress:
            progress.update(phase="waiting_permission", status=status, actions=actions, local_ready=False)
        time.sleep(min(2, max(0, deadline - time.monotonic())))


def setup_at_root(args, root, progress=None):
    executable = shutil.which("hermes")
    if not executable:
        fallback = Path.home() / ".local/bin/hermes"
        executable = str(fallback) if fallback.is_file() else None
    if not executable:
        raise SetupError("Hermes is not installed on this Mac or its executable cannot be found.")
    env = {**os.environ, "HERMES_HOME": str(root)}
    # The explicit selector prevents a sticky active profile from receiving the plugin instead.
    command = [executable, "-p", "default"]
    state = root / STATE_NAME
    settings = existing_settings(settings_path(root))
    control = args.control or bool(settings.get("allow_control"))
    plugin = root / "plugins" / PLUGIN_NAME
    legacy_plugin = root / "plugins" / LEGACY_PLUGIN_NAME
    saved = read_json(state / "setup-state.json")
    reload_pending = saved.get("gateway_reload_pending") is True or saved.get("restart_required") is True
    legacy = {"plugin_removed": False, "apps_removed": [], "actions": []}
    if not args.check:
        source_plugin = SOURCE / "gateway-plugin" / PLUGIN_NAME
        validate_plugin(source_plugin)
        helper = load_helper(source_plugin, root)
        existing = Path(str(settings.get("helper_path", "/Applications/" + APP_NAME))).expanduser()
        renamed = existing.with_name(APP_NAME) if existing.name == LEGACY_APP_NAME else existing
        source = Path(args.app).expanduser().resolve() if args.app else renamed
        if not args.app:
            try:
                signed_team(source)
            except SetupError:
                try:
                    source = build_helper()
                except SetupError:
                    # No toolchain or identity here: keep the signed old app working rather than block.
                    if renamed == existing:
                        raise
                    signed_team(existing)
                    source = renamed = existing
                    legacy["actions"].append(f"Kept the old {existing.name}: {APP_NAME} could not be built on this Mac.")
        team = signed_team(source)
        allowed_teams = settings.get("team_ids") or []
        if allowed_teams and team not in allowed_teams:
            raise SetupError(f"The helper belongs to team {team}, outside the existing allowed teams. Keep the original signing identity.")
        if source.resolve() == renamed.resolve():
            target = renamed
        else:
            applications = Path(args.install_dir).expanduser() if args.install_dir else existing.parent if existing.name == LEGACY_APP_NAME else (
                Path("/Applications") if os.access("/Applications", os.W_OK) else Path.home() / "Applications")
            target = applications / APP_NAME
        entries = plugin_entries(command, env)
        was_enabled = plugin_enabled(command, env, entries)
        legacy_installed = legacy_plugin.exists() or any(entry.get("name") == LEGACY_PLUGIN_NAME for entry in entries)
        source_fingerprint = tree_fingerprint(source_plugin)
        plugin_changed = tree_fingerprint(plugin) != source_fingerprint
        progress.update(phase="installing", helper_path=str(target))
        activation_attempted = False
        try:
            # Keep both previous versions until the fresh CLI has checked the new plugin.
            with ExitStack() as transactions:
                install_app(source, target, helper, transactions)
                if plugin_changed:
                    transactions.enter_context(replaced_directory(source_plugin, plugin, validate=validate_plugin))
                if not was_enabled:
                    activation_attempted = True
                    run([*command, "plugins", "enable", PLUGIN_NAME], env=env, timeout=120)
                preflight = command_json(run([*command, CLI, "doctor"], env=env))
                if preflight.get("hermes_shapes") != "ok":
                    raise SetupError("This Hermes version is incompatible with the screen plugin: " + str(preflight.get("hermes_shapes")))
                if preflight.get("plugin_enabled") is not True:
                    raise SetupError("Hermes did not enable the screen plugin. Its previous installation has been restored.")
        except BaseException:
            if activation_attempted and not was_enabled:
                try:
                    run([*command, "plugins", "disable", PLUGIN_NAME], env=env, timeout=120)
                except SetupError:
                    progress.update(activation_rollback_required=True)
            raise
        # One plugin and one helper: the renamed ones replace dispatch-screen and "Dispatch Screen.app"
        # (the old ~/.hermes/dispatch-screen settings folder stays). Only after the new ones checked out.
        if legacy_installed:
            try:
                run([*command, "plugins", "remove", LEGACY_PLUGIN_NAME], env=env, timeout=120)
                legacy["plugin_removed"] = True
            except SetupError as exc:
                legacy["actions"].append(f"Remove the old plugin with: hermes plugins remove {LEGACY_PLUGIN_NAME} ({exc})")
        if target.name == APP_NAME:
            old_apps = [existing, target.with_name(LEGACY_APP_NAME)]
            if any(app.name == LEGACY_APP_NAME and app.is_dir() for app in old_apps):
                helper.stop_legacy_helper(root / LEGACY_STATE_NAME)
            legacy["apps_removed"], actions = remove_legacy_apps(old_apps, target)
            legacy["actions"] += actions
        reload_pending = reload_pending or plugin_changed or not was_enabled or legacy["plugin_removed"]
        progress.update(phase="configuring", gateway_reload_pending=reload_pending,
                        plugin_sha256=source_fingerprint, signing_team=team)
        teams = allowed_teams or [team]
        run([*command, CLI, "enable", "--control" if control else "--no-control",
             "--helper-path", target, *[arg for allowed in teams for arg in ("--team-id", allowed)]], env=env)
        # LaunchServices owns attribution of the macOS privacy prompts. There is no TCC bypass.
        helper = load_helper(plugin, root)
        helper.ensure_running()
        # After permission approval a retry reuses the installed bits and only checks/starts them.
        current = helper.helper_status() or {}
        permissions = current.get("tcc") or {}
        if not (state / "sharing_paused").exists() and (permissions.get("screen") is not True or
                                                       (control and permissions.get("events") is not True)):
            progress.update(phase="waiting_permission")
            run(["/usr/bin/open", "-n", "-a", target, "--args", "grant",
                 *(["--control"] if control else [])])
    report = wait_for_permissions(
        lambda: command_json(run([*command, CLI, "doctor"], env=env)),
        control, getattr(args, "wait_permissions", 0), progress)
    status, actions = assess(report, args.control or bool(report.get("settings", {}).get("allow_control")))
    actions = actions + legacy["actions"]
    phase = ("waiting_permission" if status == "permissions_required" else
             "waiting_helper" if status == "helper_start_required" else
             "blocked" if status == "blocked" else "waiting_gateway_verification")
    result = {"setup_schema_version": SETUP_SCHEMA_VERSION, "installer_version": INSTALLER_VERSION,
            "status": status, "phase": phase, "actions": actions, "hermes_root": str(root),
            "local_ready": status == "ready_to_verify", "plugin_sha256": tree_fingerprint(plugin),
            "gateway_verification_required": True,
            "gateway_reload_pending": reload_pending, "restart_required": None,
            "legacy_plugin_removed": legacy["plugin_removed"], "legacy_apps_removed": legacy["apps_removed"],
            "verification": "Verify the connected gateway's hermes-hq-screen health and this bot's display.status; restart only its existing managed services if the new plugin is not loaded, then open Screen and confirm a live frame.",
            "doctor": report}
    if progress:
        progress.update(**{key: value for key, value in result.items() if key != "doctor"})
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--app", help="use an already signed helper app instead of compiling")
    parser.add_argument("--install-dir", help="application folder (default: /Applications if writable, else ~/Applications)")
    parser.add_argument("--hermes-root", help="host's Hermes root; defaults to the root of HERMES_HOME")
    parser.add_argument("--control", action="store_true", help="also enable remote input and request Accessibility")
    parser.add_argument("--wait-permissions", type=int, choices=range(0, 301), metavar="0..300", default=0,
                        help="wait this many seconds for permission approval, without reinstalling")
    parser.add_argument("--check", action="store_true", help="report local readiness without installing, enabling or requesting permissions")
    parser.add_argument("--json", action="store_true", help="print a machine-readable report")
    args = parser.parse_args(argv)
    try:
        result = setup(args)
    except SetupBusy as exc:
        result = {"status": "setup_running", "phase": "installing", "actions": [str(exc)],
                  "setup_schema_version": SETUP_SCHEMA_VERSION, "installer_version": INSTALLER_VERSION,
                  "local_ready": False, "gateway_verification_required": True}
    except (SetupError, OSError, ValueError) as exc:
        result = {"status": "blocked", "phase": "blocked", "actions": [str(exc)],
                  "setup_schema_version": SETUP_SCHEMA_VERSION, "installer_version": INSTALLER_VERSION,
                  "local_ready": False, "gateway_verification_required": True}
    if args.json:
        print(json.dumps(result, indent=2, sort_keys=True))
    else:
        print("Mac screen setup: " + result["status"].replace("_", " "))
        for action in result.get("actions", []):
            print(action)
        if result.get("verification"):
            print(result["verification"])
        if result["status"] == "ready_to_verify":
            print("The signed helper is running and its required permissions are allowed. Verify Screen in Hermes HQ before reporting success.")
    return 2 if result["status"] == "permissions_required" else 3 if result["status"] == "setup_running" else 0 if result["status"] == "ready_to_verify" else 1


if __name__ == "__main__":
    sys.exit(main())
