import Darwin
import Foundation

/// `~/.hermes/hermes-hq-screen/` (0700): rfb.sock and ctl.sock (0600), helper.pid, helper.lock,
/// helper.log (rotated; never frames or typed text), sharing_paused.
public final class StateDirectory {
    public let url: URL
    private var lockFD: Int32 = -1
    private let logLock = NSLock()

    public init(path: String) throws {
        url = URL(fileURLWithPath: (path as NSString).expandingTildeInPath, isDirectory: true)
        try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        chmod(url.path, 0o700)
    }

    public var rfbSocket: String { url.appendingPathComponent("rfb.sock").path }
    public var controlSocket: String { url.appendingPathComponent("ctl.sock").path }

    /// One helper per state directory: false when another instance holds the lock.
    public func acquireSingleInstance() -> Bool {
        let path = url.appendingPathComponent("helper.lock").path
        lockFD = open(path, O_CREAT | O_RDWR, 0o600)
        guard lockFD >= 0, flock(lockFD, LOCK_EX | LOCK_NB) == 0 else { return false }
        let pid = "\(getpid())\n"
        FileManager.default.createFile(atPath: url.appendingPathComponent("helper.pid").path, contents: Data(pid.utf8),
                                       attributes: [.posixPermissions: 0o600])
        return true
    }

    public func releaseSingleInstance() {
        try? FileManager.default.removeItem(at: url.appendingPathComponent("helper.pid"))
        if lockFD >= 0 { flock(lockFD, LOCK_UN); close(lockFD); lockFD = -1 }
    }

    public func log(_ message: String) {
        logLock.lock(); defer { logLock.unlock() }
        let file = url.appendingPathComponent("helper.log")
        if let size = (try? FileManager.default.attributesOfItem(atPath: file.path)[.size]) as? Int, size > 1_000_000 {
            let old = url.appendingPathComponent("helper.log.1")
            try? FileManager.default.removeItem(at: old)
            try? FileManager.default.moveItem(at: file, to: old)
        }
        let line = "\(ISO8601DateFormatter().string(from: Date())) \(message)\n"
        if let handle = FileHandle(forWritingAtPath: file.path) {
            handle.seekToEndOfFile(); handle.write(Data(line.utf8)); try? handle.close()
        } else {
            FileManager.default.createFile(atPath: file.path, contents: Data(line.utf8), attributes: [.posixPermissions: 0o600])
        }
    }
}
