import CoreVideo
import Foundation

public struct Rect: Equatable, CustomStringConvertible {
    public var x: Int, y: Int, width: Int, height: Int
    public init(x: Int, y: Int, width: Int, height: Int) { self.x = x; self.y = y; self.width = width; self.height = height }
    public var isEmpty: Bool { width <= 0 || height <= 0 }
    public var maxX: Int { x + width }
    public var maxY: Int { y + height }
    public var area: Int { max(0, width) * max(0, height) }
    public var description: String { "\(x),\(y) \(width)x\(height)" }

    public func union(_ other: Rect) -> Rect {
        if isEmpty { return other }
        if other.isEmpty { return self }
        let minX = min(x, other.x), minY = min(y, other.y)
        return Rect(x: minX, y: minY, width: max(maxX, other.maxX) - minX, height: max(maxY, other.maxY) - minY)
    }

    public func intersection(_ other: Rect) -> Rect {
        let minX = max(x, other.x), minY = max(y, other.y)
        let w = min(maxX, other.maxX) - minX, h = min(maxY, other.maxY) - minY
        return w > 0 && h > 0 ? Rect(x: minX, y: minY, width: w, height: h) : Rect(x: 0, y: 0, width: 0, height: 0)
    }

    /// Grown outward to a `grid` boundary (clamped to `bounds`): JPEG's 16-pixel MCUs then line up
    /// between updates, so a region re-encoded later shows no seam against its neighbours.
    public func aligned(to grid: Int, within bounds: Rect) -> Rect {
        let minX = x / grid * grid, minY = y / grid * grid
        let maxX = (self.maxX + grid - 1) / grid * grid, maxY = (self.maxY + grid - 1) / grid * grid
        return Rect(x: minX, y: minY, width: maxX - minX, height: maxY - minY).intersection(bounds)
    }

    /// Overlapping or within `slack` of each other.
    func touches(_ other: Rect, slack: Int) -> Bool {
        x - slack < other.maxX && other.x - slack < maxX && y - slack < other.maxY && other.y - slack < maxY
    }
}

/// Coalesce changed regions for one update: touching rects merge; past `limit` rects, or when the
/// union is barely larger than their sum, a single bounding box is cheaper to encode.
public func coalesce(_ rects: [Rect], within bounds: Rect, limit: Int = 12) -> [Rect] {
    var pending = rects.map { $0.intersection(bounds) }.filter { !$0.isEmpty }
    var merged: [Rect] = []
    while let first = pending.popLast() {
        var current = first
        var changed = true
        while changed {
            changed = false
            pending.removeAll { other in
                guard current.touches(other, slack: 16) else { return false }
                current = current.union(other)
                changed = true
                return true
            }
            merged.removeAll { other in
                guard current.touches(other, slack: 16) else { return false }
                current = current.union(other)
                changed = true
                return true
            }
        }
        merged.append(current)
    }
    if merged.count > limit {
        return [merged.dropFirst().reduce(merged[0]) { $0.union($1) }]
    }
    return merged.sorted { ($0.y, $0.x) < ($1.y, $1.x) }
}

/// One captured frame: a 32-bit BGRA pixel buffer (IOSurface-backed from ScreenCaptureKit), the
/// regions that changed since the previous frame, and a serial the sessions pull against.
public final class Frame {
    public let buffer: CVPixelBuffer
    public let serial: UInt64
    public let dirty: [Rect]
    public let capturedAt: Date

    public init(buffer: CVPixelBuffer, serial: UInt64, dirty: [Rect], capturedAt: Date = Date()) {
        self.buffer = buffer
        self.serial = serial
        self.dirty = dirty
        self.capturedAt = capturedAt
    }

    public var width: Int { CVPixelBufferGetWidth(buffer) }
    public var height: Int { CVPixelBufferGetHeight(buffer) }
    public var bounds: Rect { Rect(x: 0, y: 0, width: width, height: height) }

    /// Read access to the BGRA bytes (row stride may exceed width * 4).
    public func withPixels<T>(_ body: (UnsafePointer<UInt8>, Int) throws -> T) rethrows -> T {
        CVPixelBufferLockBaseAddress(buffer, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(buffer, .readOnly) }
        let base = CVPixelBufferGetBaseAddress(buffer)!.assumingMemoryBound(to: UInt8.self)
        return try body(UnsafePointer(base), CVPixelBufferGetBytesPerRow(buffer))
    }
}

/// A fresh BGRA pixel buffer, IOSurface-backed so VideoToolbox can take it without a copy.
public func makePixelBuffer(width: Int, height: Int) -> CVPixelBuffer? {
    var buffer: CVPixelBuffer?
    let attributes: [CFString: Any] = [kCVPixelBufferIOSurfacePropertiesKey: [:] as CFDictionary,
                                       kCVPixelBufferCGImageCompatibilityKey: true,
                                       kCVPixelBufferCGBitmapContextCompatibilityKey: true]
    CVPixelBufferCreate(kCFAllocatorDefault, width, height, kCVPixelFormatType_32BGRA, attributes as CFDictionary, &buffer)
    return buffer
}

/// Tiles (64 px) whose pixels differ between two BGRA buffers, coalesced; the whole frame when there
/// is no comparable previous buffer.
public func changedTiles(from previous: CVPixelBuffer?, to current: CVPixelBuffer, tile: Int = 64) -> [Rect] {
    let width = CVPixelBufferGetWidth(current), height = CVPixelBufferGetHeight(current)
    let bounds = Rect(x: 0, y: 0, width: width, height: height)
    guard let previous, CVPixelBufferGetWidth(previous) == width, CVPixelBufferGetHeight(previous) == height else { return [bounds] }
    CVPixelBufferLockBaseAddress(previous, .readOnly); CVPixelBufferLockBaseAddress(current, .readOnly)
    defer { CVPixelBufferUnlockBaseAddress(previous, .readOnly); CVPixelBufferUnlockBaseAddress(current, .readOnly) }
    guard let a = CVPixelBufferGetBaseAddress(previous), let b = CVPixelBufferGetBaseAddress(current) else { return [bounds] }
    let strideA = CVPixelBufferGetBytesPerRow(previous), strideB = CVPixelBufferGetBytesPerRow(current)
    var changed: [Rect] = []
    for top in stride(from: 0, to: height, by: tile) {
        for left in stride(from: 0, to: width, by: tile) {
            let w = min(tile, width - left), h = min(tile, height - top)
            for y in top ..< top + h where memcmp(a.advanced(by: y * strideA + left * 4), b.advanced(by: y * strideB + left * 4), w * 4) != 0 {
                changed.append(Rect(x: left, y: top, width: w, height: h))
                break
            }
        }
    }
    return coalesce(changed, within: bounds)
}
