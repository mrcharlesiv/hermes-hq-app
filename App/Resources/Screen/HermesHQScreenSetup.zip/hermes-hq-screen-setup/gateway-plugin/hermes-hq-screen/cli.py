"""``hermes hq-screen enable|disable|status|doctor|grant|stop``: run at the Mac by its owner.
``hermes dispatch-screen …`` (this plugin's old name) runs the same commands."""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

COMMAND = "hq-screen"
LEGACY_COMMAND = "dispatch-screen"
PLUGIN_NAME = "hermes-hq-screen"
LEGACY_PLUGIN_NAME = "dispatch-screen"

DESCRIPTION = """Share this Mac's screen with the Screen view of your Hermes bots in Hermes HQ.

  enable [--control] [--profiles all|a,b] [--max-width N] [--display ID] [--team-id ID] [--h264|--no-h264]
                     turn sharing on (add --control to let a phone take control)
  disable            turn sharing off, stop the helper, give control back to the agents
  status             settings, the helper and what blocks sharing
  doctor             check the plugin against this Hermes, the helper's signature and permissions
  grant              ask macOS for Screen Recording and Accessibility for Hermes HQ Screen
  stop               stop the helper now (it starts again when someone opens a Screen)"""


# Settings the helper takes as launch arguments (helper.launch_argv); allow_control is applied live.
LAUNCH_SETTINGS = ("max_width", "display", "h264", "idle_minutes", "helper_path")


def _load(name):
    import importlib.util
    key = f"hermes_hq_screen_{name}"
    if key not in sys.modules:
        spec = importlib.util.spec_from_file_location(key, Path(__file__).with_name(f"{name}.py"))
        module = importlib.util.module_from_spec(spec)
        sys.modules[key] = module
        spec.loader.exec_module(module)
    return sys.modules[key]


def setup(parser):
    sub = parser.add_subparsers(dest="hermes_hq_screen_command")
    enable = sub.add_parser("enable", help="turn screen sharing on")
    enable.add_argument("--control", action="store_true", help="let the viewer holding the lease control the Mac")
    enable.add_argument("--no-control", dest="control", action="store_false")
    enable.set_defaults(control=None)
    enable.add_argument("--profiles", help="'all' (default) or a comma-separated list of profile names")
    enable.add_argument("--max-width", type=int)
    enable.add_argument("--display", help="'main' or a CGDirectDisplayID")
    enable.add_argument("--team-id", action="append", dest="team_ids", help="allowed signing team (repeatable)")
    enable.add_argument("--helper-path", help="absolute path to the signed Hermes HQ Screen.app")
    enable.add_argument("--h264", action="store_true", default=None, help="stream H.264 (less bandwidth; verify on your phone first)")
    enable.add_argument("--no-h264", dest="h264", action="store_false")
    for name, text in [("disable", "turn screen sharing off"), ("status", "show sharing status"),
                       ("doctor", "check the setup"), ("grant", "ask macOS for the two permissions"),
                       ("stop", "stop the helper now")]:
        sub.add_parser(name, help=text)


def _release_revoked_holder(revoked) -> bool:
    """Hand control back when a person holds it through a revoked profile (or through a profile nobody
    recorded: fail safe). A person in control through a bot that keeps access keeps it."""
    from hermes_constants import hermes_home_key
    from tools.bot_desktop import lease
    adapter = _load("adapter")
    adapter.install_agent_side()
    held = lease.get()
    if held.holder != lease.HUMAN:
        return False
    key = adapter.holder_profile_key(held.viewer_id)
    if key is not None and key not in {hermes_home_key(home) for home in revoked}:
        return False
    # By holder: a takeover landing meanwhile is never revoked.
    return lease.release(viewer_id=held.viewer_id).holder == lease.AGENT


def _print(data):
    print(json.dumps(data, indent=2, sort_keys=True, default=str))


def run(args) -> int:
    helper = _load("helper")
    command = getattr(args, "hermes_hq_screen_command", None) or getattr(args, "dispatch_screen_command", None) or "status"
    if sys.platform != "darwin" and command not in ("status", "doctor"):
        print("Hermes HQ Screen shares a Mac's screen; this host is not a Mac.")
        return 1
    if command == "enable":
        values = {"enabled": True}
        if args.control is not None:
            values["allow_control"] = bool(args.control)
        if args.profiles:
            values["profiles"] = "all" if args.profiles.strip() == "all" else [p.strip() for p in args.profiles.split(",") if p.strip()]
        if args.max_width:
            values["max_width"] = max(640, int(args.max_width))
        if args.display:
            values["display"] = args.display
        if args.team_ids:
            values["team_ids"] = args.team_ids
        if getattr(args, "helper_path", None):
            values["helper_path"] = str(Path(args.helper_path).expanduser().resolve())
        if getattr(args, "h264", None) is not None:
            values["h264"] = bool(args.h264)
        before = helper.settings()
        current = helper.save_settings(values)
        running = helper.ctl({"cmd": "set", "allow_control": bool(current["allow_control"])}) is not None
        problem = helper.blocker(current, status=None)
        print("Screen sharing is on" + (" with control" if current["allow_control"] else " (watch only)")
              + f" for {'all bots' if current['profiles'] == 'all' else ', '.join(current['profiles'])}.")
        # The helper reads these only at launch: stop it, and the next Screen opened starts it with them.
        relaunch = [key for key in LAUNCH_SETTINGS if before.get(key) != current.get(key)]
        # Bots that just lost access lose it now: their socket links go, a person in control through one
        # of them hands control back, and their live streams are cut. The helper can't tell whose stream is
        # whose, so it restarts; the bots still allowed reconnect.
        revoked = helper.revoked_homes(before, current)
        if revoked:
            helper.remove_links(revoked)
            if _release_revoked_holder(revoked):
                print("Control handed back to the agents: it was held through a bot that no longer has access.")
        if (relaunch or revoked) and running:
            helper.ctl({"cmd": "stop"})
            if relaunch:
                print(f"Restarted the helper so the new {', '.join(relaunch)} apply (anyone watching reconnects).")
            if revoked:
                print(f"Disconnected everyone watching so {', '.join(helper.profile_name(home) for home in revoked)} lose access now"
                      " (bots that still have access reconnect).")
        if problem:
            print(f"Still needed: {problem}.")
        print("Restart hermes serve and hermes gateway once after installing the plugin, so every agent gets the shared lease.")
        return 0
    if command == "disable":
        helper.save_settings({"enabled": False})
        helper.ctl({"cmd": "stop"})
        helper.remove_links(helper.known_homes())
        from tools.bot_desktop import lease
        _load("adapter").install_agent_side()
        if lease.get().holder == lease.HUMAN:
            lease.release()
            print("Control handed back to the agents.")
        print("Screen sharing is off.")
        return 0
    if command == "stop":
        print("Stopped." if helper.ctl({"cmd": "stop"}) else "The helper was not running.")
        return 0
    if command == "grant":
        app = helper.app_path()
        if not app.exists():
            print(f"{app} is not installed: scripts/build-screen-helper.sh --install")
            return 1
        # Through LaunchServices so macOS asks for (and remembers) Hermes HQ Screen, not this terminal.
        control = bool(helper.settings().get("allow_control"))
        subprocess.run(["/usr/bin/open", "-W", "-n", "-a", str(app), "--args", "grant",
                        *(["--control"] if control else [])], check=False)
        print(f"Turn on {app.stem} under Screen & System Audio Recording"
              + (" and Accessibility" if control else "") + " in System Settings › Privacy & Security.")
        return 0
    current = helper.settings()
    live = helper.helper_status()
    report = {"settings": current, "helper": live, "blocker": helper.blocker(current, status=live), "state": str(helper.state_dir()),
              "app": str(helper.app_path(current))}
    if helper.app_path(current).name == helper.LEGACY_APP_NAME:
        report["legacy_app"] = True
    if helper.legacy_plugin_loaded():
        report["legacy_plugin_loaded"] = True
    if command == "doctor":
        adapter = _load("adapter")
        report["hermes_shapes"] = adapter.verify_shapes() or "ok"
        report["signature"] = helper.signature_problem(current) or "ok"
        binary = helper.binary(current)
        if binary.exists():
            try:
                out = subprocess.run([str(binary), "status", "--state", str(helper.state_dir())], capture_output=True, text=True, timeout=10)
                report["permissions"] = json.loads(out.stdout or "{}").get("tcc")
            except (OSError, ValueError, subprocess.SubprocessError) as exc:
                report["permissions"] = f"unknown ({exc})"
        try:
            from hermes_cli.plugins_cmd import _get_enabled_set
            enabled = _get_enabled_set()
            report["plugin_enabled"] = PLUGIN_NAME in enabled
            if LEGACY_PLUGIN_NAME in enabled:
                report["legacy_plugin_enabled"] = True
        except Exception:  # noqa: BLE001
            report["plugin_enabled"] = "unknown"
        if sys.platform == "darwin" and adapter.install_agent_side():
            # Processes started with a profile's HERMES_HOME (kanban workers, per-profile chats) never load
            # this plugin; their computer_use fence reads the profile's own copy, which serve keeps in step.
            report["profile_leases"] = adapter.profile_leases()
    _print(report)
    return 0
