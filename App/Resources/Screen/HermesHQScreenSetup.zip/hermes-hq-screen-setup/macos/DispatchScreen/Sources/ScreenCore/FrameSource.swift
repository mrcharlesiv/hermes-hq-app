import CoreGraphics
import CoreVideo
import Foundation

/// Where frames come from: ScreenCaptureKit on a real Mac, a synthetic pattern in tests.
public protocol FrameSource: AnyObject {
    /// Start delivering frames; `deliver` may be called on any thread.
    func start(deliver: @escaping (Frame) -> Void) throws
    func stop()
    /// One frame on demand while not streaming (the thumbnail of an unwatched screen).
    func snapshot() -> Frame?
    var name: String { get }
    /// Where the captured display sits in global screen points now, so pointer mapping follows a
    /// resolution or arrangement change and the display actually captured; nil = the server's option.
    var displayBounds: CGRect? { get }
}

extension FrameSource {
    public var displayBounds: CGRect? { nil }
}

/// A moving test pattern that needs no Screen Recording grant: a gradient, a box sweeping across it
/// and a frame counter. `--source test-pattern` and swift test use it.
public final class TestPatternSource: FrameSource {
    public let width: Int
    public let height: Int
    public let name = "test-pattern"
    private let interval: TimeInterval
    private var timer: DispatchSourceTimer?
    private var serial: UInt64 = 0
    private var previousBox: Rect?
    private let lock = NSLock()

    public init(width: Int = 1280, height: Int = 800, fps: Double = 10) {
        self.width = width & ~1
        self.height = height & ~1
        interval = 1 / max(1, fps)
    }

    public func start(deliver: @escaping (Frame) -> Void) throws {
        stop()
        let timer = DispatchSource.makeTimerSource(queue: DispatchQueue(label: "dispatch-screen.test-pattern"))
        timer.schedule(deadline: .now(), repeating: interval)
        timer.setEventHandler { [weak self] in
            if let frame = self?.next() { deliver(frame) }
        }
        lock.lock(); self.timer = timer; lock.unlock()
        timer.resume()
    }

    public func stop() {
        lock.lock(); let timer = self.timer; self.timer = nil; lock.unlock()
        timer?.cancel()
    }

    public func snapshot() -> Frame? { next() }

    /// The next frame, with the rects that changed since the previous one.
    public func next() -> Frame? {
        lock.lock(); defer { lock.unlock() }
        serial += 1
        guard let buffer = makePixelBuffer(width: width, height: height) else { return nil }
        let boxSize = max(16, height / 6)
        let travel = max(1, width - boxSize)
        let step = Int(serial * 24) % (2 * travel)
        let box = Rect(x: step < travel ? step : 2 * travel - step, y: height / 2 - boxSize / 2, width: boxSize, height: boxSize)
        CVPixelBufferLockBaseAddress(buffer, [])
        let base = CVPixelBufferGetBaseAddress(buffer)!.assumingMemoryBound(to: UInt8.self)
        let stride = CVPixelBufferGetBytesPerRow(buffer)
        for y in 0 ..< height {
            let row = base.advanced(by: y * stride)
            for x in 0 ..< width {
                let p = row.advanced(by: x * 4)
                let inBox = x >= box.x && x < box.maxX && y >= box.y && y < box.maxY
                p[0] = inBox ? 40 : UInt8(truncatingIfNeeded: 60 + y * 120 / height)   // B
                p[1] = inBox ? 200 : UInt8(truncatingIfNeeded: 40 + x * 100 / width)   // G
                p[2] = inBox ? 250 : 30                                                 // R
                p[3] = 255
            }
        }
        // The counter: the frame serial as 16 bits of black/white squares along the top edge.
        let cell = max(4, width / 64)
        for bit in 0 ..< 16 {
            let on = (serial >> UInt64(bit)) & 1 == 1
            for y in 0 ..< min(height, cell) {
                let row = base.advanced(by: y * stride)
                for x in bit * cell ..< min(width, (bit + 1) * cell) {
                    let p = row.advanced(by: x * 4)
                    p[0] = on ? 255 : 0; p[1] = on ? 255 : 0; p[2] = on ? 255 : 0
                }
            }
        }
        CVPixelBufferUnlockBaseAddress(buffer, [])
        let counter = Rect(x: 0, y: 0, width: min(width, 16 * cell), height: min(height, cell))
        let dirty = serial == 1 ? [Rect(x: 0, y: 0, width: width, height: height)] : [box.union(previousBox ?? box), counter]
        previousBox = box
        return Frame(buffer: buffer, serial: serial, dirty: dirty)
    }
}
