import AppKit
import CoreGraphics
import Foundation
import ScreenCore

// Hermes HQ Screen: shares this Mac's screen with Hermes' Bot Screen (the hermes-hq-screen gateway
// plugin launches it with `open -n -g -a "Hermes HQ Screen.app" --args serve …`, so macOS attributes
// Screen Recording and Accessibility to this app, not to the gateway's Python).
//
//   DispatchScreen serve [--state DIR] [--source screen|test-pattern] [--max-width N] [--display ID]
//                        [--control] [--allow-unlock] [--idle-minutes N] [--h264] [--real-input]
//   DispatchScreen grant [--control] ask for Screen Recording (and Accessibility for control)
//   DispatchScreen status    JSON: the running helper's status, or the permission preflight
//   DispatchScreen version

let usage = """
usage: DispatchScreen serve [--state DIR] [--source screen|test-pattern] [--max-width N] [--display ID]
                            [--control] [--allow-unlock] [--idle-minutes N] [--h264]
       DispatchScreen grant [--control] | status [--state DIR] | version
"""

struct Arguments {
    var command = "serve"
    var state = "~/.hermes/hermes-hq-screen"
    var source = "screen"
    var maxWidth = 1920
    var display: CGDirectDisplayID?
    var control = false
    var allowUnlock = false
    var idleMinutes = 30.0
    var realInput = false
    var h264 = false

    init(_ argv: [String]) {
        var rest = argv.dropFirst()
        if let first = rest.first, !first.hasPrefix("-") { command = first; rest = rest.dropFirst() }
        while let flag = rest.popFirst() {
            switch flag {
            case "--state": state = rest.popFirst() ?? state
            case "--source": source = rest.popFirst() ?? source
            case "--max-width": maxWidth = Int(rest.popFirst() ?? "") ?? maxWidth
            case "--display": display = rest.popFirst().flatMap { $0 == "main" ? nil : UInt32($0) }
            case "--control": control = true
            case "--allow-unlock": allowUnlock = true
            case "--idle-minutes": idleMinutes = Double(rest.popFirst() ?? "") ?? idleMinutes
            case "--real-input": realInput = true
            case "--h264": h264 = true
            default: FileHandle.standardError.write(Data("unknown option \(flag)\n\(usage)\n".utf8)); exit(64)
            }
        }
    }
}

func printJSON(_ object: [String: Any]) {
    let data = (try? JSONSerialization.data(withJSONObject: object, options: [.prettyPrinted, .sortedKeys])) ?? Data("{}".utf8)
    print(String(decoding: data, as: UTF8.self))
}

func permissions() -> (screen: Bool, events: Bool) { (CGPreflightScreenCaptureAccess(), CGPreflightPostEventAccess()) }

/// Discards input from the test pattern unless --real-input: a synthetic screen must never move the real pointer.
final class DiscardInput: InputSink { func perform(_ action: InputAction) {} }

let arguments = Arguments(CommandLine.arguments)

switch arguments.command {
case "version":
    print(ScreenHelper.version)
    exit(0)

case "grant":
    // Each call shows the macOS prompt once; afterwards the switches live in System Settings.
    let screen = CGRequestScreenCaptureAccess()
    let events = !arguments.control || CGRequestPostEventAccess()
    if !screen, let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture") { NSWorkspace.shared.open(url) }
    if !events, let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility") { NSWorkspace.shared.open(url) }
    print(screen && events ? "Screen Recording\(arguments.control ? " and Accessibility" : "") is allowed for Hermes HQ Screen."
          : "Turn on Hermes HQ Screen under Screen & System Audio Recording\(events ? "" : " and Accessibility") in System Settings › Privacy & Security, then run this again.")
    exit(screen && events ? 0 : 1)

case "status":
    let state = (arguments.state as NSString).expandingTildeInPath
    if let status = try? controlRequest(state + "/ctl.sock", ["cmd": "status"]) {
        printJSON(status)
    } else {
        let grants = permissions()
        printJSON(["ok": true, "running": false, "version": ScreenHelper.version, "tcc": ["screen": grants.screen, "events": grants.events]])
    }
    exit(0)

case "serve":
    break

default:
    FileHandle.standardError.write(Data("\(usage)\n".utf8))
    exit(64)
}

// MARK: serve

let stateDirectory: StateDirectory
do { stateDirectory = try StateDirectory(path: arguments.state) } catch {
    FileHandle.standardError.write(Data("cannot use state directory \(arguments.state): \(error)\n".utf8)); exit(1)
}
guard stateDirectory.acquireSingleInstance() else {
    print("Hermes HQ Screen is already running for \(stateDirectory.url.path)")
    exit(0)
}

let testPattern = arguments.source == "test-pattern"
let source: FrameSource
let capture: ScreenCaptureSource?
if testPattern {
    source = TestPatternSource(width: min(arguments.maxWidth, 1280), height: min(arguments.maxWidth, 1280) * 10 / 16)
    capture = nil
} else {
    let screen = ScreenCaptureSource(maxWidth: arguments.maxWidth, displayID: arguments.display)
    screen.log = stateDirectory.log
    source = screen
    capture = screen
}
if !testPattern { Keysyms.activeLayout = currentLayoutTable() }
let input: InputSink = testPattern && !arguments.realInput ? DiscardInput() : EventInput()
let displayFrame = CGDisplayBounds(arguments.display ?? CGMainDisplayID())
let server = RFBServer(source: source, input: input,
                       options: .init(name: Host.current().localizedName ?? "This Mac", allowControl: arguments.control,
                                      allowUnlock: arguments.allowUnlock, displayFrame: displayFrame, h264: arguments.h264))
server.isLocked = testPattern ? { false } : screenIsLocked
server.log = stateDirectory.log
let helper = ScreenHelper(server: server, stateDir: stateDirectory.url)
helper.permissions = testPattern ? { (true, true) } : permissions
helper.secureInput = testPattern ? { false } : secureInputEnabled
server.setPaused(FileManager.default.fileExists(atPath: helper.pausedFile.path))
// Stop in macOS's own recording indicator is the person at the Mac saying stop: the same as Stop
// sharing (persisted until resumed at the Mac). Any other end of the stream drops the viewers; the next
// one starts a fresh capture.
capture?.onStopped = { reason, userStopped in
    if userStopped { helper.setSharingPaused(true) }
    server.captureFailed(reason)
}

var control: ControlServer?
func shutdown(_ code: Int32 = 0) {
    stateDirectory.log("stopping")
    control?.close()
    server.stop()
    stateDirectory.releaseSingleInstance()
    exit(code)
}
helper.onStop = { DispatchQueue.main.async { shutdown() } }

do {
    try server.listen(path: stateDirectory.rfbSocket)
    control = try ControlServer(path: stateDirectory.controlSocket, handle: helper.handle)
} catch {
    stateDirectory.log("cannot listen: \(error)")
    FileHandle.standardError.write(Data("cannot listen: \(error)\n".utf8))
    shutdown(1)
}
stateDirectory.log("serving \(source.name) (control \(arguments.control ? "allowed" : "off")) pid \(getpid())")

var retainedSignalSources: [DispatchSourceSignal] = []
for signalNumber in [SIGTERM, SIGINT, SIGHUP] {
    signal(signalNumber, SIG_IGN)
    let handler = DispatchSource.makeSignalSource(signal: signalNumber, queue: .main)
    handler.setEventHandler { shutdown() }
    handler.resume()
    retainedSignalSources.append(handler)
}

// Idle exit: nobody watched for idle_minutes; the plugin relaunches the helper when it is needed.
var lastViewer = Date()
let idleTimer = DispatchSource.makeTimerSource(queue: .main)
idleTimer.schedule(deadline: .now() + 30, repeating: 30)
idleTimer.setEventHandler {
    if server.clientCount > 0 { lastViewer = Date() }
    else if arguments.idleMinutes > 0, Date().timeIntervalSince(lastViewer) > arguments.idleMinutes * 60 { shutdown() }
}
idleTimer.resume()

if testPattern {
    dispatchMain()
} else {
    let app = NSApplication.shared
    app.setActivationPolicy(.accessory)
    let menuBar = MenuBar(helper: helper)
    let refresh = { DispatchQueue.main.async { menuBar.refresh() } }
    server.onClientsChanged = { _ in refresh() }
    helper.onChange = refresh
    app.run()
}
