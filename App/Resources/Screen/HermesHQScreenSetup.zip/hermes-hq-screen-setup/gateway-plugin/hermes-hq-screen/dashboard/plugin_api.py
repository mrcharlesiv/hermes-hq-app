"""Mounted by ``hermes serve`` (``/api/plugins/hermes-hq-screen``): installs the Bot Screen backend in
the process that answers ``display.*`` and bridges ``/api/display/ws``, and runs the repaint /
orphaned-lease loop (watch.py)."""
import importlib.util
import logging
import sys
import threading
import time
from pathlib import Path

from fastapi import APIRouter

log = logging.getLogger("hermes-hq-screen")
_ROOT = Path(__file__).parents[1]


def _load(name):
    key = f"hermes_hq_screen_{name}"
    if key not in sys.modules:
        spec = importlib.util.spec_from_file_location(key, _ROOT / f"{name}.py")
        module = importlib.util.module_from_spec(spec)
        sys.modules[key] = module
        spec.loader.exec_module(module)
    return sys.modules[key]


helper = _load("helper")
adapter = _load("adapter")
installed = sys.platform == "darwin" and adapter.install_serve_side(helper)
router = APIRouter()


def _served_homes():
    server = sys.modules.get("tui_gateway.server")
    homes = {Path(helper.root())}
    if server is not None:
        homes |= {Path(p) for p in getattr(server, "_served_profile_homes", set())}
    return sorted(homes)


def _broadcast(event, payload):
    server = sys.modules.get("tui_gateway.server")
    send = getattr(server, "_broadcast_global_event", None) if server else None
    if send:
        send(event, payload)


def _snapshot(home):
    server = sys.modules.get("tui_gateway.server")
    snapshot = getattr(server, "_display_snapshot", None) if server else None
    if snapshot is None:
        return None
    from hermes_constants import reset_hermes_home_override, set_hermes_home_override
    token = set_hermes_home_override(home)
    try:
        return snapshot()
    except Exception:  # noqa: BLE001
        return None
    finally:
        reset_hermes_home_override(token)


def _loop():
    watcher = _load("watch").Watcher(helper, homes=_served_homes, broadcast=_broadcast, snapshot=_snapshot,
                                     mirror=adapter.mirror_lease)
    try:  # codesign takes seconds once per helper build: warm it here, never inside a Screen's RPC
        helper.signature_problem()
    except Exception:  # noqa: BLE001
        log.debug("hermes-hq-screen signature warm-up failed", exc_info=True)
    routed = False
    while True:
        try:
            adapter.retire_legacy()  # an old dispatch-screen mounted after this one patched over it
            routed = routed or adapter.route_display_off_the_socket()
            watcher.tick()
        except Exception:  # noqa: BLE001 - the loop must outlive a torn read
            log.debug("hermes-hq-screen watch tick failed", exc_info=True)
        time.sleep(1.0)


if installed:
    threading.Thread(target=_loop, name="hermes-hq-screen-watch", daemon=True).start()


@router.get("/health")
def health():
    """The plugin's view of the Mac screen backend (behind the dashboard login)."""
    current = helper.settings()
    live = helper.helper_status()
    return {"ok": True, "installed": bool(installed), "platform": sys.platform,
            "drift": [] if installed else adapter.verify_shapes(), "enabled": bool(current.get("enabled")),
            "control": bool(current.get("allow_control")), "profiles": current.get("profiles"),
            "blocker": helper.blocker(current, status=live), "helper": live,
            "legacy_plugin_loaded": helper.legacy_plugin_loaded(), "legacy_app": helper.app_path(current).name == helper.LEGACY_APP_NAME}
