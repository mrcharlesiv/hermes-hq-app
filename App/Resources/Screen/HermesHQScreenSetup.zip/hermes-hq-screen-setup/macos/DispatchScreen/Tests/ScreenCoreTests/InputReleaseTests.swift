import XCTest
@testable import ScreenCore

/// What is still pressed after these actions (an auto-repeated key-down needs only one key-up).
private func stillDown(_ actions: [InputAction]) -> [String] {
    var pressed: [String: Bool] = [:]
    for action in actions {
        switch action {
        case let .key(code, isDown, _): pressed["key \(code)"] = isDown
        case let .text(text, isDown): pressed["text \(text)"] = isDown
        case let .button(button, isDown, _, _, _): pressed["button \(button)"] = isDown
        default: break
        }
    }
    return pressed.filter { $0.value }.map(\.key).sorted()
}

/// r1-28: a viewer that drops between a key's down and up must leave nothing pressed on the Mac. Every
/// down the translator hands the sink (a virtual key, typed text, a button) gets its up by releaseAll.
final class InputReleaseTests: XCTestCase {
    private func perform(_ actions: [InputAction], on sink: RecordingSink) { actions.forEach(sink.perform) }

    func testSpecialKeysTextAndShortcutsAreAllReleasedWhenTheViewerDrops() {
        var translator = InputTranslator()
        let sink = RecordingSink()
        // Backspace, ← and Return held (a key repeat of ← on the way), text mid-press, ⌘ with a shortcut
        // letter down, and the left button mid-drag: the viewer drops before any key-up arrives.
        for keysym: UInt32 in [0xff08, 0xff51, 0xff51, 0xff0d, 0x61, 0x01004f60, 0xffe7, 0x76] { perform(translator.key(keysym, down: true), on: sink) }
        perform(translator.pointer(mask: 1, x: 5, y: 5, scale: { ($0, $1) }, time: 0), on: sink)
        XCTAssertEqual(stillDown(sink.snapshot).count, 8, "⌫ ← ↩ a 你 ⌘ v and the left button")
        perform(translator.releaseAll(x: 0, y: 0), on: sink)
        XCTAssertEqual(stillDown(sink.snapshot), [], "every down has its up")
        XCTAssertEqual(translator.releaseAll(x: 0, y: 0), [], "nothing is released twice")
    }

    func testAKeyReleasedNormallyIsNotReleasedAgain() {
        var translator = InputTranslator()
        let sink = RecordingSink()
        for (keysym, down) in [(UInt32(0xff08), true), (0xff08, false), (0x61, true), (0x61, false), (0xff0d, true)] {
            perform(translator.key(keysym, down: down), on: sink)
        }
        let release = translator.releaseAll(x: 0, y: 0)
        XCTAssertEqual(release, [.key(code: 36, down: false, flags: [])], "only Return was still down")
        perform(release, on: sink)
        XCTAssertEqual(stillDown(sink.snapshot), [])
    }
}

/// r6-77: the bridge forwards a key-down or button just as the person hands back. The helper lifted what was
/// held, then its reader applied the event already on the socket, and the bridge dropped the matching key-up
/// (the person no longer holds the lease): the agent worked with a key or button down until the watcher's
/// next tick. Input is now refused once the agent holds, checked in the same critical section as the post.
final class HandBackInputTests: XCTestCase {
    var directory: String!
    var server: RFBServer!

    override func setUp() { directory = NSTemporaryDirectory() + "dsh-\(UUID().uuidString.prefix(8))" }

    override func tearDown() {
        server?.stop()
        try? FileManager.default.removeItem(atPath: directory)
    }

    private func serve(_ sink: InputSink) throws -> (TestClient, ScreenHelper) {
        server = RFBServer(source: TestPatternSource(width: 320, height: 200, fps: 30), input: sink,
                           options: .init(name: "Test Mac", allowControl: true, displayFrame: CGRect(x: 0, y: 0, width: 640, height: 400), h264: false))
        let path = directory + "/rfb.sock"
        try server.listen(path: path)
        let client = try TestClient(path)
        try client.handshake()
        return (client, ScreenHelper(server: server, stateDir: URL(fileURLWithPath: directory)))
    }

    func testInputForwardedBeforeAHandBackIsRefusedAfterIt() throws {
        let sink = RecordingSink()
        let (client, helper) = try serve(sink)
        _ = helper.handle(["cmd": "set", "human_control": true, "release_input": true])
        try client.key(0xffe3, true); try client.pointer(1, 20, 20); try client.roundTrip()
        XCTAssertEqual(stillDown(sink.snapshot), ["button left", "key 59"], "the person's Ctrl and drag are applied")
        _ = helper.handle(["cmd": "set", "human_control": false, "release_input": true])
        XCTAssertEqual(stillDown(sink.snapshot), [], "the hand-back lifts them")
        let count = sink.snapshot.count
        // Already on the socket when the person handed back: ⌘ down, the right button, a letter.
        try client.key(0xffe7, true); try client.pointer(4, 30, 30); try client.key(0x61, true)
        try client.roundTrip()
        XCTAssertEqual(sink.snapshot.count, count, "refused: the agent holds control")
        XCTAssertEqual(stillDown(sink.snapshot), [], "nothing stays held under the agent")
        XCTAssertEqual(helper.status()["human_control"] as? Bool, false)
        // The next takeover's notice comes before the acquire answers the phone: its first events apply.
        _ = helper.handle(["cmd": "set", "human_control": true, "release_input": true])
        try client.key(0xffe7, true); try client.roundTrip()
        XCTAssertEqual(sink.snapshot.last, .key(code: 55, down: true, flags: .command))
        try client.key(0xffe7, false); try client.roundTrip()
        XCTAssertEqual(stillDown(sink.snapshot), [])
        // A paste already on the socket at a hand-back is refused too, and drops the viewer (RD-18): the ⌘V
        // behind it must never meet the next takeover's open gate and paste what the Mac's clipboard held.
        _ = helper.handle(["cmd": "set", "human_control": false, "release_input": true])
        let before = sink.snapshot.count
        try client.clipboard("pw")
        XCTAssertThrowsError(try client.connection.readByte())
        _ = helper.handle(["cmd": "set", "human_control": true, "release_input": true])
        try? client.key(0xffe7, true); try? client.key(0x76, true)
        let deadline = Date().addingTimeInterval(2)
        while server.clientCount > 0, Date() < deadline { usleep(20_000) }
        XCTAssertEqual(server.clientCount, 0)
        XCTAssertEqual(sink.snapshot.count, before, "neither the clipboard nor the ⌘V lands")
    }

    /// The hand-back arrives while a key-down is being posted and another key-down is queued behind it:
    /// whichever order the reader and the hand-back take the input lock in, nothing is left down.
    func testAHandBackRacingInFlightInputLeavesNothingHeld() throws {
        let gate = GatedSink()
        let (client, helper) = try serve(gate)
        _ = helper.handle(["cmd": "set", "human_control": true, "release_input": true])
        try client.key(0xff0d, true)  // Return down: its post is held in the sink
        XCTAssertEqual(gate.entered.wait(timeout: .now() + 2), .success, "the reader is posting the key-down")
        let handedBack = expectation(description: "handed back")
        DispatchQueue.global().async {
            _ = helper.handle(["cmd": "set", "human_control": false, "release_input": true])
            handedBack.fulfill()
        }
        try client.key(0xffe3, true)  // Ctrl down, forwarded just before the hand-back
        usleep(150_000)
        gate.proceed.signal()
        wait(for: [handedBack], timeout: 3)
        try client.roundTrip()
        XCTAssertEqual(stillDown(gate.recorder.snapshot), [], "Return and Ctrl are either lifted or never posted")
        // Its flags depend on the order: ⌃ when the reader posted Ctrl before the hand-back took the lock.
        XCTAssertTrue(gate.recorder.snapshot.contains { if case .key(36, false, _) = $0 { return true }; return false }, "the posted Return is lifted")
    }
}
