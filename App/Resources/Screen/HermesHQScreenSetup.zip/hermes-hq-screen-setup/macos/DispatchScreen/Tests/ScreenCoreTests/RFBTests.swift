import CoreGraphics
import CoreMedia
import ImageIO
import VideoToolbox
import XCTest
@testable import ScreenCore

/// A minimal RFB client over the helper's Unix socket.
final class TestClient {
    let connection: SocketConnection
    var width = 0, height = 0, name = ""
    var serverFormat: [UInt8] = []

    init(_ path: String) throws { connection = try connectUnix(path) }

    func handshake() throws {
        XCTAssertEqual(String(decoding: try connection.read(12), as: UTF8.self), "RFB 003.008\n")
        try connection.write(Array("RFB 003.008\n".utf8))
        XCTAssertEqual(try connection.read(2), [1, 1], "exactly one security type: None")
        try connection.write([1])
        XCTAssertEqual(try connection.read(4), [0, 0, 0, 0])
        try connection.write([1])  // shared
        let head = try connection.read(24)
        width = Int(head.u16(0)); height = Int(head.u16(2))
        serverFormat = Array(head[4 ..< 20])
        name = String(decoding: try connection.read(Int(head.u32(20))), as: UTF8.self)
    }

    func setEncodings(_ list: [Int32]) throws {
        var message: [UInt8] = [2, 0]
        message.put16(UInt16(list.count))
        for e in list { message.putS32(e) }
        try connection.write(message)
    }

    func setPixelFormat(_ format: PixelFormat) throws { try connection.write([0, 0, 0, 0] + format.bytes) }

    func request(incremental: Bool, width w: Int? = nil, height h: Int? = nil) throws {
        var message: [UInt8] = [3, incremental ? 1 : 0]
        message.put16(0); message.put16(0); message.put16(UInt16(w ?? width)); message.put16(UInt16(h ?? height))
        try connection.write(message)
    }

    struct Update { var rects: [(rect: Rect, encoding: Int32, data: [UInt8])] }

    /// Reads one FramebufferUpdate, decoding rect payload lengths for the encodings this server sends.
    func readUpdate(format: PixelFormat = .native) throws -> Update {
        XCTAssertEqual(try connection.readByte(), 0, "FramebufferUpdate")
        let head = try connection.read(3)
        var update = Update(rects: [])
        for _ in 0 ..< Int(head.u16(1)) {
            let r = try connection.read(12)
            let rect = Rect(x: Int(r.u16(0)), y: Int(r.u16(2)), width: Int(r.u16(4)), height: Int(r.u16(6)))
            let encoding = r.s32(8)
            var data: [UInt8] = []
            switch encoding {
            case Encoding.raw: data = try connection.read(rect.area * format.bytesPerPixel)
            case Encoding.tight:
                let ctl = try connection.readByte()
                data = [ctl]
                if ctl == 0x80 { data += try connection.read(format.tightPixelIsRGB ? 3 : format.bytesPerPixel) }
                else {
                    // Compact length: 7 bits, 7 bits, then a whole third byte (noVNC and TigerVNC read it so).
                    var length = 0
                    for index in 0 ..< 3 {
                        let byte = try connection.readByte()
                        length |= Int(index == 2 ? byte : byte & 0x7f) << (7 * index)
                        if index < 2, byte & 0x80 == 0 { break }
                    }
                    data += try connection.read(length)
                }
            case Encoding.h264:
                let h = try connection.read(8)
                data = h + (try connection.read(Int(h.u32(0))))
            case Encoding.extendedDesktopSize: data = try connection.read(4 + 16)
            case Encoding.desktopSize: data = []
            default: XCTFail("unexpected encoding \(encoding)")
            }
            update.rects.append((rect, encoding, data))
        }
        return update
    }

    /// Nothing more arrives within `seconds`.
    func assertQuiet(_ seconds: Double, file: StaticString = #filePath, line: UInt = #line) {
        var tv = timeval(tv_sec: 0, tv_usec: Int32(seconds * 1_000_000))
        setsockopt(connection.fd, SOL_SOCKET, SO_RCVTIMEO, &tv, socklen_t(MemoryLayout<timeval>.size))
        var byte: UInt8 = 0
        let n = recv(connection.fd, &byte, 1, MSG_PEEK)
        XCTAssertTrue(n < 0, "server sent unsolicited bytes (first byte \(byte))", file: file, line: line)
        var off = timeval(tv_sec: 0, tv_usec: 0)
        setsockopt(connection.fd, SOL_SOCKET, SO_RCVTIMEO, &off, socklen_t(MemoryLayout<timeval>.size))
    }

    func pointer(_ mask: UInt8, _ x: Int, _ y: Int) throws {
        var message: [UInt8] = [5, mask]; message.put16(UInt16(x)); message.put16(UInt16(y))
        try connection.write(message)
    }

    func key(_ keysym: UInt32, _ down: Bool) throws {
        var message: [UInt8] = [4, down ? 1 : 0, 0, 0]; message.put32(keysym)
        try connection.write(message)
    }

    func clipboard(_ text: String) throws {
        var message: [UInt8] = [6, 0, 0, 0]
        message.put32(UInt32(text.utf8.count)); message += text.utf8
        try connection.write(message)
    }

    /// A full update round trip: every message sent before it has been applied.
    func roundTrip() throws { try request(incremental: false); _ = try readUpdate() }
}

/// Counts on-demand grabs (the thumbnail rate limit).
final class CountingSource: FrameSource {
    let inner: TestPatternSource
    var snapshots = 0
    var name: String { inner.name }
    init(_ inner: TestPatternSource) { self.inner = inner }
    func start(deliver: @escaping (Frame) -> Void) throws { try inner.start(deliver: deliver) }
    func stop() { inner.stop() }
    func snapshot() -> Frame? { snapshots += 1; return inner.snapshot() }
}

/// A source that reports where its display sits now (a resolution or arrangement change).
final class MovingDisplaySource: FrameSource {
    let inner = TestPatternSource(width: 320, height: 200, fps: 30)
    var bounds: CGRect?
    var name: String { inner.name }
    var displayBounds: CGRect? { bounds }
    func start(deliver: @escaping (Frame) -> Void) throws { try inner.start(deliver: deliver) }
    func stop() { inner.stop() }
    func snapshot() -> Frame? { inner.snapshot() }
}

/// The same frame of seeded noise on every delivery: at JPEG quality 100 it stays past Tight's 4 MiB length.
final class NoiseSource: FrameSource {
    let frame: Frame
    let name = "noise"
    private var timer: DispatchSourceTimer?

    init(width: Int, height: Int) {
        let buffer = makePixelBuffer(width: width, height: height)!
        CVPixelBufferLockBaseAddress(buffer, [])
        let base = CVPixelBufferGetBaseAddress(buffer)!.assumingMemoryBound(to: UInt8.self)
        let stride = CVPixelBufferGetBytesPerRow(buffer)
        var state: UInt64 = 0x9E37_79B9_7F4A_7C15
        for y in 0 ..< height {
            let row = base.advanced(by: y * stride)
            for x in 0 ..< width {
                state ^= state << 13; state ^= state >> 7; state ^= state << 17
                row[x * 4] = UInt8(truncatingIfNeeded: state); row[x * 4 + 1] = UInt8(truncatingIfNeeded: state >> 8)
                row[x * 4 + 2] = UInt8(truncatingIfNeeded: state >> 16); row[x * 4 + 3] = 255
            }
        }
        CVPixelBufferUnlockBaseAddress(buffer, [])
        frame = Frame(buffer: buffer, serial: 1, dirty: [Rect(x: 0, y: 0, width: width, height: height)])
    }

    func start(deliver: @escaping (Frame) -> Void) throws {
        let timer = DispatchSource.makeTimerSource(queue: DispatchQueue(label: "noise"))
        timer.schedule(deadline: .now(), repeating: 0.5)
        timer.setEventHandler { [frame] in deliver(frame) }
        self.timer = timer
        timer.resume()
    }
    func stop() { timer?.cancel(); timer = nil }
    func snapshot() -> Frame? { frame }
}

/// Holds the first key-down inside perform, as a slow CGEventPost would, until the test lets it go.
final class GatedSink: InputSink {
    let recorder = RecordingSink()
    let entered = DispatchSemaphore(value: 0), proceed = DispatchSemaphore(value: 0)
    private let lock = NSLock()
    private var armed = true

    func perform(_ action: InputAction) {
        lock.lock()
        var hold = false
        if armed, case .key(_, true, _) = action { armed = false; hold = true }
        lock.unlock()
        if hold { entered.signal(); proceed.wait() }
        recorder.perform(action)
    }
}

final class ClipboardGate: InputSink {
    let recorder = RecordingSink()
    let entered = DispatchSemaphore(value: 0), proceed = DispatchSemaphore(value: 0)
    func perform(_ action: InputAction) {
        if case .pasteboard = action {
            entered.signal()
            XCTAssertEqual(proceed.wait(timeout: .now() + 3), .success)
        }
        recorder.perform(action)
    }
}

final class DeferredClipboardSink: InputMutationExecutor {
    let recorder = RecordingSink()
    let entered = DispatchSemaphore(value: 0), proceed = DispatchSemaphore(value: 0)
    var finished: (() -> Void)?
    func executeMutation(_ body: () -> Void) {
        entered.signal()
        XCTAssertEqual(proceed.wait(timeout: .now() + 3), .success)
        body()
        finished?()
    }
    func perform(_ action: InputAction) { recorder.perform(action) }
}

final class ControlledSource: FrameSource {
    let inner = TestPatternSource(width: 320, height: 200, fps: 30)
    let entered = DispatchSemaphore(value: 0), proceed = DispatchSemaphore(value: 0), stopped = DispatchSemaphore(value: 0)
    var block = false
    private let lock = NSLock()
    private var shouldFail = true
    var name: String { "controlled" }
    func allowStart() { lock.lock(); shouldFail = false; lock.unlock() }
    func start(deliver: @escaping (Frame) -> Void) throws {
        entered.signal()
        if block { XCTAssertEqual(proceed.wait(timeout: .now() + 4), .success) }
        lock.lock(); let fail = shouldFail; lock.unlock()
        if fail { throw SocketError.system("chosen display is missing", ENODEV) }
        try inner.start(deliver: deliver)
    }
    func stop() { inner.stop(); stopped.signal() }
    func snapshot() -> Frame? { inner.snapshot() }
}

final class RFBTests: XCTestCase {
    var directory: String!
    var server: RFBServer!
    var sink: RecordingSink!
    var locked = false

    override func setUp() {
        directory = NSTemporaryDirectory() + "ds-\(UUID().uuidString.prefix(8))"
        sink = RecordingSink()
        locked = false
    }

    override func tearDown() {
        server?.stop()
        try? FileManager.default.removeItem(atPath: directory)
    }

    /// `human`: a person holds the control lease, as the plugin tells the helper (input is refused otherwise).
    func start(control: Bool = true, human: Bool = true, h264: Bool = false, source: FrameSource = TestPatternSource(width: 320, height: 200, fps: 30), input: InputSink? = nil, configure: (inout RFBServer.Options) -> Void = { _ in }) throws -> String {
        server = RFBServer(source: source, input: input ?? sink, options: .init(name: "Test Mac", allowControl: control, displayFrame: CGRect(x: 0, y: 0, width: 640, height: 400), h264: h264))
        server.update(configure)
        server.setHumanControl(human)
        server.isLocked = { [unowned self] in locked }
        let path = directory + "/rfb.sock"
        try server.listen(path: path)
        return path
    }

    func testHandshakeServerInitAndPrivateSocket() throws {
        let path = try start()
        var info = stat()
        stat(path, &info)
        XCTAssertEqual(info.st_mode & 0o777, 0o600)
        stat(directory, &info)
        XCTAssertEqual(info.st_mode & 0o777, 0o700)
        let client = try TestClient(path)
        try client.handshake()
        XCTAssertEqual([client.width, client.height], [320, 200])
        XCTAssertEqual(client.serverFormat, PixelFormat.native.bytes)
        XCTAssertEqual(client.name, "Test Mac")
        XCTAssertEqual(server.clientCount, 1)
        XCTAssertTrue(server.isCapturing, "capture runs while a viewer is connected")
    }

    func testSetPixelFormatAndRaw() throws {
        let client = try TestClient(try start())
        try client.handshake()
        // noVNC's format: little-endian RGBX.
        let rgbx = PixelFormat(bitsPerPixel: 32, depth: 24, bigEndian: false, trueColor: true, redMax: 255, greenMax: 255, blueMax: 255, redShift: 0, greenShift: 8, blueShift: 16)
        try client.setPixelFormat(rgbx)
        try client.setEncodings([Encoding.raw])
        try client.request(incremental: false)
        let update = try client.readUpdate(format: rgbx)
        XCTAssertEqual(update.rects.count, 1)
        XCTAssertEqual(update.rects[0].rect, Rect(x: 0, y: 0, width: 320, height: 200))
        let pixel = Array(update.rects[0].data[(199 * 320 + 10) * 4 ..< (199 * 320 + 10) * 4 + 4])
        XCTAssertEqual(pixel, [30, UInt8(40 + 10 * 100 / 320), UInt8(60 + 199 * 120 / 200), 0], "B/G/R gradient as R,G,B,X")
        // 16-bit big-endian RGB565 is converted too.
        let rgb565 = PixelFormat(bitsPerPixel: 16, depth: 16, bigEndian: true, trueColor: true, redMax: 31, greenMax: 63, blueMax: 31, redShift: 11, greenShift: 5, blueShift: 0)
        try client.setPixelFormat(rgb565)
        try client.request(incremental: false)
        let small = try client.readUpdate(format: rgb565)
        XCTAssertEqual(small.rects[0].data.count, 320 * 200 * 2)
    }

    func testTightJPEGAndIncrementalUpdates() throws {
        let client = try TestClient(try start())
        try client.handshake()
        try client.setEncodings([Encoding.tight, Encoding.raw, -25])  // QualityLevel 7
        try client.request(incremental: false)
        let full = try client.readUpdate()
        XCTAssertEqual(full.rects.count, 1)
        XCTAssertEqual(full.rects[0].encoding, Encoding.tight)
        XCTAssertEqual(full.rects[0].data[0], 0x90, "JPEG subencoding")
        let jpeg = Data(full.rects[0].data.dropFirst())
        let source = CGImageSourceCreateWithData(jpeg as CFData, nil)!
        let image = CGImageSourceCreateImageAtIndex(source, 0, nil)!
        XCTAssertEqual([image.width, image.height], [320, 200])
        try client.request(incremental: true)
        let next = try client.readUpdate()
        XCTAssertFalse(next.rects.isEmpty)
        XCTAssertLessThan(next.rects.map { $0.rect.area }.reduce(0, +), 320 * 200, "only what changed")
        XCTAssertEqual(tightLength(100), [100]); XCTAssertEqual(tightLength(1000), [0xe8, 0x07]); XCTAssertEqual(tightLength(100_000), [0xa0, 0x8d, 0x06])
    }

    /// r6-76: a JPEG of 4 MiB or more has no Tight length; building one trapped the helper (a checked UInt8
    /// of the top bits), killing every viewer's stream. It is sent as row bands that each fit instead.
    func testATightJPEGTooLongForItsLengthIsSentAsBandsNotATrap() throws {
        XCTAssertEqual(tightLength(tightMaxLength), [0xff, 0xff, 0xff])
        XCTAssertNil(tightLength(tightMaxLength + 1)); XCTAssertNil(tightLength(8 << 20)); XCTAssertNil(tightLength(-1))
        let source = NoiseSource(width: 2048, height: 1280)
        let whole = try XCTUnwrap(jpegData(source.frame, source.frame.bounds, quality: 100))
        XCTAssertGreaterThan(whole.count, tightMaxLength, "the full-frame JPEG that used to trap")
        let client = try TestClient(try start(source: source))
        try client.handshake()
        try client.setEncodings([Encoding.tight, Encoding.raw, -23])  // QualityLevel 9: JPEG 100
        try client.request(incremental: false)
        let update = try client.readUpdate()
        XCTAssertGreaterThan(update.rects.count, 1)
        var nextY = 0
        for (rect, encoding, data) in update.rects {
            XCTAssertEqual(encoding, Encoding.tight)
            XCTAssertEqual(data[0], 0x90, "JPEG, not a Raw fallback of the whole screen")
            XCTAssertEqual([rect.x, rect.y, rect.width], [0, nextY, 2048], "bands tile the frame top to bottom")
            nextY = rect.maxY
            let jpeg = Data(data.dropFirst())
            XCTAssertLessThanOrEqual(jpeg.count, tightMaxLength)
            let image = try XCTUnwrap(CGImageSourceCreateImageAtIndex(CGImageSourceCreateWithData(jpeg as CFData, nil)!, 0, nil))
            XCTAssertEqual([image.width, image.height], [rect.width, rect.height])
        }
        XCTAssertEqual(nextY, 1280)
        try client.request(incremental: false)
        XCTAssertEqual(try client.readUpdate().rects.count, update.rects.count, "the helper is still serving")
    }

    func testH264IsOptInAndPrefersTightOtherwise() throws {
        let client = try TestClient(try start())
        try client.handshake()
        try client.setEncodings([Encoding.h264, Encoding.tight, Encoding.raw, -25])
        try client.request(incremental: false)
        XCTAssertEqual(try client.readUpdate().rects.map(\.encoding), [Encoding.tight])
    }

    func testH264DecodesAndContinues() throws {
        let client = try TestClient(try start(h264: true))
        try client.handshake()
        try client.setEncodings([Encoding.h264, Encoding.tight, Encoding.raw, -25])
        try client.request(incremental: false)
        let first = try client.readUpdate()
        XCTAssertEqual(first.rects.count, 1)
        XCTAssertEqual(first.rects[0].encoding, Encoding.h264)
        XCTAssertEqual(first.rects[0].rect, Rect(x: 0, y: 0, width: 320, height: 200))
        let flags = first.rects[0].data.u32(4)
        XCTAssertEqual(flags, 1, "a new stream resets the client's decoder context")
        let key = Array(first.rects[0].data.dropFirst(8))
        let units = nalUnits(key)
        XCTAssertEqual(Array(units.map { $0[0] & 0x1f }.prefix(2)), [7, 8], "SPS and PPS lead the keyframe")
        XCTAssertTrue(units.contains { $0[0] & 0x1f == 5 }, "an IDR slice")
        let decoder = try H264TestDecoder(units)
        XCTAssertEqual(try decoder.decode(units), CGSize(width: 320, height: 200))
        try client.request(incremental: true)
        let second = try client.readUpdate()
        XCTAssertEqual(second.rects[0].data.u32(4), 0)
        let delta = nalUnits(Array(second.rects[0].data.dropFirst(8)))
        XCTAssertTrue(delta.contains { $0[0] & 0x1f == 1 }, "a P slice continues the stream")
        XCTAssertEqual(try decoder.decode(delta), CGSize(width: 320, height: 200))
    }

    func testNeverAcknowledgedPseudoEncodings() throws {
        let client = try TestClient(try start())
        try client.handshake()
        try client.setEncodings([Encoding.raw, -316, -309, -313, -312, Encoding.desktopSize, Encoding.extendedDesktopSize, -224])
        try client.request(incremental: false)
        let update = try client.readUpdate()
        XCTAssertEqual(update.rects.map(\.encoding), [Encoding.raw])
        // EnableContinuousUpdates and a Fence are read and ignored: no EndOfContinuousUpdates (150), no Fence (248).
        var continuous: [UInt8] = [150, 1]; continuous.put16(0); continuous.put16(0); continuous.put16(320); continuous.put16(200)
        try client.connection.write(continuous)
        try client.connection.write([248, 0, 0, 0, 0, 0, 0, 1, 2, 7, 7])
        client.assertQuiet(0.4)
        // Still framed correctly afterwards, and the 6-byte PointerEvent is what we parse.
        try client.request(incremental: false)
        XCTAssertEqual(try client.readUpdate().rects.count, 1)
    }

    func testInputIsTranslatedGatedAndReleased() throws {
        let client = try TestClient(try start())
        try client.handshake()
        func pointer(_ mask: UInt8, _ x: Int, _ y: Int) throws {
            var message: [UInt8] = [5, mask]; message.put16(UInt16(x)); message.put16(UInt16(y))
            try client.connection.write(message)
        }
        func key(_ keysym: UInt32, _ down: Bool) throws {
            var message: [UInt8] = [4, down ? 1 : 0, 0, 0]; message.put32(keysym)
            try client.connection.write(message)
        }
        try client.request(incremental: false); _ = try client.readUpdate()
        try pointer(0, 100, 50); try pointer(1, 100, 50); try pointer(0, 100, 50)
        try key(0x61, true); try key(0x61, false)
        var cut: [UInt8] = [6, 0, 0, 0]; cut.put32(5); cut += Array("hello".utf8)
        try client.connection.write(cut)
        try client.request(incremental: false); _ = try client.readUpdate()  // a round trip: everything before it was applied
        XCTAssertEqual(sink.snapshot, [
            .move(x: 200, y: 100, dragging: nil),
            .button(.left, down: true, x: 200, y: 100, clicks: 1),
            .button(.left, down: false, x: 200, y: 100, clicks: 1),
            .text("a", down: true), .text("a", down: false),
            .pasteboard("hello"),
        ], "framebuffer (100,50) is (200,100) on a 640x400-point display")
        // Locked Mac: nothing gets through.
        locked = true
        let before = sink.snapshot.count
        try pointer(1, 10, 10); try pointer(0, 10, 10)
        try client.request(incremental: false); _ = try client.readUpdate()
        XCTAssertEqual(sink.snapshot.count, before)
        locked = false
        // A viewer that leaves mid-drag releases the button.
        try pointer(1, 20, 20)
        try client.request(incremental: false); _ = try client.readUpdate()
        client.connection.close()
        let deadline = Date().addingTimeInterval(2)
        while server.clientCount > 0, Date() < deadline { usleep(20_000) }
        XCTAssertEqual(sink.snapshot.last, .button(.left, down: false, x: 40, y: 40, clicks: 1), "released where the finger was")
    }

    func testControlOffDropsInput() throws {
        let client = try TestClient(try start(control: false))
        try client.handshake()
        var message: [UInt8] = [5, 1]; message.put16(5); message.put16(5)
        try client.connection.write(message)
        try client.request(incremental: false); _ = try client.readUpdate()
        XCTAssertEqual(sink.snapshot, [])
    }

    func testInputWhileTheAgentHoldsControlIsDropped() throws {
        let client = try TestClient(try start(human: false))
        try client.handshake()
        try client.pointer(1, 5, 5); try client.key(0xffe3, true)
        try client.roundTrip()
        XCTAssertEqual(server.clientCount, 1, "refused keys and pointer leave the viewer watching")
        // A refused clipboard also drops the viewer (RD-18): the ⌘V behind it must never meet a reopened gate.
        try client.clipboard("hi")
        XCTAssertThrowsError(try client.connection.readByte())
        waitForNoClients()
        XCTAssertEqual(sink.snapshot, [], "nothing reaches the Mac while no person holds the lease, the clipboard included")
    }

    func testPausedSharingRefusesViewers() throws {
        let path = try start()
        server.setPaused(true)
        let client = try TestClient(path)
        XCTAssertThrowsError(try client.connection.read(12), "a paused helper closes new connections")
        server.setPaused(false)
        let again = try TestClient(path)
        try again.handshake()
    }

    func testControlSocketStatusAndRateLimitedThumbnail() throws {
        let source = CountingSource(TestPatternSource(width: 320, height: 200, fps: 30))
        _ = try start(source: source)
        let helper = ScreenHelper(server: server, stateDir: URL(fileURLWithPath: directory))
        let control = try ControlServer(path: directory + "/ctl.sock", handle: helper.handle)
        defer { control.close() }
        let status = try controlRequest(directory + "/ctl.sock", ["cmd": "status"])
        XCTAssertEqual(status["ok"] as? Bool, true)
        XCTAssertEqual(status["clients"] as? Int, 0)
        XCTAssertEqual(status["capturing"] as? Bool, false)
        XCTAssertEqual(status["allow_control"] as? Bool, true)
        for _ in 0 ..< 3 {
            let thumb = try controlRequest(directory + "/ctl.sock", ["cmd": "thumbnail", "max_w": 160, "max_h": 100])
            let url = try XCTUnwrap(thumb["data_url"] as? String)
            XCTAssertTrue(url.hasPrefix("data:image/jpeg;base64,"))
            let jpeg = Data(base64Encoded: String(url.dropFirst("data:image/jpeg;base64,".count)))!
            let image = CGImageSourceCreateImageAtIndex(CGImageSourceCreateWithData(jpeg as CFData, nil)!, 0, nil)!
            XCTAssertEqual([image.width, image.height], [160, 100])
        }
        XCTAssertEqual(source.snapshots, 1, "one grab per 5 s while nobody watches")
        let set = try controlRequest(directory + "/ctl.sock", ["cmd": "set", "allow_control": false, "human_control": true])
        XCTAssertEqual(set["allow_control"] as? Bool, false)
        XCTAssertEqual(set["human_control"] as? Bool, true)
        XCTAssertEqual(try controlRequest(directory + "/ctl.sock", ["cmd": "bogus"])["ok"] as? Bool, false)
    }

    func waitForNoClients() {
        let deadline = Date().addingTimeInterval(2)
        while server.clientCount > 0, Date() < deadline { usleep(20_000) }
    }

    func testSetDesktopSizeIsSkippedAndTheStreamStaysInSync() throws {
        let client = try TestClient(try start())
        try client.handshake()
        // 251, padding, 320 x 400, one screen, padding, then the 16-byte screen. The height's low byte
        // (0x90) is not the screen count: reading it as one would swallow 2304 bytes of later messages.
        var resize: [UInt8] = [251, 0]; resize.put16(320); resize.put16(400); resize += [1, 0]
        resize += [UInt8](repeating: 0, count: 16)
        try client.connection.write(resize)
        try client.pointer(0, 10, 10)
        try client.roundTrip()
        XCTAssertEqual(sink.snapshot, [.move(x: 20, y: 20, dragging: nil)], "the pointer event after SetDesktopSize still applies")
    }

    func testStopSharingMidDragReleasesWhatTheViewerHeld() throws {
        let client = try TestClient(try start())
        try client.handshake()
        try client.pointer(1, 20, 20); try client.key(0xffeb, true)
        try client.roundTrip()
        server.setPaused(true)
        waitForNoClients()
        XCTAssertEqual(Array(sink.snapshot.suffix(2)), [
            .button(.left, down: false, x: 40, y: 40, clicks: 1),
            .key(code: 55, down: false, flags: []),
        ], "the button and ⌘ are lifted although input is now refused")
    }

    func testRefusedInputLiftsWhatIsHeld() throws {
        let client = try TestClient(try start())
        try client.handshake()
        try client.pointer(1, 20, 20)
        try client.roundTrip()
        locked = true
        try client.pointer(0, 30, 30)  // the release itself is refused with the Mac locked
        try client.roundTrip()
        XCTAssertEqual(sink.snapshot.last, .button(.left, down: false, x: 40, y: 40, clicks: 1))
        let count = sink.snapshot.count
        try client.pointer(1, 30, 30); try client.roundTrip()
        XCTAssertEqual(sink.snapshot.count, count, "nothing new while locked")
    }

    func testInputFromAnotherViewerReleasesThePreviousController() throws {
        let path = try start()
        let first = try TestClient(path), second = try TestClient(path)
        try first.handshake(); try second.handshake()
        try first.pointer(1, 20, 20); try first.key(0xffe3, true)
        try first.roundTrip()
        try second.pointer(0, 50, 50)
        try second.roundTrip()
        XCTAssertEqual(Array(sink.snapshot.suffix(3)), [
            .button(.left, down: false, x: 40, y: 40, clicks: 1),
            .key(code: 59, down: false, flags: []),
            .move(x: 100, y: 100, dragging: nil),
        ], "a takeover never leaves the last controller's button or Ctrl down")
    }

    func testHandBackToTheAgentReleasesHeldInput() throws {
        let client = try TestClient(try start())
        try client.handshake()
        let helper = ScreenHelper(server: server, stateDir: URL(fileURLWithPath: directory))
        _ = helper.handle(["cmd": "set", "human_control": true])
        try client.pointer(1, 20, 20); try client.roundTrip()
        _ = helper.handle(["cmd": "set", "human_control": false])
        XCTAssertEqual(sink.snapshot.last, .button(.left, down: false, x: 40, y: 40, clicks: 1))
    }

    func testSwitchingControlOffReleasesHeldInput() throws {
        let client = try TestClient(try start())
        try client.handshake()
        let helper = ScreenHelper(server: server, stateDir: URL(fileURLWithPath: directory))
        try client.pointer(1, 20, 20); try client.key(0xffeb, true); try client.roundTrip()
        _ = helper.handle(["cmd": "set", "allow_control": false])
        XCTAssertEqual(Array(sink.snapshot.suffix(2)), [
            .button(.left, down: false, x: 40, y: 40, clicks: 1),
            .key(code: 55, down: false, flags: []),
        ], "the drag and ⌘ are lifted at once, not when the viewer next sends input")
        let count = sink.snapshot.count
        _ = helper.handle(["cmd": "set", "allow_control": false])
        try client.pointer(0, 30, 30); try client.roundTrip()
        XCTAssertEqual(sink.snapshot.count, count, "already off: nothing is released twice, and input stays refused")
    }

    /// r2-35: viewer A's key-down is being posted when another thread releases what A holds. The release
    /// must land after the key-down, or the key stays down on the Mac with nothing tracking it.
    private func raceAKeyDown(_ release: @escaping (RFBServer) -> Void, file: StaticString = #filePath, line: UInt = #line) throws -> (GatedSink, TestClient) {
        let gate = GatedSink()
        let client = try TestClient(try start(input: gate))
        try client.handshake()
        try client.key(0xff0d, true)  // Return down: its post is held in the sink
        XCTAssertEqual(gate.entered.wait(timeout: .now() + 2), .success, "the reader is posting the key-down", file: file, line: line)
        let released = expectation(description: "released")
        let server = self.server!
        DispatchQueue.global().async { release(server); released.fulfill() }
        usleep(150_000)  // unserialized, the release's key-up would be posted now, before the key-down
        gate.proceed.signal()
        wait(for: [released], timeout: 3)
        return (gate, client)
    }

    private func keys(_ actions: [InputAction]) -> [InputAction] { actions.filter { if case .key = $0 { return true }; return false } }

    func testAHandBackRacingAKeyDownReleasesItAfterItIsPosted() throws {
        let (gate, _) = try raceAKeyDown { $0.releaseHeldInput() }
        XCTAssertEqual(keys(gate.recorder.snapshot), [.key(code: 36, down: true, flags: []), .key(code: 36, down: false, flags: [])])
    }

    func testStopSharingRacingAKeyDownReleasesItAfterItIsPosted() throws {
        let (gate, client) = try raceAKeyDown { $0.setPaused(true) }
        waitForNoClients()
        XCTAssertEqual(keys(gate.recorder.snapshot), [.key(code: 36, down: true, flags: []), .key(code: 36, down: false, flags: [])])
        XCTAssertThrowsError(try client.connection.readByte(), "the viewer was disconnected")
    }

    func testATakeoverRacingAKeyDownReleasesItAfterItIsPosted() throws {
        let gate = GatedSink()
        let path = try start(input: gate)
        let first = try TestClient(path), second = try TestClient(path)
        try first.handshake(); try second.handshake()
        try first.key(0xff0d, true)
        XCTAssertEqual(gate.entered.wait(timeout: .now() + 2), .success)
        try second.pointer(0, 50, 50)  // B's first input claims control and releases A's
        usleep(150_000)
        gate.proceed.signal()
        try second.roundTrip(); try first.roundTrip()
        XCTAssertEqual(gate.recorder.snapshot, [
            .key(code: 36, down: true, flags: []),
            .key(code: 36, down: false, flags: []),
            .move(x: 100, y: 100, dragging: nil),
        ], "A's Return is posted, then lifted by B's claim, then B's input applies")
        try first.key(0xff0d, false); try first.roundTrip()
        XCTAssertEqual(keys(gate.recorder.snapshot).last, .key(code: 36, down: false, flags: []), "A's own key-up leaves nothing down")
    }

    func testCaptureEndedByMacOSDropsViewersAndTheNextOneRestartsIt() throws {
        let path = try start()
        let client = try TestClient(path)
        try client.handshake()
        try client.pointer(1, 20, 20); try client.roundTrip()
        server.captureFailed("The display was reconfigured")
        waitForNoClients()
        XCTAssertFalse(server.isCapturing)
        XCTAssertNil(server.latestFrame, "no frozen frame for the next viewer")
        XCTAssertEqual(server.lastCaptureError, "The display was reconfigured")
        XCTAssertEqual(sink.snapshot.last, .button(.left, down: false, x: 40, y: 40, clicks: 1))
        XCTAssertThrowsError(try client.connection.readByte(), "the viewer's stream ended")
        let helper = ScreenHelper(server: server, stateDir: URL(fileURLWithPath: directory))
        XCTAssertEqual(helper.status()["capture_error"] as? String, "The display was reconfigured")
        let again = try TestClient(path)
        try again.handshake()
        XCTAssertTrue(server.isCapturing)
        XCTAssertNil(server.lastCaptureError)
    }

    func testFailedStartClosesWaitingViewerAndCleanStartClearsError() throws {
        let source = ControlledSource()
        let path = try start(source: source)
        let client = try TestClient(path)
        // The failed start closes the viewer wherever its handshake has got to (not at the 10 s deadline).
        let before = ProcessInfo.processInfo.systemUptime
        XCTAssertThrowsError(try { while true { _ = try client.connection.readByte() } }())
        XCTAssertLessThan(ProcessInfo.processInfo.systemUptime - before, 2)
        waitForNoClients()
        XCTAssertEqual(server.clientCount, 0)
        XCTAssertFalse(server.isCapturing)
        XCTAssertEqual(server.lastCaptureError, String(describing: SocketError.system("chosen display is missing", ENODEV)))
        source.allowStart()
        let again = try TestClient(path)
        try again.handshake()
        XCTAssertTrue(server.isCapturing)
        XCTAssertNil(server.lastCaptureError)
    }

    func testStopSharingRacingClipboardSerializesTheWrite() throws {
        let gate = ClipboardGate()
        let client = try TestClient(try start(input: gate))
        try client.handshake(); try client.clipboard("phone")
        XCTAssertEqual(gate.entered.wait(timeout: .now() + 2), .success)
        let stopping = expectation(description: "stopping"), stopped = expectation(description: "stopped")
        let server = self.server!
        DispatchQueue.global().async { stopping.fulfill(); server.setPaused(true); stopped.fulfill() }
        wait(for: [stopping], timeout: 1)
        XCTAssertEqual(gate.recorder.snapshot, [])
        gate.proceed.signal()
        wait(for: [stopped], timeout: 2)
        XCTAssertEqual(gate.recorder.snapshot, [.pasteboard("phone")])
        XCTAssertEqual(server.clientCount, 0)
        XCTAssertThrowsError(try client.connection.readByte())
        server.setPaused(false)
        XCTAssertEqual(gate.recorder.snapshot, [.pasteboard("phone")])
    }

    func testStopOnMainDoesNotWaitForClipboardExecutor() throws {
        let sink = DeferredClipboardSink()
        let client = try TestClient(try start(input: sink))
        try client.handshake()
        let finished = expectation(description: "executor returned")
        sink.finished = { finished.fulfill() }
        try client.clipboard("phone")
        XCTAssertEqual(sink.entered.wait(timeout: .now() + 2), .success)
        XCTAssertTrue(Thread.isMainThread)
        // Model main withholding the executor while Stop runs; the fake executor itself has a deadline.
        server.setPaused(true)
        sink.proceed.signal()
        wait(for: [finished], timeout: 2)
        XCTAssertEqual(sink.recorder.snapshot, [])
        XCTAssertEqual(server.clientCount, 0)
    }

    func testTakeoverRacingClipboardKeepsMutationOrder() throws {
        let gate = ClipboardGate()
        let path = try start(input: gate)
        let first = try TestClient(path), second = try TestClient(path)
        try first.handshake(); try second.handshake()
        try first.key(0xffeb, true); try first.roundTrip()
        try first.clipboard("phone")
        XCTAssertEqual(gate.entered.wait(timeout: .now() + 2), .success)
        try second.pointer(0, 50, 50)
        gate.proceed.signal()
        try second.roundTrip(); try first.roundTrip()
        XCTAssertEqual(gate.recorder.snapshot, [
            .key(code: 55, down: true, flags: .command), .pasteboard("phone"),
            .key(code: 55, down: false, flags: []), .move(x: 100, y: 100, dragging: nil),
        ])
    }

    func testRefusedClipboardClosesViewerEvenIfGateReopensBeforePaste() throws {
        let path = try start(control: false)
        let client = try TestClient(path)
        try client.handshake(); try client.clipboard("phone")
        XCTAssertThrowsError(try client.connection.readByte())
        waitForNoClients()
        server.update { $0.allowControl = true }
        try? client.key(0xffeb, true); try? client.key(0x76, true)
        XCTAssertEqual(server.clientCount, 0)
        XCTAssertEqual(sink.snapshot, [])
    }

    func testLockedAndPausedClipboardWritesNothing() throws {
        let path = try start()
        let client = try TestClient(path)
        try client.handshake(); locked = true; try client.clipboard("locked")
        XCTAssertThrowsError(try client.connection.readByte())
        waitForNoClients(); locked = false
        let again = try TestClient(path)
        try again.handshake(); server.setPaused(true)
        try? again.clipboard("paused")
        XCTAssertEqual(sink.snapshot, [])
    }

    func testClipboardThenCommandVArriveInOrder() throws {
        let client = try TestClient(try start())
        try client.handshake(); try client.clipboard("phone")
        try client.key(0xffeb, true); try client.key(0x76, true); try client.roundTrip()
        XCTAssertEqual(sink.snapshot, [.pasteboard("phone"), .key(code: 55, down: true, flags: .command), .key(code: 9, down: true, flags: .command)])
    }

    func testHandshakeDeadlineFreesSlot() throws {
        let path = try start { $0.handshakeTimeout = 0.2; $0.maxClients = 1; $0.captureStopDelay = 0 }
        let silent = try TestClient(path)
        XCTAssertEqual(try silent.connection.read(12).count, 12)
        XCTAssertThrowsError(try silent.connection.readByte())
        waitForNoClients()
        XCTAssertEqual(server.clientCount, 0)
        let next = try TestClient(path)
        try next.handshake()
    }

    func testPartialMessagesAndMalformedTypeReleaseHeldInput() throws {
        let path = try start { $0.messageTimeout = 0.1 }
        for fragment: [UInt8] in [[4, 1], [5, 1], [123]] {
            let client = try TestClient(path)
            try client.handshake(); try client.key(0xffeb, true); try client.roundTrip()
            try client.connection.write(fragment)
            XCTAssertThrowsError(try client.connection.readByte())
            waitForNoClients()
            XCTAssertEqual(server.clientCount, 0)
            XCTAssertEqual(sink.snapshot.last, .key(code: 55, down: false, flags: []))
        }
    }

    func testIdleViewerHasNoMessageDeadline() throws {
        let client = try TestClient(try start { $0.messageTimeout = 0.05; $0.handshakeTimeout = 0.2 })
        try client.handshake()
        client.assertQuiet(0.3)
        try client.roundTrip()
        XCTAssertEqual(server.clientCount, 1)
    }

    func testOversizedClipboardClosesViewerWithoutWriting() throws {
        let client = try TestClient(try start())
        try client.handshake(); try client.key(0xffeb, true); try client.roundTrip()
        var message: [UInt8] = [6, 0, 0, 0]; message.put32(256 * 1024 + 1)
        try client.connection.write(message)
        XCTAssertThrowsError(try client.connection.readByte())
        waitForNoClients()
        XCTAssertEqual(sink.snapshot, [.key(code: 55, down: true, flags: .command), .key(code: 55, down: false, flags: [])])
    }

    func testViewerThatStopsReadingHitsWriteDeadline() throws {
        let client = try TestClient(try start(source: TestPatternSource(width: 1920, height: 1080, fps: 1)) { $0.writeTimeout = 0.1 })
        try client.handshake(); try client.key(0xffeb, true)
        try client.request(incremental: false)
        waitForNoClients()
        XCTAssertEqual(server.clientCount, 0)
        XCTAssertEqual(sink.snapshot.last, .key(code: 55, down: false, flags: []))
    }

    func testBlockedCaptureStartLeavesStatusAcceptAndStopResponsive() throws {
        let source = ControlledSource(); source.allowStart(); source.block = true
        let path = try start(source: source)
        let first = try TestClient(path)
        defer { source.proceed.signal() }
        XCTAssertEqual(source.entered.wait(timeout: .now() + 2), .success)
        let helper = ScreenHelper(server: server, stateDir: URL(fileURLWithPath: directory))
        let control = try ControlServer(path: directory + "/ctl.sock", handle: helper.handle)
        defer { control.close() }
        let checked = expectation(description: "responsive status and accept")
        let server = self.server!
        DispatchQueue.global().async {
            XCTAssertEqual(server.clientCount, 1)
            XCTAssertTrue(server.isCapturing)
            XCTAssertNil(server.lastCaptureError)
            do {
                let status = try controlRequest(self.directory + "/ctl.sock", ["cmd": "status"])
                XCTAssertEqual(status["clients"] as? Int, 1)
                let second = try TestClient(path)
                XCTAssertEqual(try second.connection.read(12).count, 12)
                server.stop()
                XCTAssertFalse(server.isCapturing)
            } catch { XCTFail("\(error)") }
            checked.fulfill()
        }
        wait(for: [checked], timeout: 2)
        source.proceed.signal()
        XCTAssertEqual(source.stopped.wait(timeout: .now() + 2), .success)
        XCTAssertNil(server.latestFrame)
        XCTAssertThrowsError(try first.handshake())
    }

    func testPartialControlLineExpiresAndHealthyRequestStillWorks() throws {
        _ = try start()
        let helper = ScreenHelper(server: server, stateDir: URL(fileURLWithPath: directory))
        let path = directory + "/ctl.sock"
        let control = try ControlServer(path: path, handle: helper.handle)
        defer { control.close() }
        let partial = try connectUnix(path)
        try partial.write(Array("{\"cmd\":\"status\"}".utf8))
        XCTAssertEqual(try controlRequest(path, ["cmd": "status"])["ok"] as? Bool, true)
        let before = ProcessInfo.processInfo.systemUptime
        XCTAssertThrowsError(try partial.readByte())
        XCTAssertLessThan(ProcessInfo.processInfo.systemUptime - before, HelperDeadlines.control + 1)
        XCTAssertEqual(try controlRequest(path, ["cmd": "status"])["ok"] as? Bool, true)
    }

    func testListenerCapsLiveConnectionsAndReturnsSlotOnClose() throws {
        let path = directory + "/capped.sock"
        let listener = try UnixListener(path: path, maxConnections: 1, readTimeout: 1)
        defer { listener.close() }
        let first = try connectUnix(path)
        let accepted = try XCTUnwrap(listener.accept())
        defer { accepted.close() }
        let excess = try connectUnix(path)
        let accepting = expectation(description: "accept ended")
        DispatchQueue.global().async { listener.accept()?.close(); accepting.fulfill() }
        XCTAssertThrowsError(try excess.readByte())
        try first.write([42]); XCTAssertEqual(try accepted.readByte(), 42)
        accepted.close()
        let next = try connectUnix(path)
        XCTAssertThrowsError(try next.readByte())
        wait(for: [accepting], timeout: 2)
    }

    func testPointerMapsOntoTheDisplayWhereItIsNow() throws {
        let source = MovingDisplaySource()
        let client = try TestClient(try start(source: source))
        try client.handshake()
        try client.pointer(0, 100, 50); try client.roundTrip()
        source.bounds = CGRect(x: 1000, y: 0, width: 1280, height: 800)  // resized and moved right
        try client.pointer(0, 100, 60); try client.roundTrip()
        XCTAssertEqual(sink.snapshot, [.move(x: 200, y: 100, dragging: nil), .move(x: 1400, y: 240, dragging: nil)])
    }
}

final class InputTranslationTests: XCTestCase {
    let identity: (Double, Double) -> (Double, Double) = { ($0, $1) }

    func testKeysymsToKeysAndText() {
        var translator = InputTranslator()
        XCTAssertEqual(translator.key(0xff0d, down: true), [.key(code: 36, down: true, flags: [])])
        XCTAssertEqual(translator.key(0xff51, down: true), [.key(code: 123, down: true, flags: [])])
        XCTAssertEqual(translator.key(0xffbe, down: true), [.key(code: 122, down: true, flags: [])], "F1")
        XCTAssertEqual(translator.key(0x01004f60, down: true), [.text("你", down: true)], "Unicode keysyms are typed as text")
        XCTAssertEqual(translator.key(0xe9, down: true), [.text("é", down: true)])
        // ⌘ (Super_L) then c: a real ⌘C, by the layout's virtual key.
        XCTAssertEqual(translator.key(0xffeb, down: true), [.key(code: 55, down: true, flags: .command)])
        XCTAssertEqual(translator.key(0x63, down: true), [.key(code: 8, down: true, flags: .command)])
        XCTAssertEqual(translator.key(0x63, down: false), [.key(code: 8, down: false, flags: .command)])
        XCTAssertEqual(translator.key(0xffeb, down: false), [.key(code: 55, down: false, flags: [])])
        // ⌥ is Alt_L; Control_L is ⌃.
        XCTAssertEqual(translator.key(0xffe9, down: true), [.key(code: 58, down: true, flags: .option)])
        XCTAssertEqual(translator.key(0xffe3, down: true), [.key(code: 59, down: true, flags: [.option, .control])])
        // Return, ←, F1, 你 and é were never released: releaseAll lifts them (newest first), then ⌃ and ⌥.
        XCTAssertEqual(translator.releaseAll(x: 0, y: 0), [
            .text("é", down: false), .text("你", down: false), .key(code: 122, down: false, flags: [.option, .control]),
            .key(code: 123, down: false, flags: [.option, .control]), .key(code: 36, down: false, flags: [.option, .control]),
            .key(code: 59, down: false, flags: .option), .key(code: 58, down: false, flags: []),
        ])
        XCTAssertNil(Keysyms.character(0xff08))
    }

    func testShiftTravelsWithShortcutLettersAndNamedKeys() {
        var translator = InputTranslator()
        // r2-34: ⇧, ⌘, then Z is ⌘⇧Z (redo) on the layout's Z key, never ⌘Z (undo).
        XCTAssertEqual(translator.key(0xffe1, down: true), [.key(code: 56, down: true, flags: .shift)])
        XCTAssertEqual(translator.key(0xffeb, down: true), [.key(code: 55, down: true, flags: [.shift, .command])])
        XCTAssertEqual(translator.key(0x5a, down: true), [.key(code: 6, down: true, flags: [.shift, .command])])
        XCTAssertEqual(translator.key(0x5a, down: false), [.key(code: 6, down: false, flags: [.shift, .command])])
        XCTAssertEqual(translator.key(0xffeb, down: false), [.key(code: 55, down: false, flags: .shift)])
        // Shift+Tab and Shift+→ carry Shift.
        XCTAssertEqual(translator.key(0xff09, down: true), [.key(code: 48, down: true, flags: .shift)])
        XCTAssertEqual(translator.key(0xff09, down: false), [.key(code: 48, down: false, flags: .shift)])
        XCTAssertEqual(translator.key(0xff53, down: true), [.key(code: 124, down: true, flags: .shift)])
        XCTAssertEqual(translator.key(0xff53, down: false), [.key(code: 124, down: false, flags: .shift)])
        XCTAssertEqual(translator.key(0xffe1, down: false), [.key(code: 56, down: false, flags: [])])
        // A capital under ⌘ with no Shift_L (the key bar's sticky ⌘ plus a capital typed on the iOS
        // keyboard) is ⌘⇧Z as well; a lower-case z stays ⌘Z.
        _ = translator.key(0xffeb, down: true)
        XCTAssertEqual(translator.key(0x5a, down: true), [.key(code: 6, down: true, flags: [.command, .shift])])
        XCTAssertEqual(translator.key(0x5a, down: false), [.key(code: 6, down: false, flags: [.command, .shift])])
        XCTAssertEqual(translator.key(0x7a, down: true), [.key(code: 6, down: true, flags: .command)])
        XCTAssertEqual(translator.key(0x7a, down: false), [.key(code: 6, down: false, flags: .command)])
        // Without ⌘/⌃/⌥ a capital is typed text, as before.
        _ = translator.key(0xffeb, down: false)
        XCTAssertEqual(translator.key(0x5a, down: true), [.text("Z", down: true)])
    }

    func testClickStateDragAndWheel() {
        var translator = InputTranslator()
        XCTAssertEqual(translator.pointer(mask: 1, x: 10, y: 10, scale: identity, time: 0).last, .button(.left, down: true, x: 10, y: 10, clicks: 1))
        _ = translator.pointer(mask: 0, x: 10, y: 10, scale: identity, time: 0.05)
        XCTAssertEqual(translator.pointer(mask: 1, x: 11, y: 10, scale: identity, time: 0.2).last, .button(.left, down: true, x: 11, y: 10, clicks: 2), "double click")
        XCTAssertEqual(translator.pointer(mask: 0, x: 11, y: 10, scale: identity, time: 0.25).last, .button(.left, down: false, x: 11, y: 10, clicks: 2))
        _ = translator.pointer(mask: 1, x: 60, y: 60, scale: identity, time: 2)
        XCTAssertEqual(translator.pointer(mask: 1, x: 80, y: 70, scale: identity, time: 2.1), [.move(x: 80, y: 70, dragging: .left)])
        _ = translator.pointer(mask: 0, x: 80, y: 70, scale: identity, time: 2.2)
        XCTAssertEqual(translator.pointer(mask: 8, x: 80, y: 70, scale: identity, time: 3), [.scroll(dx: 0, dy: 3, x: 80, y: 70)])
        XCTAssertEqual(translator.pointer(mask: 0, x: 80, y: 70, scale: identity, time: 3.01), [])
        XCTAssertEqual(translator.pointer(mask: 16, x: 80, y: 70, scale: identity, time: 3.1), [.scroll(dx: 0, dy: -3, x: 80, y: 70)])
        XCTAssertEqual(translator.pointer(mask: 4, x: 90, y: 70, scale: identity, time: 4).last, .button(.right, down: true, x: 90, y: 70, clicks: 1))
        var tracker = ClickTracker(interval: 0.5, slop: 4)
        XCTAssertEqual(tracker.press(.left, at: 0, x: 0, y: 0), 1)
        XCTAssertEqual(tracker.press(.left, at: 0.4, x: 3, y: 0), 2)
        XCTAssertEqual(tracker.press(.left, at: 0.8, x: 3, y: 0), 3)
        XCTAssertEqual(tracker.press(.left, at: 2, x: 3, y: 0), 1, "too late")
        XCTAssertEqual(tracker.press(.left, at: 2.1, x: 30, y: 0), 1, "too far")
        XCTAssertEqual(tracker.press(.right, at: 2.2, x: 30, y: 0), 1, "another button")
    }

    func testCoalesceAndTileDiff() {
        let bounds = Rect(x: 0, y: 0, width: 100, height: 100)
        XCTAssertEqual(coalesce([Rect(x: 0, y: 0, width: 10, height: 10), Rect(x: 12, y: 0, width: 10, height: 10)], within: bounds), [Rect(x: 0, y: 0, width: 22, height: 10)])
        XCTAssertEqual(coalesce([Rect(x: 0, y: 0, width: 10, height: 10), Rect(x: 80, y: 80, width: 30, height: 30)], within: bounds).count, 2)
        let source = TestPatternSource(width: 256, height: 128, fps: 1)
        let a = source.next()!, b = source.next()!
        let changed = changedTiles(from: a.buffer, to: b.buffer)
        XCTAssertFalse(changed.isEmpty)
        XCTAssertLessThan(changed.map(\.area).reduce(0, +), 256 * 128)
        XCTAssertEqual(changedTiles(from: b.buffer, to: b.buffer), [])
        XCTAssertEqual(changedTiles(from: nil, to: b.buffer), [Rect(x: 0, y: 0, width: 256, height: 128)])
        XCTAssertEqual(Rect(x: 17, y: 3, width: 10, height: 30).aligned(to: 16, within: bounds), Rect(x: 16, y: 0, width: 16, height: 48))
        XCTAssertEqual(Rect(x: 90, y: 90, width: 9, height: 9).aligned(to: 16, within: bounds), Rect(x: 80, y: 80, width: 20, height: 20))
    }
}

func nalUnits(_ annexB: [UInt8]) -> [[UInt8]] {
    var starts: [Int] = []
    var i = 0
    while i + 3 < annexB.count {
        if annexB[i] == 0, annexB[i + 1] == 0, annexB[i + 2] == 1 { starts.append(i + 3); i += 3 } else { i += 1 }
    }
    return starts.enumerated().map { index, start in
        var end = index + 1 < starts.count ? starts[index + 1] - 3 : annexB.count
        while end > start, annexB[end - 1] == 0 { end -= 1 }
        return Array(annexB[start ..< end])
    }
}

/// Decodes the helper's Annex-B stream with VideoToolbox, as a check that it is a valid H.264 stream.
final class H264TestDecoder {
    private var session: VTDecompressionSession?
    private let format: CMVideoFormatDescription

    init(_ units: [[UInt8]]) throws {
        let sps = units.first { $0[0] & 0x1f == 7 }!, pps = units.first { $0[0] & 0x1f == 8 }!
        var description: CMVideoFormatDescription?
        let status = sps.withUnsafeBufferPointer { s in
            pps.withUnsafeBufferPointer { p in
                let pointers = [s.baseAddress!, p.baseAddress!]
                let sizes = [sps.count, pps.count]
                return CMVideoFormatDescriptionCreateFromH264ParameterSets(allocator: nil, parameterSetCount: 2, parameterSetPointers: pointers,
                                                                           parameterSetSizes: sizes, nalUnitHeaderLength: 4, formatDescriptionOut: &description)
            }
        }
        XCTAssertEqual(status, noErr)
        format = description!
        var created: VTDecompressionSession?
        XCTAssertEqual(VTDecompressionSessionCreate(allocator: nil, formatDescription: format, decoderSpecification: nil, imageBufferAttributes: nil,
                                                    outputCallback: nil, decompressionSessionOut: &created), noErr)
        session = created
    }

    deinit { if let session { VTDecompressionSessionInvalidate(session) } }

    /// Decodes the slices in `units`; returns the decoded frame's size.
    func decode(_ units: [[UInt8]]) throws -> CGSize? {
        var avcc: [UInt8] = []
        for unit in units where [1, 5].contains(unit[0] & 0x1f) { avcc.put32(UInt32(unit.count)); avcc += unit }
        var block: CMBlockBuffer?
        CMBlockBufferCreateWithMemoryBlock(allocator: nil, memoryBlock: nil, blockLength: avcc.count, blockAllocator: nil, customBlockSource: nil,
                                           offsetToData: 0, dataLength: avcc.count, flags: kCMBlockBufferAssureMemoryNowFlag, blockBufferOut: &block)
        CMBlockBufferReplaceDataBytes(with: avcc, blockBuffer: block!, offsetIntoDestination: 0, dataLength: avcc.count)
        var sample: CMSampleBuffer?
        var size = avcc.count
        CMSampleBufferCreateReady(allocator: nil, dataBuffer: block, formatDescription: format, sampleCount: 1, sampleTimingEntryCount: 0,
                                  sampleTimingArray: nil, sampleSizeEntryCount: 1, sampleSizeArray: &size, sampleBufferOut: &sample)
        var decoded: CGSize?
        let status = VTDecompressionSessionDecodeFrame(session!, sampleBuffer: sample!, flags: [], infoFlagsOut: nil) { status, _, image, _, _ in
            if status == noErr, let image { decoded = CGSize(width: CVPixelBufferGetWidth(image), height: CVPixelBufferGetHeight(image)) }
        }
        XCTAssertEqual(status, noErr)
        VTDecompressionSessionWaitForAsynchronousFrames(session!)
        return decoded
    }
}
