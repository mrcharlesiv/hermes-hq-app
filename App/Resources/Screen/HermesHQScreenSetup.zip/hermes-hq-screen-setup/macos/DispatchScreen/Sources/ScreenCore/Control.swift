import Foundation

/// `ctl.sock`: one JSON object per line in, one per line out. The gateway plugin's only way in:
/// status, a thumbnail for the Screen hero, stop, and settings.
public final class ControlServer {
    private let listener: UnixListener

    public init(path: String, handle: @escaping ([String: Any]) -> [String: Any]) throws {
        listener = try UnixListener(path: path)
        let listener = self.listener
        let thread = Thread {
            while let connection = listener.accept() {
                guard connection.peerUID == getuid() else { connection.close(); continue }
                let worker = Thread { ControlServer.serve(connection, handle: handle) }
                worker.name = "dispatch-screen.ctl"
                worker.start()
            }
        }
        thread.name = "dispatch-screen.ctl-accept"
        thread.start()
    }

    public func close() { listener.close() }

    private static func serve(_ connection: SocketConnection, handle: ([String: Any]) -> [String: Any]) {
        defer { connection.close() }
        var line: [UInt8] = []
        while let byte = try? connection.readByte() {
            if byte != 0x0a {
                line.append(byte)
                if line.count > 64 * 1024 { return }
                continue
            }
            let request = (try? JSONSerialization.jsonObject(with: Data(line))) as? [String: Any]
            line.removeAll()
            let response = request.map(handle) ?? ["ok": false, "error": "expected a JSON object"]
            guard let data = try? JSONSerialization.data(withJSONObject: response, options: [.sortedKeys]) else { return }
            do { try connection.write([UInt8](data) + [0x0a]) } catch { return }
        }
    }
}

/// One request/response over a control socket (the plugin's client, and tests).
public func controlRequest(_ path: String, _ request: [String: Any]) throws -> [String: Any] {
    let connection = try connectUnix(path)
    defer { connection.close() }
    try connection.write([UInt8](try JSONSerialization.data(withJSONObject: request)) + [0x0a])
    var line: [UInt8] = []
    while true {
        let byte = try connection.readByte()
        if byte == 0x0a { break }
        line.append(byte)
    }
    return (try JSONSerialization.jsonObject(with: Data(line)) as? [String: Any]) ?? [:]
}

/// The helper's state as the control socket reports it, and its commands.
public final class ScreenHelper {
    public static let version = "1.1.0"
    public let server: RFBServer
    public let stateDir: URL
    /// Screen Recording and Accessibility (post-event) grants.
    public var permissions: () -> (screen: Bool, events: Bool) = { (true, true) }
    public var secureInput: () -> Bool = { false }
    public var onStop: () -> Void = {}
    public var onChange: () -> Void = {}
    private let lock = NSLock()
    private var grabbed: (at: Date, frame: Frame)?
    /// At most one grab per 5 s while nobody watches: every grab lights the capture indicator.
    public var thumbnailTTL: TimeInterval = 5

    public init(server: RFBServer, stateDir: URL) {
        self.server = server
        self.stateDir = stateDir
    }

    public var pausedFile: URL { stateDir.appendingPathComponent("sharing_paused") }

    public var isHumanInControl: Bool { server.isHumanInControl }

    /// "Stop sharing" from the menu bar: persisted, so a relaunch stays stopped until resumed at the Mac.
    public func setSharingPaused(_ paused: Bool) {
        if paused { FileManager.default.createFile(atPath: pausedFile.path, contents: Data(), attributes: [.posixPermissions: 0o600]) }
        else { try? FileManager.default.removeItem(at: pausedFile) }
        server.setPaused(paused)
        onChange()
    }

    public func status() -> [String: Any] {
        let frame = server.latestFrame
        let options = server.currentOptions
        let grants = permissions()
        return [
            "ok": true, "version": ScreenHelper.version, "pid": Int(getpid()),
            "source": server.source.name, "capturing": server.isCapturing, "clients": server.clientCount,
            "width": frame?.width ?? 0, "height": frame?.height ?? 0, "fps": server.fps,
            "tcc": ["screen": grants.screen, "events": grants.events],
            "locked": server.isLocked(), "secure_input": secureInput(),
            "allow_control": options.allowControl, "paused": server.isPaused, "human_control": isHumanInControl,
            "input_events": Int(server.inputCount), "capture_error": server.lastCaptureError ?? NSNull(),
        ]
    }

    public func handle(_ request: [String: Any]) -> [String: Any] {
        switch request["cmd"] as? String {
        case "status":
            return status()
        case "thumbnail":
            let maxWidth = (request["max_w"] as? Int) ?? 960, maxHeight = (request["max_h"] as? Int) ?? 600
            let quality = (request["quality"] as? Int) ?? 72
            guard let jpeg = thumbnailJPEG(maxWidth: maxWidth, maxHeight: maxHeight, quality: quality) else {
                return ["ok": true, "data_url": NSNull()]
            }
            return ["ok": true, "data_url": "data:image/jpeg;base64," + Data(jpeg).base64EncodedString()]
        case "set":
            if let allow = request["allow_control"] as? Bool {
                var was = false
                server.update { was = $0.allowControl; $0.allowControl = allow }
                // Control switched off mid-drag or with ⌘ down: lift it now, not when that viewer next
                // sends input or leaves (serialized with every viewer's input).
                if was && !allow { server.releaseHeldInput() }
            }
            // Back to the agent: nothing a person pressed may stay down under its clicks, and input the bridge
            // forwarded before the hand-back is refused from here on (r6-77). r5-54: the plugin sends
            // release_input on every lease transition, as it happens; a takeover and hand-back between two
            // of its once-a-second samples never flipped human_control, so a held button or modifier (its
            // key-up dropped by the lease filter) stayed down under the agent.
            let human = request["human_control"] as? Bool, release = request["release_input"] as? Bool == true
            if human != nil || release { server.setHumanControl(human, releaseInput: release) }
            if let paused = request["paused"] as? Bool { setSharingPaused(paused) }
            onChange()
            return status()
        case "stop":
            DispatchQueue.global().asyncAfter(deadline: .now() + 0.1) { self.onStop() }
            return ["ok": true]
        default:
            return ["ok": false, "error": "unknown command"]
        }
    }

    /// From the live stream's newest frame while someone watches; otherwise one grab, reused for 5 s.
    func thumbnailJPEG(maxWidth: Int, maxHeight: Int, quality: Int) -> [UInt8]? {
        if server.isPaused { return nil }
        if server.isCapturing, let frame = server.latestFrame, Date().timeIntervalSince(frame.capturedAt) < 2 {
            return ScreenCore.thumbnailJPEG(frame, maxWidth: maxWidth, maxHeight: maxHeight, quality: quality)
        }
        lock.lock(); defer { lock.unlock() }
        if grabbed == nil || Date().timeIntervalSince(grabbed!.at) >= thumbnailTTL {
            guard let frame = server.source.snapshot() else { return nil }
            grabbed = (Date(), frame)
        }
        return ScreenCore.thumbnailJPEG(grabbed!.frame, maxWidth: maxWidth, maxHeight: maxHeight, quality: quality)
    }
}
