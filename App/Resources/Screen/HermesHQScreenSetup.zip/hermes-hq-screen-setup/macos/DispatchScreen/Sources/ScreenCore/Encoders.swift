import CoreGraphics
import Foundation
import ImageIO
import UniformTypeIdentifiers

/// RFB PIXEL_FORMAT (RFC 6143 §7.4).
public struct PixelFormat: Equatable {
    public var bitsPerPixel: UInt8
    public var depth: UInt8
    public var bigEndian: Bool
    public var trueColor: Bool
    public var redMax: UInt16, greenMax: UInt16, blueMax: UInt16
    public var redShift: UInt8, greenShift: UInt8, blueShift: UInt8

    /// What the capture delivers: little-endian 32-bit BGRX (red in bits 16-23).
    public static let native = PixelFormat(bitsPerPixel: 32, depth: 24, bigEndian: false, trueColor: true,
                                           redMax: 255, greenMax: 255, blueMax: 255, redShift: 16, greenShift: 8, blueShift: 0)

    public init(bitsPerPixel: UInt8, depth: UInt8, bigEndian: Bool, trueColor: Bool, redMax: UInt16, greenMax: UInt16,
                blueMax: UInt16, redShift: UInt8, greenShift: UInt8, blueShift: UInt8) {
        self.bitsPerPixel = bitsPerPixel; self.depth = depth; self.bigEndian = bigEndian; self.trueColor = trueColor
        self.redMax = redMax; self.greenMax = greenMax; self.blueMax = blueMax
        self.redShift = redShift; self.greenShift = greenShift; self.blueShift = blueShift
    }

    /// Parses the 16-byte wire form; nil for anything this server cannot produce (colour maps, odd sizes).
    public init?(bytes: [UInt8]) {
        guard bytes.count >= 16, [8, 16, 32].contains(bytes[0]), bytes[3] != 0 else { return nil }
        self.init(bitsPerPixel: bytes[0], depth: bytes[1], bigEndian: bytes[2] != 0, trueColor: true,
                  redMax: bytes.u16(4), greenMax: bytes.u16(6), blueMax: bytes.u16(8),
                  redShift: bytes[10], greenShift: bytes[11], blueShift: bytes[12])
        guard redMax > 0, greenMax > 0, blueMax > 0 else { return nil }
    }

    public var bytes: [UInt8] {
        var out: [UInt8] = [bitsPerPixel, depth, bigEndian ? 1 : 0, trueColor ? 1 : 0]
        out.put16(redMax); out.put16(greenMax); out.put16(blueMax)
        out += [redShift, greenShift, blueShift, 0, 0, 0]
        return out
    }

    public var bytesPerPixel: Int { Int(bitsPerPixel) / 8 }

    /// Tight's compact pixel: three bytes R, G, B for 32-bit depth-24 true colour, else the full pixel.
    var tightPixelIsRGB: Bool { bitsPerPixel == 32 && depth == 24 && redMax == 255 && greenMax == 255 && blueMax == 255 }

    @inline(__always) func append(r: UInt8, g: UInt8, b: UInt8, to out: inout [UInt8]) {
        let value = (UInt32(r) * UInt32(redMax) / 255) << redShift
            | (UInt32(g) * UInt32(greenMax) / 255) << greenShift
            | (UInt32(b) * UInt32(blueMax) / 255) << blueShift
        switch bitsPerPixel {
        case 8: out.append(UInt8(truncatingIfNeeded: value))
        case 16:
            let v = UInt16(truncatingIfNeeded: value)
            if bigEndian { out.append(UInt8(v >> 8)); out.append(UInt8(v & 0xff)) } else { out.append(UInt8(v & 0xff)); out.append(UInt8(v >> 8)) }
        default:
            if bigEndian { out.put32(value) } else {
                out.append(UInt8(value & 0xff)); out.append(UInt8((value >> 8) & 0xff))
                out.append(UInt8((value >> 16) & 0xff)); out.append(UInt8(value >> 24))
            }
        }
    }
}

public enum Encoding {
    public static let raw: Int32 = 0
    public static let tight: Int32 = 7
    public static let h264: Int32 = 50
    public static let desktopSize: Int32 = -223
    public static let lastRect: Int32 = -224
    public static let extendedDesktopSize: Int32 = -308
    /// Never acknowledged. ExtendedMouseButtons makes noVNC send 7-byte PointerEvents that the gateway's
    /// RfbClientFilter frames as 6; XVP's client message 250 is unknown to that filter (it closes the
    /// stream); ContinuousUpdates and Fence would give up the pull model's backpressure on cellular.
    public static let neverAcknowledged: Set<Int32> = [-316, -309, -313, -312]
    public static func isQuality(_ e: Int32) -> Bool { (-32 ... -23).contains(e) }
    public static func isCompression(_ e: Int32) -> Bool { (-256 ... -247).contains(e) }
}

/// JPEG quality per RFB QualityLevel 0-9 (TigerVNC's mapping).
public let jpegQuality: [Int] = [15, 29, 41, 42, 62, 77, 79, 86, 92, 100]

func rectHeader(_ rect: Rect, _ encoding: Int32) -> [UInt8] {
    var out: [UInt8] = []
    out.reserveCapacity(12)
    out.put16(UInt16(rect.x)); out.put16(UInt16(rect.y)); out.put16(UInt16(rect.width)); out.put16(UInt16(rect.height))
    out.putS32(encoding)
    return out
}

/// Raw: the rect's pixels in the client's pixel format.
public func encodeRaw(_ frame: Frame, _ rect: Rect, format: PixelFormat) -> [UInt8] {
    var out = rectHeader(rect, Encoding.raw)
    out.reserveCapacity(out.count + rect.area * format.bytesPerPixel)
    frame.withPixels { base, stride in
        let bgrx = format == .native
        let rgbx = format.bitsPerPixel == 32 && !format.bigEndian && format.redShift == 0 && format.greenShift == 8
            && format.blueShift == 16 && format.redMax == 255 && format.greenMax == 255 && format.blueMax == 255
        for y in rect.y ..< rect.maxY {
            let row = base.advanced(by: y * stride + rect.x * 4)
            if bgrx {
                out.append(contentsOf: UnsafeBufferPointer(start: row, count: rect.width * 4))
                continue
            }
            for x in 0 ..< rect.width {
                let p = row.advanced(by: x * 4)
                if rgbx { out.append(p[2]); out.append(p[1]); out.append(p[0]); out.append(0) } else { format.append(r: p[2], g: p[1], b: p[0], to: &out) }
            }
        }
    }
    return out
}

/// The longest payload Tight's compact length can state: 22 bits (7 + 7 + 8), one byte short of 4 MiB.
public let tightMaxLength = 0x3F_FFFF

/// Tight's compact length (1-3 bytes: 7, 7 and 8 bits); nil past `tightMaxLength`, which it cannot state
/// (a checked UInt8 of the top bits would trap the helper, and every viewer's stream with it).
public func tightLength(_ n: Int) -> [UInt8]? {
    guard (0 ... tightMaxLength).contains(n) else { return nil }
    if n < 0x80 { return [UInt8(n)] }
    if n < 0x4000 { return [UInt8(n & 0x7f) | 0x80, UInt8(n >> 7)] }
    return [UInt8(n & 0x7f) | 0x80, UInt8((n >> 7) & 0x7f) | 0x80, UInt8(n >> 14)]
}

/// The rect's single colour (B, G, R) when every pixel matches; only checked for small rects.
func solidColor(_ frame: Frame, _ rect: Rect) -> (UInt8, UInt8, UInt8)? {
    guard rect.area <= 256 * 256 else { return nil }
    return frame.withPixels { base, stride in
        let first = base.advanced(by: rect.y * stride + rect.x * 4)
        let b = first[0], g = first[1], r = first[2]
        for y in rect.y ..< rect.maxY {
            let row = base.advanced(by: y * stride + rect.x * 4)
            for x in 0 ..< rect.width {
                let p = row.advanced(by: x * 4)
                if p[0] != b || p[1] != g || p[2] != r { return nil }
            }
        }
        return (b, g, r)
    }
}

/// Tight with its Fill or JPEG subencoding (the client asked for a quality level, so JPEG is allowed), as
/// one or more rects. A JPEG too long for Tight's length (a full update of a noisy screen at quality 8-9,
/// or a raised max width, can pass 4 MiB) is re-encoded as two row bands, halving again as needed. nil
/// when JPEG fails: the caller sends Raw.
public func encodeTightJPEG(_ frame: Frame, _ rect: Rect, format: PixelFormat, quality: Int) -> [[UInt8]]? {
    var out = rectHeader(rect, Encoding.tight)
    if let (b, g, r) = solidColor(frame, rect) {
        out.append(0x80)
        if format.tightPixelIsRGB { out += [r, g, b] } else { format.append(r: r, g: g, b: b, to: &out) }
        return [out]
    }
    guard let jpeg = jpegData(frame, rect, quality: quality) else { return nil }
    guard let length = tightLength(jpeg.count) else {
        guard rect.height > 1 else { return nil }
        let top = Rect(x: rect.x, y: rect.y, width: rect.width, height: rect.height / 2)
        let bottom = Rect(x: rect.x, y: top.maxY, width: rect.width, height: rect.height - top.height)
        guard let upper = encodeTightJPEG(frame, top, format: format, quality: quality),
              let lower = encodeTightJPEG(frame, bottom, format: format, quality: quality) else { return nil }
        return upper + lower
    }
    out.append(0x90)
    out += length
    out += jpeg
    return [out]
}

/// A CGImage over a region of the frame (copied: the capture recycles its buffers).
public func cgImage(_ frame: Frame, _ rect: Rect) -> CGImage? {
    let data: Data = frame.withPixels { base, stride in
        var bytes = Data(capacity: rect.area * 4)
        for y in rect.y ..< rect.maxY {
            bytes.append(base.advanced(by: y * stride + rect.x * 4), count: rect.width * 4)
        }
        return bytes
    }
    guard let provider = CGDataProvider(data: data as CFData) else { return nil }
    let info = CGBitmapInfo(rawValue: CGBitmapInfo.byteOrder32Little.rawValue | CGImageAlphaInfo.noneSkipFirst.rawValue)
    return CGImage(width: rect.width, height: rect.height, bitsPerComponent: 8, bitsPerPixel: 32, bytesPerRow: rect.width * 4,
                   space: CGColorSpace(name: CGColorSpace.sRGB)!, bitmapInfo: info, provider: provider, decode: nil,
                   shouldInterpolate: false, intent: .defaultIntent)
}

public func jpegData(_ image: CGImage, quality: Int) -> [UInt8]? {
    let output = NSMutableData()
    guard let destination = CGImageDestinationCreateWithData(output, UTType.jpeg.identifier as CFString, 1, nil) else { return nil }
    CGImageDestinationAddImage(destination, image, [kCGImageDestinationLossyCompressionQuality: Double(quality) / 100] as CFDictionary)
    guard CGImageDestinationFinalize(destination) else { return nil }
    return [UInt8](output as Data)
}

func jpegData(_ frame: Frame, _ rect: Rect, quality: Int) -> [UInt8]? {
    guard let image = cgImage(frame, rect) else { return nil }
    return jpegData(image, quality: quality)
}

/// A JPEG thumbnail of the frame, scaled to fit `maxWidth` x `maxHeight` (the Screen hero's preview).
public func thumbnailJPEG(_ frame: Frame, maxWidth: Int, maxHeight: Int, quality: Int) -> [UInt8]? {
    guard let full = cgImage(frame, frame.bounds) else { return nil }
    let scale = min(1, Double(maxWidth) / Double(frame.width), Double(maxHeight) / Double(frame.height))
    let width = max(1, Int(Double(frame.width) * scale)), height = max(1, Int(Double(frame.height) * scale))
    guard let context = CGContext(data: nil, width: width, height: height, bitsPerComponent: 8, bytesPerRow: 0,
                                  space: CGColorSpace(name: CGColorSpace.sRGB)!, bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue)
    else { return nil }
    context.interpolationQuality = .medium
    context.draw(full, in: CGRect(x: 0, y: 0, width: width, height: height))
    guard let scaled = context.makeImage() else { return nil }
    return jpegData(scaled, quality: quality)
}
