import CoreGraphics
import Foundation

/// RFB 3.8 with security type None on a private Unix socket (the Hermes display bridge authenticates
/// the viewer and gates input by the control lease before any byte reaches this socket; the plugin also
/// tells this server who holds the lease, so input the bridge forwarded just before a hand-back is refused).
///
/// Pull model: each client has at most one update in flight, answered when a new frame exists, so a
/// slow link throttles itself and an idle screen sends nothing. Capture runs only while a client is
/// connected.
public final class RFBServer {
    public struct Options {
        public var name: String
        /// Input is honoured only with control allowed (`--control`), a person holding the lease
        /// (`setHumanControl`), sharing not paused, and the Mac unlocked (unless `allowUnlock`).
        public var allowControl: Bool
        public var allowUnlock: Bool
        /// Where the captured display sits in global screen points (pointer mapping), for a source that
        /// does not report its own live `displayBounds`.
        public var displayFrame: CGRect
        public var captureStopDelay: TimeInterval
        public var maxClients: Int
        public var handshakeTimeout = HelperDeadlines.handshake
        public var messageTimeout = HelperDeadlines.message
        public var writeTimeout = HelperDeadlines.write
        /// Offer H.264 to clients that ask for it. Off by default: noVNC holds each update until the
        /// previous frame is painted, and a WebCodecs decoder that keeps one frame back (seen in the iOS
        /// Simulator's WebKit) then never paints. Tight-JPEG always paints at once.
        public var h264: Bool
        public init(name: String = "This Mac", allowControl: Bool = false, allowUnlock: Bool = false,
                    displayFrame: CGRect = .zero, captureStopDelay: TimeInterval = 5, maxClients: Int = 8, h264: Bool = false) {
            self.name = name; self.allowControl = allowControl; self.allowUnlock = allowUnlock
            self.displayFrame = displayFrame; self.captureStopDelay = captureStopDelay; self.maxClients = maxClients
            self.h264 = h264
        }
    }

    public let source: FrameSource
    public let input: InputSink?
    public var isLocked: () -> Bool = { false }
    public var log: (String) -> Void = { _ in }
    /// Called (on any thread) with the client count whenever it changes, and when input is applied.
    public var onClientsChanged: ((Int) -> Void)?
    public var onInput: (() -> Void)?

    let condition = NSCondition()
    /// Serializes input across every viewer: a viewer's translate-and-post, a release of what a viewer
    /// holds (a takeover by another viewer, hand-back to the agent, control switched off, Stop sharing, a
    /// disconnect, capture ending) and the claim of control. Without it a release on another thread could
    /// post its key-up between a viewer's translated key-down and that key-down's post, leaving the key
    /// down on the Mac with nothing tracking it. Taken before `condition`, never while holding it;
    /// recursive, because a claim releases the previous controller from inside a viewer's own apply.
    let inputLock = NSRecursiveLock()
    private(set) var options: Options
    private var listener: UnixListener?
    private var sessions: [ObjectIdentifier: RFBSession] = [:]
    private(set) var latest: Frame?
    private var serial: UInt64 = 0
    private var history: [(serial: UInt64, dirty: [Rect])] = []
    private var capturing = false
    fileprivate var starting = false
    private var stopped = false
    private var captureGeneration: UInt64 = 0
    private let captureQueue = DispatchQueue(label: "dispatch-screen.transitions")
    private var stopWork: DispatchWorkItem?
    private var paused = false
    /// A person holds the control lease (the gateway plugin says so on every transition). Written under
    /// `inputLock` and `condition`, read under either: the bridge forwards input only from the holder, but
    /// an event already on this socket when the person hands back would otherwise be posted after the
    /// hand-back's release, leaving its key or button down under the agent.
    private var humanControl = false
    private var captureError: String?
    /// The session whose input was applied last: one viewer controls at a time (the bridge gates input
    /// by the lease), so input from another session means the previous one lost control.
    private weak var inputSession: RFBSession?
    private var deliveries: [Date] = []
    private(set) var bytesSent: UInt64 = 0
    private(set) var inputEvents: UInt64 = 0

    public init(source: FrameSource, input: InputSink?, options: Options) {
        self.source = source
        self.input = input
        self.options = options
    }

    // MARK: lifecycle

    public func listen(path: String) throws {
        let listener = try UnixListener(path: path)
        self.listener = listener
        let thread = Thread { [weak self] in
            while let connection = listener.accept() {
                self?.admit(connection)
            }
        }
        thread.name = "dispatch-screen.accept"
        thread.start()
        log("listening on \(path)")
    }

    public func stop() {
        listener?.close()
        listener = nil
        condition.lock(); stopped = true; stopCaptureLocked(); condition.unlock()
        disconnectAll()
    }

    public func disconnectAll() {
        condition.lock()
        let all = Array(sessions.values)
        condition.unlock()
        all.forEach { $0.close() }
    }

    public var clientCount: Int { condition.lock(); defer { condition.unlock() }; return sessions.count }
    /// Input actions applied since launch (diagnostics; never what they were).
    public var inputCount: UInt64 { condition.lock(); defer { condition.unlock() }; return inputEvents }
    public var isCapturing: Bool { condition.lock(); defer { condition.unlock() }; return capturing }
    public var latestFrame: Frame? { condition.lock(); defer { condition.unlock() }; return latest }
    public var currentOptions: Options { condition.lock(); defer { condition.unlock() }; return options }

    /// Frames delivered in the last second.
    public var fps: Int {
        condition.lock(); defer { condition.unlock() }
        let cutoff = Date().addingTimeInterval(-1)
        return deliveries.filter { $0 > cutoff }.count
    }

    public func update(_ change: (inout Options) -> Void) {
        inputLock.lock(); defer { inputLock.unlock() }
        condition.lock(); change(&options); condition.unlock()
    }

    /// "Stop sharing" from the Mac: everyone is disconnected and nobody is admitted until resumed.
    public func setPaused(_ value: Bool) {
        inputLock.lock(); defer { inputLock.unlock() }
        condition.lock(); paused = value; if value { stopCaptureLocked() }; condition.unlock()
        if value { disconnectAll() }
    }
    public var isPaused: Bool { condition.lock(); defer { condition.unlock() }; return paused }
    public var isHumanInControl: Bool { condition.lock(); defer { condition.unlock() }; return humanControl }

    /// The lease changed hands (`human` nil: unchanged). Back to the agent, what any viewer holds is lifted in
    /// the same critical section that stops accepting input, so no viewer's event lands between the two;
    /// `releaseInput` lifts it on any transition (a takeover from another person, a take-and-hand-back that
    /// never flipped `human`).
    public func setHumanControl(_ human: Bool?, releaseInput: Bool = false) {
        inputLock.lock(); defer { inputLock.unlock() }
        condition.lock()
        let was = humanControl
        if let human { humanControl = human }
        let handedBack = was && !humanControl
        condition.unlock()
        if handedBack || releaseInput { releaseHeldInput() }
    }
    /// Why capture last ended on its own (nil once a capture starts cleanly).
    public var lastCaptureError: String? { condition.lock(); defer { condition.unlock() }; return captureError }

    /// macOS ended the capture (the grant was revoked or re-asked, a display was reconfigured): viewers
    /// would freeze on the last frame while still steering a desktop they cannot see, so they are
    /// disconnected (releasing anything they held). Only a fresh viewer starts capture again.
    public func captureFailed(_ reason: String) {
        condition.lock()
        guard capturing else { captureError = reason; condition.unlock(); return }
        stopCaptureLocked()
        captureError = reason
        let all = Array(sessions.values)
        condition.unlock()
        log("capture ended: \(reason); disconnecting viewers")
        all.forEach { $0.close() }
    }

    /// Release whatever every viewer still holds: control went back to the agent mid-gesture or was
    /// switched off, the bridge dropped the viewer's own release, and nothing may inherit a pressed
    /// button or ⌘. Serialized with every viewer's input (see `inputLock`).
    public func releaseHeldInput() {
        inputLock.lock(); defer { inputLock.unlock() }
        condition.lock()
        let all = Array(sessions.values)
        condition.unlock()
        all.forEach { $0.releaseHeld() }
    }

    private func admit(_ connection: SocketConnection) {
        // The socket is 0600 in a 0700 directory; the uid check keeps it this user's even if a mode slips.
        guard connection.peerUID == getuid() else { connection.close(); return }
        condition.lock()
        if stopped || paused || sessions.count >= options.maxClients {
            condition.unlock()
            log(stopped ? "refused a viewer: stopping" : paused ? "refused a viewer: sharing is paused" : "refused a viewer: too many clients")
            connection.close()
            return
        }
        connection.readTimeout = nil
        connection.readDeadline = ProcessInfo.processInfo.systemUptime + options.handshakeTimeout
        connection.writeTimeout = options.writeTimeout
        let session = RFBSession(server: self, connection: connection)
        sessions[ObjectIdentifier(session)] = session
        let count = sessions.count
        stopWork?.cancel(); stopWork = nil
        if !capturing { startCaptureLocked() }
        condition.unlock()
        log("viewer connected (\(count))")
        onClientsChanged?(count)
        session.start()
    }

    func remove(_ session: RFBSession) {
        condition.lock()
        guard sessions.removeValue(forKey: ObjectIdentifier(session)) != nil else { condition.unlock(); return }
        let count = sessions.count
        if count == 0 {
            // Keep capture briefly: a reconnect (new ticket, lease flip) should not restart ScreenCaptureKit.
            let work = DispatchWorkItem { [weak self] in
                guard let self else { return }
                self.condition.lock()
                if self.sessions.isEmpty { self.stopCaptureLocked() }
                self.condition.unlock()
            }
            stopWork = work
            DispatchQueue.global().asyncAfter(deadline: .now() + options.captureStopDelay, execute: work)
        }
        condition.broadcast()
        condition.unlock()
        log("viewer disconnected (\(count))")
        onClientsChanged?(count)
    }

    private func startCaptureLocked() {
        capturing = true; starting = true
        captureGeneration &+= 1
        let generation = captureGeneration
        captureQueue.async { [self] in
            condition.lock()
            let wanted = capturing && captureGeneration == generation
            condition.unlock()
            guard wanted else { return }
            do {
                try source.start { [weak self] frame in self?.deliver(frame, generation: generation) }
                condition.lock()
                let current = capturing && captureGeneration == generation
                if current { starting = false; captureError = nil; condition.broadcast() }
                condition.unlock()
                // A stop invalidates the generation immediately, even while start is still in flight.
                if !current { source.stop() }
            } catch {
                condition.lock()
                let current = capturing && captureGeneration == generation
                var all: [RFBSession] = []
                if current {
                    stopCaptureLocked()
                    captureError = String(describing: error)
                    all = Array(sessions.values)
                }
                condition.unlock()
                log("capture failed to start: \(error)")
                all.forEach { $0.close() }
            }
        }
    }

    private func stopCaptureLocked() {
        guard capturing else { return }
        capturing = false; starting = false
        captureGeneration &+= 1
        latest = nil
        history.removeAll()
        stopWork?.cancel(); stopWork = nil
        condition.broadcast()
        captureQueue.async { [source] in source.stop() }
    }

    // MARK: frames

    private func deliver(_ incoming: Frame, generation: UInt64) {
        condition.lock()
        guard capturing, captureGeneration == generation else { condition.unlock(); return }
        serial += 1
        let frame = Frame(buffer: incoming.buffer, serial: serial, dirty: incoming.dirty, capturedAt: incoming.capturedAt)
        latest = frame
        history.append((serial, frame.dirty))
        if history.count > 64 { history.removeFirst(history.count - 64) }
        let now = Date()
        deliveries.append(now)
        deliveries.removeAll { now.timeIntervalSince($0) > 1 }
        condition.broadcast()
        condition.unlock()
    }

    /// Caller holds `condition`. What changed after `since`; nil when that frame fell out of history.
    func dirtyLocked(since: UInt64) -> [Rect]? {
        guard let oldest = history.first?.serial, since + 1 >= oldest else { return nil }
        return history.filter { $0.serial > since }.flatMap { $0.dirty }
    }

    func accountSent(_ bytes: Int) {
        condition.lock(); bytesSent += UInt64(bytes); condition.unlock()
    }

    // MARK: input

    /// Caller holds `inputLock` when it goes on to post, so a hand-back cannot land between check and post.
    func inputAllowed() -> Bool {
        condition.lock()
        let allowed = options.allowControl && !paused && humanControl
        let unlock = options.allowUnlock
        condition.unlock()
        return allowed && (unlock || !isLocked())
    }

    func perform(_ actions: [InputAction]) {
        guard !actions.isEmpty, let input else { return }
        actions.forEach(input.perform)
        condition.lock(); inputEvents += UInt64(actions.count); condition.unlock()
        onInput?()
    }

    /// `session` is about to apply input. A different session that applied input before has lost
    /// control (a takeover through another bot's pane never evicts it), so what it holds is released.
    func claimInput(_ session: RFBSession) {
        inputLock.lock(); defer { inputLock.unlock() }
        condition.lock()
        let previous = inputSession
        inputSession = session
        condition.unlock()
        if let previous, previous !== session { previous.releaseHeld() }
    }

    /// Screen points for a framebuffer coordinate of the current frame.
    func pointMapper() -> (Double, Double) -> (Double, Double) {
        let live = source.displayBounds
        condition.lock()
        let frame = live.flatMap { $0.width > 0 ? $0 : nil } ?? options.displayFrame
        let width = Double(latest?.width ?? 0), height = Double(latest?.height ?? 0)
        condition.unlock()
        return { x, y in
            guard width > 0, height > 0, frame.width > 0 else { return (x, y) }
            return (frame.minX + x * frame.width / width, frame.minY + y * frame.height / height)
        }
    }
}

/// One viewer: a reader thread parsing client messages (input applies at once) and a writer thread
/// answering update requests.
final class RFBSession {
    private let server: RFBServer
    private let connection: SocketConnection
    private var alive = true
    // Guarded by server.condition:
    private var format = PixelFormat.native
    private var encodings: [Int32] = [Encoding.raw]
    private var quality: Int?
    private var pendingFull = false
    private var pendingIncremental = false
    private var lastSerial: UInt64 = 0
    private var lastSize: (Int, Int)?
    private var h264: H264Encoder?
    private var h264Quality = 7
    private var refusedInputLogged = false
    // Guarded by server.inputLock:
    private var translator = InputTranslator()

    init(server: RFBServer, connection: SocketConnection) {
        self.server = server
        self.connection = connection
    }

    func start() {
        let reader = Thread { [self] in
            do {
                try handshake()
                let writer = Thread { [self] in writeLoop() }
                writer.name = "dispatch-screen.writer"
                writer.start()
                try readLoop()
            } catch {
                if case SocketError.closed = error {} else { server.log("viewer ended: \(error)") }
            }
            close()
        }
        reader.name = "dispatch-screen.reader"
        reader.start()
    }

    func close() {
        server.inputLock.lock(); defer { server.inputLock.unlock() }
        server.condition.lock()
        let wasAlive = alive
        alive = false
        server.condition.broadcast()
        server.condition.unlock()
        connection.close()
        guard wasAlive else { return }
        // Whatever the gate says now (Stop sharing, control off, a locked Mac): lifting what this viewer
        // pressed is not new input, and skipping it leaves the Mac with a button or ⌘ held down.
        releaseHeld()
        server.remove(self)
    }

    /// Lift every button and key this viewer still holds (nothing when it holds none). Under the input
    /// lock, so it lands after any translated input of this viewer's that is being posted, never between.
    func releaseHeld() {
        server.inputLock.lock(); defer { server.inputLock.unlock() }
        let (x, y) = server.pointMapper()(0, 0)
        server.perform(translator.releaseAll(x: x, y: y))
    }

    private var isAlive: Bool { server.condition.lock(); defer { server.condition.unlock() }; return alive }

    // MARK: handshake

    private func handshake() throws {
        try connection.write(Array("RFB 003.008\n".utf8))
        let version = String(decoding: try connection.read(12), as: UTF8.self)
        guard version.hasPrefix("RFB 003.") else { throw SocketError.closed }
        let minor = Int(version.dropFirst(8).prefix(3)) ?? 8
        if minor >= 7 {
            try connection.write([1, 1])                  // one security type: None
            guard try connection.readByte() == 1 else { throw SocketError.closed }
            if minor >= 8 { try connection.write([0, 0, 0, 0]) }  // SecurityResult OK
        } else {
            try connection.write([0, 0, 0, 1])            // 3.3: the server picks None
        }
        _ = try connection.readByte()                     // ClientInit: always shared
        let (width, height) = try waitForFirstFrame()
        var initMessage: [UInt8] = []
        initMessage.put16(UInt16(width)); initMessage.put16(UInt16(height))
        initMessage += PixelFormat.native.bytes
        let name = Array(server.currentOptions.name.utf8)
        initMessage.put32(UInt32(name.count)); initMessage += name
        try connection.write(initMessage)
        server.condition.lock(); lastSize = (width, height); server.condition.unlock()
    }

    /// ServerInit needs the framebuffer size: wait (briefly) for the capture's first frame.
    private func waitForFirstFrame() throws -> (Int, Int) {
        let deadline = Date().addingTimeInterval(max(0, (connection.readDeadline ?? ProcessInfo.processInfo.systemUptime) - ProcessInfo.processInfo.systemUptime))
        server.condition.lock(); defer { server.condition.unlock() }
        while (server.latest == nil || server.starting), alive, Date() < deadline { _ = server.condition.wait(until: deadline) }
        guard alive, !server.starting, let frame = server.latest else { throw SocketError.system("no frame from \(server.source.name) before the handshake deadline", ETIMEDOUT) }
        return (frame.width, frame.height)
    }

    // MARK: client → server

    private func readLoop() throws {
        while true {
            connection.readDeadline = nil
            let type = try connection.readByte()
            connection.readDeadline = ProcessInfo.processInfo.systemUptime + server.currentOptions.messageTimeout
            switch type {
            case 0:  // SetPixelFormat
                let body = try connection.read(19)
                if let parsed = PixelFormat(bytes: Array(body[3...])) {
                    server.condition.lock(); format = parsed; server.condition.unlock()
                }
            case 2:  // SetEncodings
                let head = try connection.read(3)
                let count = Int(head.u16(1))
                let raw = try connection.read(count * 4)
                let list = (0 ..< count).map { raw.s32($0 * 4) }
                server.condition.lock()
                encodings = list
                let q = list.first(where: Encoding.isQuality).map { Int($0 + 32) }
                quality = q
                server.condition.unlock()
            case 3:  // FramebufferUpdateRequest
                let body = try connection.read(9)
                server.condition.lock()
                if body[0] != 0 { pendingIncremental = true } else { pendingFull = true }
                server.condition.broadcast()
                server.condition.unlock()
            case 4:  // KeyEvent
                let body = try connection.read(7)
                apply { $0.key(body.u32(3), down: body[0] != 0) }
            case 5:  // PointerEvent (6 bytes: ExtendedMouseButtons is never acknowledged)
                let body = try connection.read(5)
                let mapper = server.pointMapper()
                let time = ProcessInfo.processInfo.systemUptime
                apply { $0.pointer(mask: body[0], x: Int(body.u16(1)), y: Int(body.u16(3)), scale: mapper, time: time) }
            case 6:  // ClientCutText (Latin-1; a negative length is the extended form, not advertised)
                let head = try connection.read(7)
                let length = Int(head.s32(3))
                guard abs(length) <= 256 * 1024 else { throw SocketError.system("clipboard too large", EMSGSIZE) }
                let text = try connection.read(abs(length))
                if length > 0 {
                    let string = String(text.map { Character(Unicode.Scalar($0)) })
                    apply(clipboard: true) { _ in [.pasteboard(string)] }
                }
            case 150:  // EnableContinuousUpdates: never acknowledged, ignored
                _ = try connection.read(9)
            case 248:  // Fence: never acknowledged, ignored
                let head = try connection.read(8)
                _ = try connection.read(Int(head[7]))
            case 251:  // SetDesktopSize: the Mac's display is never resized from a phone
                // padding(1) width(2) height(2) number-of-screens(1) padding(1), then 16 bytes per screen.
                let head = try connection.read(7)
                _ = try connection.read(Int(head[5]) * 16)
            case 255:  // QEMU client message (not advertised)
                _ = try connection.read(11)
            default:
                throw SocketError.system("unknown RFB client message \(type)", EPROTO)
            }
        }
    }

    /// Translate and post one event as a single step under the input lock: a release from another thread
    /// waits until it is posted, and this viewer, once closed or refused, posts nothing more. While the
    /// lock is held no other viewer can claim control, so the claim made here still stands at the post.
    private func apply(clipboard: Bool = false, _ translate: (inout InputTranslator) -> [InputAction]) {
        func step() {
            self.server.inputLock.lock(); defer { self.server.inputLock.unlock() }
            // Closed meanwhile (Stop sharing, capture ended, the stream dropped): its release already ran.
            guard self.isAlive else { return }
            guard self.server.inputAllowed() else {
                if !self.refusedInputLogged { self.refusedInputLogged = true; self.server.log("input ignored: control is off, no person holds it, sharing is paused or the Mac is locked") }
                // Refused mid-gesture (the Mac locked, control switched off, handed back to the agent): the
                // release this event may carry is dropped with it, so lift what is held rather than leave it pressed.
                self.releaseHeld()
                // A refused clipboard must not become a stale paste if the gate reopens (control back on, the
                // Mac unlocked, the next takeover) before the ⌘V right behind it on this socket.
                if clipboard { self.close() }
                return
            }
            self.server.claimInput(self)
            self.server.perform(translate(&self.translator))
        }
        // Only pasteboard needs the platform executor. Releases never wait on main under inputLock.
        if clipboard, let executor = server.input as? InputMutationExecutor { executor.executeMutation(step) }
        else { step() }
    }

    // MARK: server → client

    private func writeLoop() {
        while true {
            server.condition.lock()
            while alive && !ready() { server.condition.wait() }
            guard alive, let frame = server.latest else { server.condition.unlock(); return }
            let size = (frame.width, frame.height)
            let resized = lastSize.map { $0 != size } ?? true
            let full = pendingFull || resized
            let changed = (server.dirtyLocked(since: lastSerial) ?? [frame.bounds]).map { $0.aligned(to: 16, within: frame.bounds) }
            let rects: [Rect] = full ? [frame.bounds] : coalesce(changed, within: frame.bounds)
            pendingFull = false
            pendingIncremental = false
            lastSerial = frame.serial
            lastSize = size
            let format = self.format, encodings = self.encodings, quality = self.quality
            server.condition.unlock()
            do {
                let message = try encode(frame, rects: rects, full: full, resized: resized, format: format, encodings: encodings, quality: quality)
                try connection.write(message)
                server.accountSent(message.count)
            } catch {
                close()
                return
            }
        }
    }

    /// Caller holds the condition.
    private func ready() -> Bool {
        guard let frame = server.latest else { return false }
        return pendingFull || (pendingIncremental && (frame.serial > lastSerial || lastSize.map { $0 != (frame.width, frame.height) } ?? true))
    }

    private func encode(_ frame: Frame, rects: [Rect], full: Bool, resized: Bool, format: PixelFormat, encodings: [Int32], quality: Int?) throws -> [UInt8] {
        var body: [UInt8] = []
        var count = 0
        if resized {
            if encodings.contains(Encoding.extendedDesktopSize) {
                body += rectHeader(Rect(x: 0, y: 0, width: frame.width, height: frame.height), Encoding.extendedDesktopSize)
                body += [1, 0, 0, 0]                                     // one screen
                body.put32(0); body.put16(0); body.put16(0)
                body.put16(UInt16(frame.width)); body.put16(UInt16(frame.height)); body.put32(0)
                count += 1
            } else if encodings.contains(Encoding.desktopSize) {
                body += rectHeader(Rect(x: 0, y: 0, width: frame.width, height: frame.height), Encoding.desktopSize)
                count += 1
            }
        }
        let offered = server.currentOptions.h264 ? [Encoding.h264, Encoding.tight, Encoding.raw] : [Encoding.tight, Encoding.raw]
        let preferred = encodings.first { offered.contains($0) } ?? Encoding.raw
        if preferred == Encoding.h264, let encoded = encodeH264(frame, keyframe: full, quality: quality) {
            body += rectHeader(frame.bounds, Encoding.h264)
            body.put32(UInt32(encoded.data.count))
            body.put32(encoded.reset ? 1 : 0)
            body += encoded.data
            count += 1
        } else {
            for rect in rects {
                if preferred == Encoding.tight, let quality, let tight = encodeTightJPEG(frame, rect, format: format, quality: jpegQuality[max(0, min(9, quality))]) {
                    tight.forEach { body += $0 }
                    count += tight.count
                } else {
                    body += encodeRaw(frame, rect, format: format)
                    count += 1
                }
            }
        }
        var message: [UInt8] = [0, 0]
        message.put16(UInt16(count))
        return message + body
    }

    private func encodeH264(_ frame: Frame, keyframe: Bool, quality: Int?) -> (data: [UInt8], reset: Bool)? {
        var reset = false
        let q = quality ?? 7
        if h264 == nil || h264!.width != frame.width || h264!.height != frame.height {
            h264 = H264Encoder(width: frame.width, height: frame.height, bitrate: H264Encoder.bitrate(quality: q, width: frame.width, height: frame.height))
            h264Quality = q
            reset = true
        }
        guard let h264 else { return nil }
        if h264Quality != q { h264.setBitrate(H264Encoder.bitrate(quality: q, width: h264.width, height: h264.height)); h264Quality = q }
        if keyframe { h264.requestKeyframe() }
        guard let encoded = h264.encode(frame.buffer) else { return nil }
        return (encoded.data, reset)
    }
}
