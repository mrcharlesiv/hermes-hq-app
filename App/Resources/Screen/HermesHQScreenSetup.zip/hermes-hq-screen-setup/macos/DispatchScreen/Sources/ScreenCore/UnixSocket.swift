import Darwin
import Foundation

public enum SocketError: Error, CustomStringConvertible {
    case system(String, Int32)
    case timeout
    case closed
    case pathTooLong(String)

    public var description: String {
        switch self {
        case let .system(what, code): return "\(what): \(String(cString: strerror(code)))"
        case .timeout: return "socket deadline exceeded"
        case .closed: return "connection closed"
        case let .pathTooLong(path): return "socket path too long: \(path)"
        }
    }
}

/// A connected stream socket with blocking exact reads and serialized whole writes.
public final class SocketConnection {
    public let fd: Int32
    private let writeLock = NSLock()
    private var isClosed = false
    private let closeLock = NSLock()

    // Read settings belong to the sole reader; writeTimeout is set before starting the writer.
    public var readTimeout: TimeInterval? = HelperDeadlines.client
    public var readDeadline: TimeInterval?
    public var writeTimeout: TimeInterval = HelperDeadlines.write
    private let onClose: () -> Void

    public init(fd: Int32, onClose: @escaping () -> Void = {}) {
        self.fd = fd; self.onClose = onClose
        var on: Int32 = 1
        setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &on, socklen_t(MemoryLayout<Int32>.size))
    }

    private func wait(_ events: Int16, until deadline: TimeInterval?) throws {
        while true {
            closeLock.lock(); let closed = isClosed; closeLock.unlock()
            if closed { throw SocketError.closed }
            let remaining = deadline.map { $0 - ProcessInfo.processInfo.systemUptime }
            if let remaining, remaining <= 0 { throw SocketError.timeout }
            // Short polls also notice close without depending on descriptor reuse or cross-thread wakeup.
            let milliseconds = Int32(min(100, max(1, (remaining ?? 0.1) * 1000)))
            var item = pollfd(fd: fd, events: events, revents: 0)
            let result = poll(&item, 1, milliseconds)
            if result > 0 { return }
            if result < 0 && errno != EINTR { throw SocketError.system("poll", errno) }
        }
    }

    /// Reads exactly `count` bytes; an absolute deadline spans all reads of a protocol message.
    public func read(_ count: Int) throws -> [UInt8] {
        let deadline = readDeadline ?? readTimeout.map { ProcessInfo.processInfo.systemUptime + $0 }
        var out = [UInt8](repeating: 0, count: count)
        var got = 0
        while got < count {
            try wait(Int16(POLLIN), until: deadline)
            closeLock.lock()
            if isClosed { closeLock.unlock(); throw SocketError.closed }
            let n = out.withUnsafeMutableBytes { buffer in
                recv(fd, buffer.baseAddress!.advanced(by: got), count - got, MSG_DONTWAIT)
            }
            let code = errno
            closeLock.unlock()
            if n == 0 { throw SocketError.closed }
            if n < 0 {
                if code == EINTR || code == EAGAIN { continue }
                throw SocketError.system("read", code)
            }
            got += n
        }
        return out
    }

    public func readByte() throws -> UInt8 { try read(1)[0] }

    public func write(_ bytes: [UInt8]) throws {
        writeLock.lock(); defer { writeLock.unlock() }
        var sent = 0
        var deadline = ProcessInfo.processInfo.systemUptime + writeTimeout
        while sent < bytes.count {
            try wait(Int16(POLLOUT), until: deadline)
            closeLock.lock()
            if isClosed { closeLock.unlock(); throw SocketError.closed }
            let n = bytes.withUnsafeBytes { buffer in
                send(fd, buffer.baseAddress!.advanced(by: sent), bytes.count - sent, MSG_DONTWAIT)
            }
            let code = errno
            closeLock.unlock()
            if n == 0 { throw SocketError.closed }
            if n < 0 {
                if code == EINTR || code == EAGAIN { continue }
                throw SocketError.system("write", code)
            }
            sent += n
            deadline = ProcessInfo.processInfo.systemUptime + writeTimeout
        }
    }

    public var peerUID: uid_t? {
        closeLock.lock(); defer { closeLock.unlock() }
        guard !isClosed else { return nil }
        var uid: uid_t = 0, gid: gid_t = 0
        return getpeereid(fd, &uid, &gid) == 0 ? uid : nil
    }

    public func close() {
        closeLock.lock()
        if isClosed { closeLock.unlock(); return }
        isClosed = true
        shutdown(fd, SHUT_RDWR)
        Darwin.close(fd)
        closeLock.unlock()
        onClose()
    }
    deinit { close() }
}

/// A listening Unix socket, created 0600 inside a 0700 directory.
public final class UnixListener {
    public let path: String
    private let fd: Int32

    private let lock = NSLock()
    private var closed = false
    private var live = 0
    private let maxConnections: Int
    private let readTimeout: TimeInterval

    public init(path: String, maxConnections: Int = 16, readTimeout: TimeInterval = HelperDeadlines.control) throws {
        self.maxConnections = maxConnections; self.readTimeout = readTimeout
        self.path = path
        let dir = (path as NSString).deletingLastPathComponent
        try FileManager.default.createDirectory(atPath: dir, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        chmod(dir, 0o700)
        unlink(path)
        fd = socket(AF_UNIX, SOCK_STREAM, 0)
        if fd < 0 { throw SocketError.system("socket", errno) }
        var address = sockaddr_un()
        address.sun_family = sa_family_t(AF_UNIX)
        let bytes = Array(path.utf8)
        guard bytes.count < MemoryLayout.size(ofValue: address.sun_path) else { Darwin.close(fd); throw SocketError.pathTooLong(path) }
        withUnsafeMutableBytes(of: &address.sun_path) { raw in
            raw.copyBytes(from: bytes)
            raw[bytes.count] = 0
        }
        // The umask decides the mode bind() creates the file with: never let it be group/world reachable.
        let previous = umask(0o077)
        let bound = withUnsafePointer(to: &address) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { bind(fd, $0, socklen_t(MemoryLayout<sockaddr_un>.size)) }
        }
        umask(previous)
        if bound != 0 { let code = errno; Darwin.close(fd); throw SocketError.system("bind \(path)", code) }
        chmod(path, 0o600)
        _ = fcntl(fd, F_SETFL, O_NONBLOCK)
        if listen(fd, 16) != 0 { let code = errno; Darwin.close(fd); throw SocketError.system("listen", code) }
    }

    /// Blocks for the next connection; nil once the listener is closed.
    public func accept() -> SocketConnection? {
        while true {
            // A nonblocking accept under the lifecycle lock prevents using a recycled descriptor.
            lock.lock()
            if closed { lock.unlock(); return nil }
            let client = Darwin.accept(fd, nil, nil)
            let code = errno
            if client >= 0 {
                if live >= maxConnections { lock.unlock(); Darwin.close(client); continue }
                live += 1
                lock.unlock()
                let connection = SocketConnection(fd: client) { [self] in
                    lock.lock(); live -= 1; lock.unlock()
                }
                connection.readTimeout = nil
                connection.readDeadline = ProcessInfo.processInfo.systemUptime + readTimeout
                return connection
            }
            lock.unlock()
            if code == EINTR || code == ECONNABORTED { continue }
            if code != EAGAIN { return nil }
            // The timeout only bounds how long a closed listener's thread lingers: keep an idle helper quiet.
            var item = pollfd(fd: fd, events: Int16(POLLIN), revents: 0)
            _ = poll(&item, 1, 1000)
        }
    }

    public func close() {
        lock.lock(); defer { lock.unlock() }
        guard !closed else { return }
        closed = true
        Darwin.close(fd)
        unlink(path)
    }

}

/// Connects to a Unix socket (tests and the control client).
public func connectUnix(_ path: String) throws -> SocketConnection {
    let fd = socket(AF_UNIX, SOCK_STREAM, 0)
    if fd < 0 { throw SocketError.system("socket", errno) }
    var address = sockaddr_un()
    address.sun_family = sa_family_t(AF_UNIX)
    let bytes = Array(path.utf8)
    guard bytes.count < MemoryLayout.size(ofValue: address.sun_path) else { Darwin.close(fd); throw SocketError.pathTooLong(path) }
    withUnsafeMutableBytes(of: &address.sun_path) { raw in
        raw.copyBytes(from: bytes)
        raw[bytes.count] = 0
    }
    _ = fcntl(fd, F_SETFL, O_NONBLOCK)
    let result = withUnsafePointer(to: &address) {
        $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { Darwin.connect(fd, $0, socklen_t(MemoryLayout<sockaddr_un>.size)) }
    }
    if result != 0 {
        let code = errno
        guard code == EINPROGRESS || code == EAGAIN else { Darwin.close(fd); throw SocketError.system("connect \(path)", code) }
        var item = pollfd(fd: fd, events: Int16(POLLOUT), revents: 0)
        guard poll(&item, 1, Int32(HelperDeadlines.client * 1000)) > 0 else { Darwin.close(fd); throw SocketError.timeout }
        var error: Int32 = 0, size = socklen_t(MemoryLayout<Int32>.size)
        guard getsockopt(fd, SOL_SOCKET, SO_ERROR, &error, &size) == 0, error == 0 else {
            Darwin.close(fd); throw SocketError.system("connect \(path)", error)
        }
    }
    _ = fcntl(fd, F_SETFL, 0)
    let connection = SocketConnection(fd: fd)
    connection.readDeadline = ProcessInfo.processInfo.systemUptime + HelperDeadlines.client
    return connection
}

// Big-endian wire helpers.
extension Array where Element == UInt8 {
    mutating func put16(_ value: UInt16) { append(UInt8(value >> 8)); append(UInt8(value & 0xff)) }
    mutating func put32(_ value: UInt32) { put16(UInt16(value >> 16)); put16(UInt16(value & 0xffff)) }
    mutating func putS32(_ value: Int32) { put32(UInt32(bitPattern: value)) }
    func u16(_ at: Int) -> UInt16 { UInt16(self[at]) << 8 | UInt16(self[at + 1]) }
    func u32(_ at: Int) -> UInt32 { UInt32(u16(at)) << 16 | UInt32(u16(at + 2)) }
    func s32(_ at: Int) -> Int32 { Int32(bitPattern: u32(at)) }
}
