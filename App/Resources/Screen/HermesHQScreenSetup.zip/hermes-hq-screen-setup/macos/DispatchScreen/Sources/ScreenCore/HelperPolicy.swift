import Foundation
import CoreFoundation

public enum DisplayResolution: Equatable {
    case use(UInt32), selectedMissing(UInt32), mainMissing(UInt32)
}

public func resolveDisplay(requested: UInt32?, main: UInt32, available: [UInt32]) -> DisplayResolution {
    let wanted = requested ?? main
    if available.contains(wanted) { return .use(wanted) }
    return requested == nil ? .mainMissing(wanted) : .selectedMissing(wanted)
}

public enum LockState { case unlocked, locked, unknown }
public struct LockSignal {
    public var screenLocked = false
    public var sessionResigned = false
    public init(screenLocked: Bool = false, sessionResigned: Bool = false) {
        self.screenLocked = screenLocked; self.sessionResigned = sessionResigned
    }
}

public func consoleLockState(session: [String: Any]?, notified: LockSignal) -> LockState {
    if notified.screenLocked || notified.sessionResigned { return .locked }
    guard let session else { return .unknown }
    func boolean(_ key: String) -> Bool? {
        guard let value = session[key] as? NSNumber, CFGetTypeID(value) == CFBooleanGetTypeID() else { return nil }
        return value.boolValue
    }
    if boolean("CGSSessionScreenIsLocked") == true { return .locked }
    if session["CGSSessionScreenIsLocked"] != nil && boolean("CGSSessionScreenIsLocked") == nil { return .unknown }
    if boolean("kCGSSessionOnConsoleKey") == false || boolean("kCGSessionLoginDoneKey") == false { return .locked }
    guard boolean("kCGSSessionOnConsoleKey") == true, boolean("kCGSessionLoginDoneKey") == true else { return .unknown }
    return .unlocked
}

public enum HelperDeadlines {
    public static let content: TimeInterval = 3 // Listing must not hold a thumbnail request indefinitely.
    public static let captureStart: TimeInterval = 5 // Allow ScreenCaptureKit to establish a stream.
    public static let captureStop: TimeInterval = 3 // Shutdown must move on even if macOS does not reply.
    public static let screenshot: TimeInterval = 3 // Bound the thumbnail's hold on the helper lock.
    public static let control: TimeInterval = 2 // A partial control line must not retain a worker.
    public static let client: TimeInterval = 10 // Accommodate capture startup, but bound CLI reads and connects.
    public static let handshake: TimeInterval = 10 // Unauthenticated peers must relinquish viewer slots.
    public static let message: TimeInterval = 2 // Bound a started frame without timing out an idle viewer.
    public static let write: TimeInterval = 5 // Drop a viewer that makes no write progress.
}

public struct HelperTimeout: Error, CustomStringConvertible {
    public let operation: String
    public var description: String { "\(operation) timed out" }
}

private final class DeadlineResult<T> {
    let lock = NSLock()
    let ready = DispatchSemaphore(value: 0)
    var result: Result<T, Error>?
    var expired = false

    func finish(_ result: Result<T, Error>, release: () -> Void, undo: (T) async -> Void) async {
        if publish(result, release: release) {
            if case let .success(value) = result { await undo(value) }
            release()
        }
    }
    private func publish(_ value: Result<T, Error>, release: () -> Void) -> Bool {
        lock.lock(); defer { lock.unlock() }
        if expired { return true }
        release()
        result = value; ready.signal()
        return false
    }
    func take() -> Result<T, Error>? {
        lock.lock(); defer { lock.unlock() }
        if let result { return result }
        expired = true
        return nil
    }
}

public struct HelperBusy: Error, CustomStringConvertible {
    public var description: String { "Screen capture is still waiting for macOS; try again later" }
}

/// A timed-out operation keeps its slot until it finishes cleanup; retries cannot grow orphan tasks.
public final class HelperDeadlineRunner {
    private let workers: DispatchSemaphore
    public init(maxPending: Int = 1) { workers = DispatchSemaphore(value: maxPending) }

    public func run<T>(_ operation: String, seconds: TimeInterval,
                       undo: @escaping (T) async -> Void = { _ in },
                       body: @escaping () async throws -> T) throws -> T {
        guard workers.wait(timeout: .now()) == .success else { throw HelperBusy() }
        let state = DeadlineResult<T>()
        let workers = self.workers
        let task = Task.detached {
            let result: Result<T, Error>
            do { result = .success(try await body()) } catch { result = .failure(error) }
            await state.finish(result, release: { workers.signal() }, undo: undo)
        }
        _ = state.ready.wait(timeout: .now() + seconds)
        if let result = state.take() { return try result.get() }
        task.cancel()
        throw HelperTimeout(operation: operation)
    }
}

private let sharedDeadlineRunner = HelperDeadlineRunner(maxPending: 8)

/// Cancellation is cooperative; a late successful start still owns its cleanup after the caller leaves.
public func withHelperDeadline<T>(_ operation: String, seconds: TimeInterval,
                                  undo: @escaping (T) async -> Void = { _ in },
                                  body: @escaping () async throws -> T) throws -> T {
    try sharedDeadlineRunner.run(operation, seconds: seconds, undo: undo, body: body)
}

/// The executor is entered before acquiring the input lock, so a main-thread Stop never waits on itself.
public protocol InputMutationExecutor: InputSink {
    func executeMutation(_ body: () -> Void)
}
