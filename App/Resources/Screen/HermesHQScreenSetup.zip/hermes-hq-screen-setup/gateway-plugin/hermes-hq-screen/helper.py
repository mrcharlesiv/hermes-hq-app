"""The Hermes HQ Screen helper, seen from the gateway: host-wide settings, launch and signature
check, the control socket, and the per-profile ``bot-desktop/rfb.sock`` symlinks the core display
bridge dials.

Everything lives under ``<hermes root>/hermes-hq-screen/`` (0700): ``settings.json`` (written only by
``hermes hq-screen enable/disable`` at the Mac), and the helper's own ``rfb.sock``, ``ctl.sock``,
``helper.log`` and ``sharing_paused``. One Mac has one console, so this state is host-wide, not per
profile.

This plugin was called dispatch-screen and its app "Dispatch Screen.app". The first time this plugin
looks at its state on a host that only has the old ``<hermes root>/dispatch-screen/``, it copies the old
settings across (the old folder is left as it was) and asks the old helper to quit; an old app is used
only while the renamed one is not installed (same bundle id, so macOS keeps its Screen Recording grant).
"""
from __future__ import annotations

import json
import logging
import os
import socket
import subprocess
import threading
import time
from pathlib import Path
from typing import Any, Optional

log = logging.getLogger("hermes-hq-screen")

# Unchanged by the rename: macOS ties the Screen Recording and Accessibility grants to it.
BUNDLE_ID = "com.charlesmcdowell.dispatch.screen"
STATE_NAME = "hermes-hq-screen"
LEGACY_STATE_NAME = "dispatch-screen"
APP_NAME = "Hermes HQ Screen.app"
LEGACY_APP_NAME = "Dispatch Screen.app"
EXECUTABLE = "DispatchScreen"
# State files carried over from the old folder (never sockets, pids or locks: those belong to a live helper).
LEGACY_STATE_FILES = ("settings.json", "holder.json", "sharing_paused", "setup-state.json")
MIGRATION_MARKER = "migrated-from-dispatch-screen"
# DisplayStatus.display for a shared Mac console (clients key their Mac affordances on it).
DISPLAY_NAME = "This Mac"
DEFAULTS: dict[str, Any] = {
    "enabled": False,
    "allow_control": False,
    "profiles": "all",
    "max_width": 1920,
    "display": "main",
    "idle_minutes": 30,
    # H.264 streaming (VideoToolbox + WebCodecs): off until verified on a phone; Tight-JPEG otherwise.
    "h264": False,
    "stale_human_lease_minutes": 15,
    "helper_path": "/Applications/" + APP_NAME,
    # Team IDs the helper's signature may carry; empty = any team (never an ad-hoc signature).
    "team_ids": [],
}

BLOCK_DISABLED = "Screen sharing is off on this Mac. Choose Set up with Hermes to enable it"
BLOCK_MISSING = "The Hermes HQ Screen helper is missing from the Mac. Choose Set up with Hermes to install it"
BLOCK_UNSIGNED = "The Hermes HQ Screen helper on the Mac needs a valid signature from an allowed team. Choose Set up with Hermes to check it"
BLOCK_PAUSED = "Sharing was stopped from the Mac's menu bar. Resume it there"
BLOCK_TCC = "Allow Screen Recording for Hermes HQ Screen on the Mac (System Settings › Privacy & Security)"
BLOCK_PROFILE = "Screen sharing is not enabled for this bot. Ask the gateway owner to give this bot access"


def root() -> Path:
    from hermes_constants import get_default_hermes_root
    return Path(get_default_hermes_root())


def state_dir() -> Path:
    base = root()
    migrate_legacy_state(base)
    return base / STATE_NAME


def legacy_state_dir() -> Path:
    return root() / LEGACY_STATE_NAME


_migrated: set[str] = set()


def migrate_legacy_state(base: Path) -> bool:
    """Once per host: copy the old dispatch-screen state (settings, the control holder, a pause) into this
    plugin's folder, then ask a helper still serving the old folder to quit (it would otherwise keep its
    menu bar item and capture until it idles out). Nothing is overwritten and the old folder is kept, so
    the old plugin still works if it is put back. True when something was copied."""
    key = str(base)
    if key in _migrated:
        return False
    _migrated.add(key)
    new, old = Path(base) / STATE_NAME, Path(base) / LEGACY_STATE_NAME
    try:
        if (new / MIGRATION_MARKER).exists() or not old.is_dir() or old.is_symlink() or new.is_symlink():
            return False
        copied = False
        _private_dir(new)
        for name in LEGACY_STATE_FILES:
            source, target = old / name, new / name
            if target.exists() or source.is_symlink() or not source.is_file():
                continue
            tmp = target.with_name(f".{name}.migrating")
            with open(source, "rb") as src, open(tmp, "wb", opener=lambda p, f: os.open(p, f, 0o600)) as dst:
                dst.write(src.read())
            os.replace(tmp, target)
            copied = True
        (new / MIGRATION_MARKER).write_text(str(old) + "\n", encoding="utf-8")
    except OSError as exc:
        _migrated.discard(key)
        log.warning("hermes-hq-screen: could not copy the old dispatch-screen settings: %s", exc)
        return False
    stop_legacy_helper(old)
    if copied:
        log.info("hermes-hq-screen: carried the dispatch-screen settings over from %s (left in place)", old)
    return copied


def stop_legacy_helper(old: Optional[Path] = None) -> bool:
    """Ask a helper started by the old plugin (it serves the old folder) to quit. True when one answered."""
    path = Path(old or legacy_state_dir()) / "ctl.sock"
    if not path.exists():
        return False
    return _ctl_at(path, {"cmd": "stop"}, timeout=1.0) is not None


def legacy_plugin_loaded() -> bool:
    """The old dispatch-screen plugin is loaded in this process too (both installed): this one takes over."""
    import sys
    return any(name in sys.modules for name in ("dispatch_screen_adapter", "dispatch_screen_helper", "dispatch_screen_cli"))


def _private_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    os.chmod(path, 0o700)
    return path


# ── settings ──────────────────────────────────────────────────────────────────────────────────

def settings() -> dict[str, Any]:
    try:
        raw = json.loads((state_dir() / "settings.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        raw = {}
    return {**DEFAULTS, **{k: v for k, v in (raw if isinstance(raw, dict) else {}).items() if k in DEFAULTS}}


def save_settings(values: dict[str, Any]) -> dict[str, Any]:
    current = {**settings(), **{k: v for k, v in values.items() if k in DEFAULTS}}
    path = _private_dir(state_dir()) / "settings.json"
    tmp = path.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8", opener=lambda p, f: os.open(p, f, 0o600)) as fh:
        json.dump(current, fh, indent=1, sort_keys=True)
    os.replace(tmp, path)
    return current


def profile_allowed(profile: str, current: Optional[dict] = None) -> bool:
    allowed = (current or settings()).get("profiles", "all")
    return allowed == "all" or (isinstance(allowed, list) and profile in allowed)


def profile_name(home: Path) -> str:
    """The profile a home belongs to: "default" for the root home, else the profile's folder name."""
    return "default" if Path(home).resolve() == root().resolve() else Path(home).name


def revoked_homes(before: dict, current: dict) -> list[Path]:
    """Homes whose profile was allowed under ``before`` and is not under ``current``."""
    return [home for home in known_homes()
            if profile_allowed(profile_name(home), before) and not profile_allowed(profile_name(home), current)]


# ── the helper app ────────────────────────────────────────────────────────────────────────────

def app_path(current: Optional[dict] = None) -> Path:
    """The configured helper app, read through the rename: a setting that still names "Dispatch
    Screen.app" uses "Hermes HQ Screen.app" beside it once that is installed, and the renamed path falls
    back to an old app beside it while only that one is installed."""
    configured = Path(str((current or settings())["helper_path"])).expanduser()
    if configured.name == LEGACY_APP_NAME:
        candidates = [configured.with_name(APP_NAME), configured]
    elif configured.name == APP_NAME:
        candidates = [configured, configured.with_name(LEGACY_APP_NAME)]
    else:
        candidates = [configured]
    return next((path for path in candidates if (path / "Contents" / "MacOS" / EXECUTABLE).exists()), configured)


def binary(current: Optional[dict] = None) -> Path:
    return app_path(current) / "Contents" / "MacOS" / EXECUTABLE


_signature_cache: dict[tuple, Optional[str]] = {}


def signature_problem(current: Optional[dict] = None) -> Optional[str]:
    """None when the helper is installed and signed as expected (bundle id, a team, an allowed team),
    else the blocker. The launch goes through LaunchServices, so macOS grants belong to this app; a
    swapped binary must not inherit them (cua-driver's check, the same way)."""
    current = current or settings()
    app = app_path(current)
    try:
        stamp = (str(app), (app / "Contents" / "MacOS" / EXECUTABLE).stat().st_mtime_ns, tuple(current.get("team_ids") or ()))
    except OSError:
        return BLOCK_MISSING
    if stamp in _signature_cache:
        return _signature_cache[stamp]
    try:
        out = subprocess.run(["/usr/bin/codesign", "-dv", "--verbose=2", str(app)], capture_output=True, text=True, timeout=10)
        info = dict(line.split("=", 1) for line in (out.stderr or "").splitlines() if "=" in line)
        verify = subprocess.run(["/usr/bin/codesign", "--verify", "--strict", str(app)], capture_output=True, timeout=20)
    except (OSError, subprocess.SubprocessError):
        return BLOCK_UNSIGNED
    team = info.get("TeamIdentifier", "not set")
    teams = current.get("team_ids") or []
    ok = (verify.returncode == 0 and info.get("Identifier") == BUNDLE_ID and team not in ("", "not set")
          and (not teams or team in teams))
    _signature_cache[stamp] = None if ok else BLOCK_UNSIGNED
    return _signature_cache[stamp]


def ctl(request: dict[str, Any], timeout: float = 2.0) -> Optional[dict[str, Any]]:
    """One control-socket round trip, or None when the helper is not running."""
    path = state_dir() / "ctl.sock"
    if not path.exists():
        return None
    return _ctl_at(path, request, timeout)


def _ctl_at(path: Path, request: dict[str, Any], timeout: float) -> Optional[dict[str, Any]]:
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            sock.connect(str(path))
            sock.sendall(json.dumps(request).encode() + b"\n")
            data = b""
            while not data.endswith(b"\n"):
                chunk = sock.recv(65536)
                if not chunk:
                    break
                data += chunk
        answer = json.loads(data or b"null")
        return answer if isinstance(answer, dict) else None
    except (OSError, ValueError):
        return None


def helper_status(timeout: float = 2.0) -> Optional[dict[str, Any]]:
    answer = ctl({"cmd": "status"}, timeout=timeout)
    return answer if answer and answer.get("ok") else None


def paused() -> bool:
    return (state_dir() / "sharing_paused").exists()


def launch_argv(current: dict[str, Any]) -> list[str]:
    args = ["serve", "--state", str(state_dir()), "--max-width", str(int(current.get("max_width") or 1920)),
            "--idle-minutes", str(float(current.get("idle_minutes") or 30))]
    if current.get("allow_control"):
        args.append("--control")
    if current.get("h264"):
        args.append("--h264")
    if str(current.get("display") or "main") != "main":
        args += ["--display", str(current["display"])]
    # LaunchServices, not a child process: macOS attributes Screen Recording and Accessibility to the
    # app bundle (as Hermes launches CuaDriver.app), and the helper outlives a gateway restart.
    return ["/usr/bin/open", "-n", "-g", "-a", str(app_path(current)), "--args", *args]


# A launch that didn't come up (a Screen Recording prompt waiting at the Mac, a helper crashing as it starts) isn't
# tried again for this long: a phone retrying its Screen would otherwise start another instance (`open -n`) and hold
# an RPC worker for up to 21 s on every try. One launch at a time; callers meanwhile wait for its answer.
LAUNCH_BACKOFF_S = 45.0
_launch_lock = threading.Lock()
_launch_failed_at: Optional[float] = None


def ensure_running(current: Optional[dict] = None, wait: float = 6.0) -> Optional[dict[str, Any]]:
    """The running helper's status, launching it first when sharing is on and nothing blocks it."""
    global _launch_failed_at
    current = current or settings()
    status = helper_status()
    if status is not None:
        return status
    if blocker(current, status=None) is not None:
        return None
    with _launch_lock:
        status = helper_status()  # launched by the caller this one waited for
        if status is not None:
            return status
        if _launch_failed_at is not None and time.monotonic() - _launch_failed_at < LAUNCH_BACKOFF_S:
            return None
        _private_dir(state_dir())
        try:
            subprocess.run(launch_argv(current), capture_output=True, timeout=15, check=False)
        except (OSError, subprocess.SubprocessError) as exc:
            log.warning("hermes-hq-screen: helper launch failed: %s", exc)
            _launch_failed_at = time.monotonic()
            return None
        deadline = time.monotonic() + wait
        while time.monotonic() < deadline:
            status = helper_status()
            if status is not None:
                _launch_failed_at = None
                return status
            time.sleep(0.1)
        _launch_failed_at = time.monotonic()
        log.warning("hermes-hq-screen: helper did not answer within %.0fs (see %s); not launching it again for %.0fs",
                    wait, state_dir() / "helper.log", LAUNCH_BACKOFF_S)
        return None


def blocker(current: Optional[dict] = None, status: Optional[dict] = ..., profile: Optional[str] = None) -> Optional[str]:
    """Why this profile's screen cannot be shown right now, in the words the phone shows; None = it can."""
    current = current or settings()
    if profile is not None and not profile_allowed(profile, current):
        return BLOCK_PROFILE
    if not current.get("enabled"):
        return BLOCK_DISABLED
    problem = signature_problem(current)
    if problem:
        return problem
    if paused():
        return BLOCK_PAUSED
    if status is ...:
        status = helper_status()
    if status is not None and not (status.get("tcc") or {}).get("screen", True):
        return BLOCK_TCC
    return None


# ── the core bridge's socket path ─────────────────────────────────────────────────────────────

def link_path(home: Path) -> Path:
    return Path(home) / "bot-desktop" / "rfb.sock"


def ensure_link(home: Path) -> Optional[Path]:
    """``<home>/bot-desktop/rfb.sock`` → the helper's socket: the core bridge dials that path directly."""
    target = state_dir() / "rfb.sock"
    if not target.exists():
        return None
    link = link_path(home)
    _private_dir(link.parent)
    try:
        if link.is_symlink() and os.readlink(link) == str(target):
            return link
        if link.is_symlink() or link.exists():
            link.unlink()
        os.symlink(str(target), str(link))
    except OSError as exc:
        log.warning("hermes-hq-screen: cannot link %s: %s", link, exc)
        return None
    return link


def remove_links(homes: list[Path]) -> None:
    targets = {str(state_dir() / "rfb.sock"), str(legacy_state_dir() / "rfb.sock")}
    for home in homes:
        link = link_path(home)
        try:
            if link.is_symlink() and os.readlink(link) in targets:
                link.unlink()
        except OSError:
            pass


def known_homes() -> list[Path]:
    """The root home and every profile home (the places a link may have been made)."""
    base = root()
    homes = [base]
    profiles = base / "profiles"
    if profiles.is_dir():
        homes += [p for p in sorted(profiles.iterdir()) if p.is_dir() and not p.name.startswith(".")]
    return homes
