"""A darwin backend for Hermes' Bot Screen, installed over ``tools.bot_desktop`` at runtime.

Core keeps everything security-relevant: display tickets, the control lease, the RfbClientFilter
input gate, eviction, thumbnail suppression while a human holds control, and ``computer_use``'s
lease fence. This module only supplies the backend: ``runtime.status/start/stop/rfb_socket_path``
answer from the Hermes HQ Screen helper, ``thumbnail`` asks the helper, and the lease file becomes
host-wide (one Mac, one console: a takeover from any bot's pane fences every bot).

Every patch point is checked against the shapes of the pinned Hermes (77a799e) first; on any drift
nothing is patched and the host stays "no screen here" (upstream will replace this with a
screen-backend hook). Patches apply only on macOS.
"""
from __future__ import annotations

import inspect
import logging
import sys
from pathlib import Path
from typing import Any, Callable, Optional

log = logging.getLogger("hermes-hq-screen")

P = inspect.Parameter
# name → [(parameter, kind, default)]: the pinned signatures this adapter replaces.
EXPECTED: dict[str, list[tuple[str, Any, Any]]] = {
    "runtime.is_supported_host": [],
    "runtime.status": [("profile", P.POSITIONAL_OR_KEYWORD, None)],
    "runtime.start": [("wait_seconds", P.KEYWORD_ONLY, 15.0)],
    "runtime.stop": [],
    "runtime.rfb_socket_path": [],
    "runtime.stop_if_idle": [],
    "runtime.ensure_started_for_tool": [],
    "runtime.install_command": [],
    "runtime._profile_name": [],
    "thumbnail.thumbnail_data_url": [("max_size", P.POSITIONAL_OR_KEYWORD, (960, 600)), ("quality", P.POSITIONAL_OR_KEYWORD, 72)],
    "lease._path": [("profile_key", P.POSITIONAL_OR_KEYWORD, P.empty)],
    "lease._notify": [("key", P.POSITIONAL_OR_KEYWORD, P.empty), ("lease", P.POSITIONAL_OR_KEYWORD, P.empty)],
    "lease._read": [("path", P.POSITIONAL_OR_KEYWORD, P.empty)],
    "lease._write": [("path", P.POSITIONAL_OR_KEYWORD, P.empty), ("lease", P.POSITIONAL_OR_KEYWORD, P.empty)],
    "lease._locked": [("path", P.POSITIONAL_OR_KEYWORD, P.empty)],
}
STATUS_FIELDS = ["profile", "supported", "installed", "missing", "running", "pid", "display", "socket", "geometry",
                 "install_command", "browser", "blocker", "memory_available_mb", "memory_limit_mb"]
# Newer Hermes can place Linux screens inside a terminal sandbox. Its two additive
# status fields have safe defaults for this Mac console; other additions still fail closed.
PLACEMENT_STATUS_DEFAULTS = {"placement": "gateway", "image_switch": None}
# Core call sites whose behaviour the adapter relies on (checked in their source text).
SOURCE_CONTRACTS = {
    "tui_gateway.methods_display": ["from tools.bot_desktop import runtime as _bd_runtime", "_bd_runtime.rfb_socket_path() is None",
                                    "from tools.bot_desktop.thumbnail import thumbnail_data_url"],
    "hermes_cli.web_routers.display": ["RfbClientFilter(_may_send_input)"],
    "tools.bot_desktop.lease": ["def _transition(profile_key", "_path(profile_key)", "_notify(key, lease)"],
}
# display.* that answer from the helper (a launch, the signature check, a ctl round trip) run on the RPC
# pool: inline, a slow one holds up every other RPC on the phone's one /api/ws, the heartbeat included.
DISPLAY_LONG_HANDLERS = frozenset({"display.status", "display.observe", "display.start", "display.stop", "display.thumbnail"})

_originals: dict[str, Callable] = {}
_installed: set[str] = set()


def _modules():
    from tools.bot_desktop import lease, runtime, thumbnail
    return {"runtime": runtime, "thumbnail": thumbnail, "lease": lease}


def _router_socket_problem(module, text: str) -> Optional[str]:
    """Both known router layouts must dial the ticket's profile-specific socket."""
    if 'Path(info["hermes_home"]) / "bot-desktop" / "rfb.sock"' in text:
        return None
    bridge = getattr(module, "_bridge", None)
    opener = getattr(module, "_open_rfb", None)
    try:
        bridge_source, opener_source = inspect.getsource(bridge), inspect.getsource(opener)
        params = [(p.name, p.kind, p.default) for p in inspect.signature(opener).parameters.values()]
    except (TypeError, ValueError, OSError):
        return "display router has no supported profile socket route"
    if params != [("profile_home", P.POSITIONAL_OR_KEYWORD, P.empty)]:
        return "display._open_rfb no longer accepts one profile_home"
    if not all(needle in bridge_source for needle in (
        'profile_home = str(info["hermes_home"])', 'await _open_rfb(Path(profile_home))')):
        return "display._bridge no longer opens the ticket's profile socket"
    if not all(needle in opener_source for needle in (
        'sock = profile_home / "bot-desktop" / "rfb.sock"',
        'await asyncio.open_unix_connection(str(sock))',
        'if _bd_runtime.sandbox_screen_running():')):
        return "display._open_rfb no longer has the supported profile Unix socket branch"
    return None


def verify_shapes() -> list[str]:
    """Everything that differs from the pinned Hermes this adapter was written against ([] = safe)."""
    problems: list[str] = []
    try:
        mods = _modules()
    except Exception as exc:  # noqa: BLE001 - an import failure is drift too
        return [f"tools.bot_desktop import failed: {exc}"]
    for dotted, params in EXPECTED.items():
        module, name = dotted.split(".")
        # Once patched, the shape that matters is the one this adapter replaced.
        fn = _originals.get(f"{mods[module].__name__}.{name}", getattr(mods[module], name, None))
        if not callable(fn):
            problems.append(f"{dotted} is missing")
            continue
        try:
            got = [(p.name, p.kind, p.default) for p in inspect.signature(fn).parameters.values()]
        except (TypeError, ValueError):
            problems.append(f"{dotted} has no signature")
            continue
        if got != params:
            problems.append(f"{dotted}{inspect.signature(fn)} differs from the pinned shape")
    field_map = getattr(mods["runtime"].DesktopStatus, "__dataclass_fields__", {})
    fields = list(field_map)
    modern_fields = STATUS_FIELDS + list(PLACEMENT_STATUS_DEFAULTS)
    if fields not in (STATUS_FIELDS, modern_fields):
        problems.append(f"runtime.DesktopStatus fields {fields} differ from {STATUS_FIELDS}")
    elif fields == modern_fields:
        for name, expected in PLACEMENT_STATUS_DEFAULTS.items():
            if field_map[name].default != expected:
                problems.append(f"runtime.DesktopStatus.{name} default differs from {expected!r}")
    sandbox_running = getattr(mods["runtime"], "sandbox_screen_running", None)
    if sandbox_running is not None:
        original = _originals.get(f"{mods['runtime'].__name__}.sandbox_screen_running", sandbox_running)
        try:
            if list(inspect.signature(original).parameters):
                problems.append("runtime.sandbox_screen_running no longer accepts zero arguments")
        except (TypeError, ValueError):
            problems.append("runtime.sandbox_screen_running has no signature")
    for module_name, needles in SOURCE_CONTRACTS.items():
        try:
            module = __import__(module_name, fromlist=["_"])
            text = inspect.getsource(module)
        except Exception as exc:  # noqa: BLE001
            problems.append(f"{module_name} unreadable: {exc}")
            continue
        problems += [f"{module_name} no longer contains {needle!r}" for needle in needles if needle not in text]
        if module_name == "hermes_cli.web_routers.display":
            problem = _router_socket_problem(module, text)
            if problem:
                problems.append(problem)
            if hasattr(module, "_open_rfb") and sandbox_running is None:
                problems.append("display._open_rfb requires runtime.sandbox_screen_running")
    return problems


def _patch(module, name: str, replacement: Callable) -> None:
    key = f"{module.__name__}.{name}"
    _originals.setdefault(key, getattr(module, name))
    setattr(module, name, replacement)
    _installed.add(key)


def uninstall() -> None:
    for key, original in list(_originals.items()):
        module_name, name = key.rsplit(".", 1)
        setattr(sys.modules[module_name], name, original)
    _originals.clear()
    _installed.clear()


def installed() -> bool:
    return bool(_installed)


def host_lease_path(_profile_key: Optional[str] = None) -> Path:
    from hermes_constants import get_default_hermes_root
    return Path(get_default_hermes_root()) / "bot-desktop" / "lease.json"


def profile_homes() -> list[Path]:
    """The root home and every profile home."""
    from hermes_constants import get_default_hermes_root
    root = Path(get_default_hermes_root())
    profiles = root / "profiles"
    return [root] + ([p for p in sorted(profiles.iterdir()) if p.is_dir() and not p.name.startswith(".")] if profiles.is_dir() else [])


class MirrorFailed(RuntimeError):
    """Some profile homes' copies of the lease could not be written (every other home was still tried)."""

    def __init__(self, failures: list[tuple[str, Path, BaseException]]):
        self.failures = failures
        super().__init__("; ".join(f"{name}: {_reason(exc)}" for name, _path, exc in failures))


class NotFenced(RuntimeError):
    """A person's takeover, rolled back because a bot could not be paused (the phone shows the text)."""


def _reason(exc: BaseException) -> str:
    return getattr(exc, "strerror", None) or str(exc) or type(exc).__name__


def in_step(have, current) -> bool:
    """A profile copy matches the host lease: the same holder, viewer, reason and ``since`` (a new value on
    every transition, so a takeover and hand-back between two mirrors still reads as a change), and an
    epoch no lower than the host's. A copy may run ahead of the host's epoch (see ``mirrored``)."""
    return ((have.holder, have.viewer_id, have.reason, have.since) == (current.holder, current.viewer_id, current.reason, current.since)
            and have.epoch >= current.epoch)


def mirrored(have, current):
    """The host lease as a profile copy whose epoch only ever rises. core's computer_use compares the epoch
    it was admitted under with the copy's after acting (tools/computer_use/tool.py _fence): a copy that kept
    its epoch through a person's turn, or went back to an older one, would pass a frame captured meanwhile."""
    import dataclasses
    return dataclasses.replace(current, epoch=max(current.epoch, have.epoch + 1))


def host_lease(lease, host: Path):
    """The host lease, written once when there is none yet (the caller holds the host lock). Core reads a
    missing file as a fresh Lease() whose ``since`` is the moment of reading: every mirror would see a new
    transition and bump each copy's epoch, failing any computer_use action that spans a watcher tick as if
    a person had taken over."""
    import dataclasses
    current = lease._read(host)
    if host.exists():
        return current
    try:
        lease._write(host, current)
    except OSError:  # an unwritable root home: a missing file then compares as one lease that never changes
        return dataclasses.replace(current, since=0.0)
    return current


def mirror_lease() -> list[str]:
    """Copy the host-wide lease into each profile home's own lease file (the profiles brought in step).

    A Hermes process started with HERMES_HOME=<profile home> (a kanban worker, a per-profile chat) finds
    plugins under that home only, so it never loads this one and its computer_use fence reads
    <profile home>/bot-desktop/lease.json. Kept in step, that file fences it too.

    The host lease is read and every copy written under the host lease's lock (then each profile's, always
    in that order; nothing takes them the other way round): a takeover can't land between the read and
    the copies, so a stale "agent" is never written over a person's control. A home whose copy can't be
    written (permissions, a full disk) doesn't stop the others; MirrorFailed names each one afterwards."""
    lease = _modules()["lease"]
    host = host_lease_path()
    changed: list[str] = []
    failures: list[tuple[str, Path, BaseException]] = []
    with lease._locked(host):
        current = host_lease(lease, host)
        for home in profile_homes():
            path = home / "bot-desktop" / "lease.json"
            if path == host:
                continue
            try:
                with lease._locked(path):
                    have = lease._read(path)  # a missing file reads as the agent's
                    if not in_step(have, current):
                        lease._write(path, mirrored(have, current))
                        changed.append(home.name)
            except Exception as exc:  # noqa: BLE001 - reported below; the other homes still get their copy
                failures.append((home.name, path, exc))
    if failures:
        raise MirrorFailed(failures)
    return changed


def unfenced(failures: list[tuple[str, Path, BaseException]]) -> list[tuple[str, Path, BaseException]]:
    """The failed homes whose copy still lets that profile's computer_use act (it doesn't say "human")."""
    lease = _modules()["lease"]
    return [failure for failure in failures if lease._read(failure[1]).holder != lease.HUMAN]


def holder_path() -> Path:
    return _helper().state_dir() / "holder.json"


def record_holder(key: str, lease) -> None:
    """Which profile a person took control through (core's lease names only the viewer): narrowing the
    allowed profiles (``enable --profiles``) hands control back when that profile loses access."""
    import json
    import os
    if lease.holder != "human" or not lease.viewer_id:
        return
    path = holder_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    os.chmod(path.parent, 0o700)
    tmp = path.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8", opener=lambda p, f: os.open(p, f, 0o600)) as fh:
        json.dump({"viewer_id": lease.viewer_id, "profile_key": key}, fh)
    os.replace(tmp, path)


def holder_profile_key(viewer_id: Optional[str]) -> Optional[str]:
    """The profile key a person took control through, when the record is for this viewer."""
    import json
    try:
        record = json.loads(holder_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if not isinstance(record, dict) or not viewer_id or record.get("viewer_id") != viewer_id:
        return None
    key = record.get("profile_key")
    return key if isinstance(key, str) else None


def profile_leases() -> dict[str, str]:
    """Each profile home's copy against the host-wide lease (``doctor``)."""
    lease = _modules()["lease"]
    current = lease.get()
    return {home.name: "in step" if in_step(have, current)
            else "out of step: hermes serve with this plugin brings it in step within a second"
            for home in profile_homes() if (path := home / "bot-desktop" / "lease.json") != host_lease_path()
            for have in [lease._read(path)]}


def _helper():
    """The sibling helper module, the same instance __init__.load gives every other part of the plugin."""
    import importlib.util
    key = "hermes_hq_screen_helper"
    if key not in sys.modules:
        spec = importlib.util.spec_from_file_location(key, Path(__file__).with_name("helper.py"))
        module = importlib.util.module_from_spec(spec)
        sys.modules[key] = module
        spec.loader.exec_module(module)
    return sys.modules[key]


def tell_helper(lease) -> None:
    """Every lease transition reaches the helper as it happens, releasing whatever the last controller still
    presses (r5-54). The watcher samples the lease about once a second: a takeover and hand-back inside one
    tick never flipped its human_control, so the helper never lifted a held button or modifier, and the
    core filter drops the late key-up of a viewer that no longer holds, leaving it down under the agent.
    The helper also refuses input while the agent holds (r6-77: an event the filter forwarded just before a
    hand-back would otherwise land after the release). This runs inside the transition, after the lease file
    is written and before core's listeners run and the acquire answers the phone: a new controller's first
    events find the helper told, and nothing it pressed can be lifted. Not running (or slow): the watcher's
    next tick catches up."""
    try:
        human = lease.holder == _modules()["lease"].HUMAN
        _helper().ctl({"cmd": "set", "human_control": human, "release_input": True}, timeout=0.5)
    except Exception:  # noqa: BLE001 - never let the menu bar or input release block a lease change
        log.debug("hermes-hq-screen: could not tell the helper about a lease change", exc_info=True)


def _host_wide_notify(original: Callable) -> Callable:
    def _notify(key, lease):
        tell_helper(lease)
        # Core names only the acquiring profile, and each display bridge ignores other profiles' keys:
        # a takeover through another bot's pane would never evict this Mac's previous controller.
        try:
            record_holder(key, lease)
        except Exception:  # noqa: BLE001 - without it, narrowing the profiles releases any person's hold
            log.warning("hermes-hq-screen: could not record which profile holds control", exc_info=True)
        try:
            mirror_lease()
        except MirrorFailed as exc:
            # A person's control that some profile's own processes can't see: their computer_use would keep
            # acting under the person (typing a credential included). The takeover is undone before anyone
            # hears of it and the phone is told why; the watcher retries the copies every second.
            if lease.holder == _modules()["lease"].HUMAN and (open_homes := unfenced(exc.failures)):
                _roll_back(key, lease)
                names = ", ".join(f"{name} ({_reason(error)})" for name, _path, error in open_homes)
                raise NotFenced(f"Couldn't pause every bot, so control wasn't taken. The Mac couldn't update the control "
                                f"lease for {names}. Check that profile's folder on the Mac, then try again.") from exc
            log.warning("hermes-hq-screen: could not mirror the lease into the profile homes: %s", exc)
        except Exception:  # noqa: BLE001 - the watcher repeats the mirror every second
            log.warning("hermes-hq-screen: could not mirror the lease into the profile homes", exc_info=True)
        from hermes_constants import hermes_home_key
        keys = [key] + [k for k in dict.fromkeys(hermes_home_key(home) for home in profile_homes()) if k != key]
        for each in keys:
            original(each, lease)
    return _notify


def _roll_back(key, lease) -> None:
    """Hand an unfenced takeover straight back, by holder (a takeover landing meanwhile is kept). The release
    is an ordinary transition: it mirrors again and tells every profile that the agent holds."""
    try:
        _modules()["lease"].release(lease.viewer_id, profile_key=key)
    except Exception:  # noqa: BLE001 - the takeover is refused either way
        log.warning("hermes-hq-screen: could not hand an unfenced takeover back", exc_info=True)


def report_unfenced_takeovers(server) -> bool:
    """display.lease.acquire answers a NotFenced refusal as a display error the phone shows, instead of the
    "internal error" an uncaught exception becomes on the socket. False while the handler isn't registered."""
    methods = getattr(server, "_methods", None)
    handler = methods.get("display.lease.acquire") if isinstance(methods, dict) else None
    if handler is None or not callable(getattr(server, "_err", None)):
        return False
    if getattr(handler, "_hermes_hq_screen_unfenced", False):
        return True

    def acquire(rid, params):
        try:
            return handler(rid, params)
        except NotFenced as exc:
            return server._err(rid, 5300, str(exc), data={"code": "not_fenced"})
    acquire._hermes_hq_screen_unfenced = True
    methods["display.lease.acquire"] = acquire
    return True


LEGACY_ADAPTER = "dispatch_screen_adapter"


def retire_legacy() -> bool:
    """The old dispatch-screen plugin loaded in this process as well (both installed until setup removes the
    old one): put back what it patched so only this plugin answers the Screen and fences computer_use, never
    both. Called before this plugin patches and again from the serve loop. The old plugin is only ever
    undone when it patched after this one (its saved originals are then this plugin's own functions) or
    before this one patched anything (they are Hermes's). True when the old one was undone now."""
    legacy = sys.modules.get(LEGACY_ADAPTER)
    if legacy is None or legacy is sys.modules.get(__name__):
        return False
    installed_fn, uninstall_fn = getattr(legacy, "installed", None), getattr(legacy, "uninstall", None)
    if not callable(installed_fn) or not callable(uninstall_fn) or not installed_fn():
        return False
    uninstall_fn()
    log.warning("hermes-hq-screen: the old dispatch-screen plugin is still installed; it was switched off in this "
                "process. Remove it: hermes plugins remove dispatch-screen")
    return True


def install_agent_side(*, platform: str = sys.platform) -> bool:
    """Every process that loads this plugin and can run ``computer_use`` (serve, the messaging gateway,
    cron, the CLI): the lease is host-wide, so a person controlling the Mac from any bot's Screen
    fences all of them, and every profile hears each change. Processes that never load it (started
    with a profile's HERMES_HOME) read the profile's own copy, kept in step by ``mirror_lease``."""
    if platform != "darwin":
        return False
    retire_legacy()
    problems = verify_shapes()
    if problems:
        log.warning("hermes-hq-screen: Hermes changed shape; screen sharing stays off: %s", "; ".join(problems))
        return False
    mods = _modules()
    _patch(mods["lease"], "_path", host_lease_path)
    if f"{mods['lease'].__name__}._notify" not in _installed:
        _patch(mods["lease"], "_notify", _host_wide_notify(mods["lease"]._notify))
    return True


def route_display_off_the_socket() -> bool:
    """Register DISPLAY_LONG_HANDLERS with the gateway (core modules extend the set the same way), and
    let an unfenced takeover's refusal reach the phone; False until ``tui_gateway.server`` is loaded in
    this process (and until the acquire handler is registered)."""
    server = sys.modules.get("tui_gateway.server")
    handlers = getattr(server, "_LONG_HANDLERS", None) if server is not None else None
    if not isinstance(handlers, frozenset):
        return False
    server._LONG_HANDLERS = handlers | DISPLAY_LONG_HANDLERS
    return report_unfenced_takeovers(server)


def install_serve_side(helper, *, platform: str = sys.platform) -> bool:
    """``hermes serve``: the runtime and thumbnail answer from the Hermes HQ Screen helper."""
    if not install_agent_side(platform=platform):
        return False
    mods = _modules()
    runtime, thumbnail = mods["runtime"], mods["thumbnail"]
    DesktopStatus = runtime.DesktopStatus
    profile_name = _originals.get(f"{runtime.__name__}._profile_name", runtime._profile_name)

    def is_supported_host() -> bool:
        return True

    def status(profile: Optional[str] = None):
        # The wire contract (DisplayStatus) forbids extra fields: "This Mac" in `display` is how a
        # client knows the screen is a shared Mac console; the rest is on /api/plugins/hermes-hq-screen/health.
        from hermes_constants import get_hermes_home
        current = helper.settings()
        live = helper.helper_status(timeout=0.5)
        allowed = helper.profile_allowed(profile_name(), current)
        block = helper.blocker(current, status=live, profile=profile_name())
        link = helper.link_path(get_hermes_home())
        width, height = (live or {}).get("width") or 0, (live or {}).get("height") or 0
        return DesktopStatus(
            profile=profile or profile_name(), supported=allowed, installed=True, missing=[],
            running=allowed and block is None, pid=(live or {}).get("pid"), display=helper.DISPLAY_NAME,
            socket=str(link) if link.is_symlink() else None, geometry=f"{width}x{height}" if width and height else "",
            install_command=None, browser=None, blocker=block if allowed else None,
            memory_available_mb=None, memory_limit_mb=None)

    def start(*, wait_seconds: float = 15.0):
        block = helper.blocker(profile=profile_name())
        if block:
            raise RuntimeError(block)
        if helper.ensure_running(wait=wait_seconds) is None:
            raise RuntimeError(f"The Hermes HQ Screen helper did not start on the Mac (see {helper.state_dir() / 'helper.log'})")
        return status()

    def stop() -> bool:
        running = helper.ctl({"cmd": "stop"}) is not None
        helper.remove_links(helper.known_homes())
        return running

    def rfb_socket_path():
        from hermes_constants import get_hermes_home
        if helper.blocker(profile=profile_name()) is not None or helper.ensure_running() is None:
            return None
        return helper.ensure_link(get_hermes_home())

    def stop_if_idle() -> bool:
        return False  # the helper stops capturing when nobody watches and exits after idle_minutes

    def ensure_started_for_tool() -> None:
        return None  # sharing never starts because the agent used computer_use

    def install_command():
        return None

    def sandbox_screen_running():
        # New Hermes routers prefer a sandbox relay when a stale terminal-screen
        # marker exists. This backend owns the Mac console and its private socket.
        return False

    def thumbnail_data_url(max_size=(960, 600), quality: int = 72):
        if helper.blocker(profile=profile_name()) is not None or helper.helper_status() is None:
            return None
        answer = helper.ctl({"cmd": "thumbnail", "max_w": int(max_size[0]), "max_h": int(max_size[1]), "quality": int(quality)}, timeout=5)
        return (answer or {}).get("data_url") or None

    for name, fn in [("is_supported_host", is_supported_host), ("status", status), ("start", start), ("stop", stop),
                     ("rfb_socket_path", rfb_socket_path), ("stop_if_idle", stop_if_idle),
                     ("ensure_started_for_tool", ensure_started_for_tool), ("install_command", install_command)]:
        _patch(runtime, name, fn)
    _patch(thumbnail, "thumbnail_data_url", thumbnail_data_url)
    if hasattr(runtime, "sandbox_screen_running"):
        _patch(runtime, "sandbox_screen_running", sandbox_screen_running)
    log.info("hermes-hq-screen: Bot Screen backend installed (helper state %s)", helper.state_dir())
    return True
