import AppKit
import Carbon.HIToolbox
import CoreGraphics
import ScreenCore

/// Posts translated remote input as HID events (needs the Accessibility grant). Only the viewer that
/// holds the Hermes control lease gets input this far: the gateway's display bridge drops the rest.
final class EventInput: InputMutationExecutor {
    init() { _ = ConsoleLockMonitor.shared }

    func executeMutation(_ body: () -> Void) {
        if Thread.isMainThread { body() } else { DispatchQueue.main.sync(execute: body) }
    }
    private let source = CGEventSource(stateID: .hidSystemState)
    private var flags: CGEventFlags = []

    func perform(_ action: InputAction) {
        switch action {
        case let .move(x, y, dragging):
            let type: CGEventType = switch dragging { case .left: .leftMouseDragged; case .right: .rightMouseDragged; case .middle: .otherMouseDragged; case nil: .mouseMoved }
            post(CGEvent(mouseEventSource: source, mouseType: type, mouseCursorPosition: CGPoint(x: x, y: y), mouseButton: button(dragging ?? .left)))
        case let .button(which, down, x, y, clicks):
            let type: CGEventType = switch (which, down) {
            case (.left, true): .leftMouseDown
            case (.left, false): .leftMouseUp
            case (.right, true): .rightMouseDown
            case (.right, false): .rightMouseUp
            case (.middle, true): .otherMouseDown
            case (.middle, false): .otherMouseUp
            }
            let event = CGEvent(mouseEventSource: source, mouseType: type, mouseCursorPosition: CGPoint(x: x, y: y), mouseButton: button(which))
            event?.setIntegerValueField(.mouseEventClickState, value: Int64(clicks))
            post(event)
        case let .scroll(dx, dy, x, y):
            let event = CGEvent(scrollWheelEvent2Source: source, units: .line, wheelCount: 2, wheel1: Int32(dy), wheel2: Int32(dx), wheel3: 0)
            event?.location = CGPoint(x: x, y: y)
            post(event)
        case let .key(code, down, modifiers):
            flags = cgFlags(modifiers)
            let event = CGEvent(keyboardEventSource: source, virtualKey: code, keyDown: down)
            event?.flags = flags
            post(event)
        case let .text(text, down):
            let event = CGEvent(keyboardEventSource: source, virtualKey: 0, keyDown: down)
            let units = Array(text.utf16)
            event?.keyboardSetUnicodeString(stringLength: units.count, unicodeString: units)
            event?.flags = flags.intersection(.maskShift)
            post(event)
        case let .pasteboard(text):
            // The entire gate runs on main before taking inputLock; the following ⌘V waits for this write.
            NSPasteboard.general.clearContents()
            NSPasteboard.general.setString(text, forType: .string)
        }
    }

    private func post(_ event: CGEvent?) { event?.post(tap: .cghidEventTap) }

    private func button(_ which: InputAction.Button) -> CGMouseButton {
        switch which { case .left: .left; case .right: .right; case .middle: .center }
    }

    private func cgFlags(_ modifiers: ModifierFlags) -> CGEventFlags {
        var out: CGEventFlags = []
        if modifiers.contains(.shift) { out.insert(.maskShift) }
        if modifiers.contains(.control) { out.insert(.maskControl) }
        if modifiers.contains(.option) { out.insert(.maskAlternate) }
        if modifiers.contains(.command) { out.insert(.maskCommand) }
        if modifiers.contains(.capsLock) { out.insert(.maskAlphaShift) }
        return out
    }
}

/// Characters to virtual keys for the current keyboard layout (so ⌘C is C wherever it sits).
func currentLayoutTable() -> [Character: UInt16] {
    guard let source = TISCopyCurrentKeyboardLayoutInputSource()?.takeRetainedValue(),
          let pointer = TISGetInputSourceProperty(source, kTISPropertyUnicodeKeyLayoutData) else { return Keysyms.usLayout }
    let data = Unmanaged<CFData>.fromOpaque(pointer).takeUnretainedValue() as Data
    var table: [Character: UInt16] = [:]
    data.withUnsafeBytes { raw in
        guard let layout = raw.baseAddress?.assumingMemoryBound(to: UCKeyboardLayout.self) else { return }
        for code in UInt16(0) ..< 128 {
            var dead: UInt32 = 0
            var length = 0
            var chars = [UniChar](repeating: 0, count: 4)
            let status = UCKeyTranslate(layout, code, UInt16(kUCKeyActionDisplay), 0, UInt32(LMGetKbdType()),
                                        OptionBits(kUCKeyTranslateNoDeadKeysBit), &dead, chars.count, &length, &chars)
            guard status == noErr, length == 1, let scalar = Unicode.Scalar(chars[0]) else { continue }
            let char = Character(String(scalar).lowercased())
            if table[char] == nil { table[char] = code }
        }
    }
    return table.isEmpty ? Keysyms.usLayout : table
}

private final class ConsoleLockMonitor {
    static let shared = ConsoleLockMonitor()
    private let lock = NSLock()
    private var signal = LockSignal()
    private var observers: [NSObjectProtocol] = []

    private init() {
        let workspace = NSWorkspace.shared.notificationCenter
        let distributed = DistributedNotificationCenter.default()
        observers.append(workspace.addObserver(forName: NSWorkspace.sessionDidResignActiveNotification, object: nil, queue: nil) { [weak self] _ in self?.update(session: true) })
        observers.append(workspace.addObserver(forName: NSWorkspace.sessionDidBecomeActiveNotification, object: nil, queue: nil) { [weak self] _ in self?.update(session: false) })
        observers.append(distributed.addObserver(forName: .init("com.apple.screenIsLocked"), object: nil, queue: nil) { [weak self] _ in self?.update(screen: true) })
        observers.append(distributed.addObserver(forName: .init("com.apple.screenIsUnlocked"), object: nil, queue: nil) { [weak self] _ in self?.update(screen: false) })
    }
    private func update(screen: Bool? = nil, session: Bool? = nil) {
        lock.lock(); defer { lock.unlock() }
        if let screen { signal.screenLocked = screen }
        if let session { signal.sessionResigned = session }
    }
    func state() -> LockState {
        lock.lock(); defer { lock.unlock() }
        let raw = CGSessionCopyCurrentDictionary() as? [String: Any]
        var session = raw
        // Normalize the documented constants at the platform boundary.
        session?["kCGSSessionOnConsoleKey"] = raw?[kCGSessionOnConsoleKey as String]
        session?["kCGSessionLoginDoneKey"] = raw?[kCGSessionLoginDoneKey as String]
        return consoleLockState(session: session, notified: signal)
    }
}

/// Locked or indeterminate console state reports locked; RFB refuses input unless --allow-unlock.
func screenIsLocked() -> Bool { ConsoleLockMonitor.shared.state() != .unlocked }

/// A password field has focus somewhere: macOS drops synthetic typing.
func secureInputEnabled() -> Bool { IsSecureEventInputEnabled() }
